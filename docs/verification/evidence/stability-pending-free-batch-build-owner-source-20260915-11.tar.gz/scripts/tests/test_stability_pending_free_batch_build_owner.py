"""Cheap contract tests for the pending-free candidate11 build owner.

These tests deliberately do not invoke Docker, compilers, a guest, or the
production lock.  They exercise only static profile/result rejection paths.
"""
import copy
import hashlib
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).parents[2]
OWNER = ROOT / 'docs/verification/evidence/stability-pending-free-batch-build-owner-20260915.py'
spec = importlib.util.spec_from_file_location('pending_free_build_owner', OWNER)
owner = importlib.util.module_from_spec(spec); spec.loader.exec_module(owner)


def inspect_row(config):
    """The accepted owner profile, with the new fixed harness argv only."""
    nonce, cid = config['nonce'], config['container_id']
    return {'Id': cid, 'Name': '/' + config['name'], 'Image': owner.IMAGE_ID,
            'Path': owner.PYTHON, 'Args': owner.harness_argv(),
            'Config': {'Hostname': cid[:12], 'Labels': {'mckernel.collector.owner': nonce},
                       'User': '1000:1000', 'Image': owner.IMAGE_ID, 'WorkingDir': '/work',
                       'Entrypoint': [owner.PYTHON], 'Cmd': owner.harness_argv(), 'Tty': False,
                       'OpenStdin': False, 'StdinOnce': False, 'AttachStdin': False, 'Domainname': '',
                       'Env': ['TMPDIR=/work/tmp', 'HOME=/tmp', 'PYTHONDONTWRITEBYTECODE=1']},
            'HostConfig': {'NetworkMode': 'none', 'Privileged': False, 'ReadonlyRootfs': True,
                           'CapDrop': ['ALL'], 'SecurityOpt': ['no-new-privileges'], 'GroupAdd': [],
                           'Memory': 12884901888, 'MemorySwap': 12884901888, 'NanoCpus': 4000000000,
                           'CpusetCpus': '2-5', 'PidsLimit': 512, 'CgroupParent': '/mckernel-dev',
                           'Init': True, 'PidMode': '', 'UTSMode': '', 'UsernsMode': '', 'IpcMode': 'private',
                           'Runtime': 'runc', 'AutoRemove': False, 'PublishAllPorts': False,
                           'RestartPolicy': {'Name': 'no', 'MaximumRetryCount': 0}, 'CgroupnsMode': '',
                           'ShmSize': 67108864, 'OomKillDisable': False, 'MemorySwappiness': -1,
                           'OomScoreAdj': 0, 'LogConfig': {'Type': 'json-file', 'Config': {}},
                           'Ulimits': [{'Hard': 0, 'Name': 'core', 'Soft': 0},
                                       {'Hard': 4096, 'Name': 'nofile', 'Soft': 4096}],
                           'Tmpfs': {'/tmp': 'rw,nodev,nosuid,size=256m'},
                           'MaskedPaths': ['/proc/kcore', '/proc/keys', '/proc/latency_stats', '/proc/timer_list', '/proc/scsi', '/sys/firmware'],
                           'ReadonlyPaths': ['/proc/bus', '/proc/fs', '/proc/irq', '/proc/sys', '/proc/sysrq-trigger'],
                           'Mounts': [{'Type': 'bind', 'Source': str(owner.REPO), 'Target': '/workspace', 'ReadOnly': True},
                                      {'Type': 'bind', 'Source': config['mount'], 'Target': '/work', 'ReadOnly': False}]},
            'Mounts': [{'Type': 'bind', 'Source': str(owner.REPO), 'Destination': '/workspace', 'RW': False, 'Propagation': 'rprivate'},
                       {'Type': 'bind', 'Source': config['mount'], 'Destination': '/work', 'RW': True, 'Propagation': 'rprivate'}],
            'NetworkSettings': {'Networks': {'none': {'IPAddress': '', 'GlobalIPv6Address': '',
                                                        'Gateway': '', 'IPv6Gateway': '', 'MacAddress': ''}}}}


class PendingFreeOwnerTests(unittest.TestCase):
    def test_exact_isolated_uid1000_entrypoint(self):
        argv = owner.expected_create('a' * 32, Path('/scratch/fresh'))
        for flag in ('--cpus=4', '--cpuset-cpus=2-5', '--memory=12g', '--memory-swap=12g',
                     '--pids-limit=512', '--cap-drop=ALL', '--security-opt=no-new-privileges',
                     '--read-only', '--network=none', '--user=1000:1000'):
            self.assertIn(flag, argv)
        self.assertNotIn('rustup', ' '.join(argv)); self.assertNotIn('+nightly', argv)
        self.assertEqual(argv[-8:], ['-B', owner.HARNESS, '--output-dir', owner.CONTAINER_OUTPUT,
                                     '--rustc', owner.RUSTC, '--cc', owner.GCC])

    def test_profile_rejects_entrypoint_and_capability_drift(self):
        config = {'nonce': 'b' * 32, 'name': 'mckernel-collector-' + 'b' * 32,
                  'container_id': 'c' * 64, 'mount': '/scratch/fresh'}
        image = {'Id': owner.IMAGE_ID, 'Architecture': 'amd64', 'Os': 'linux',
                 'Config': {'Env': []}, 'RootFS': {'Type': 'layers', 'Layers': []}}
        row = inspect_row(config)
        owner.full_inspect(row, config, image, copy.deepcopy(image))
        mutations = (
            lambda r: r.__setitem__('Args', ['-c', 'id']),
            lambda r: r['Config'].__setitem__('Cmd', ['-B', owner.HARNESS, '--rustc', '/tmp/rustc']),
            lambda r: r['HostConfig'].__setitem__('Privileged', True),
            lambda r: r['HostConfig'].__setitem__('Devices', ['/dev/kvm']),
            lambda r: r['Mounts'].__setitem__(0, {**r['Mounts'][0], 'RW': True}),
        )
        for mutate in mutations:
            with self.subTest(mutate=mutate):
                drift = copy.deepcopy(row); mutate(drift)
                with self.assertRaises(ValueError): owner.full_inspect(drift, config, image, copy.deepcopy(image))

    def test_source_and_six_input_pins_are_exact(self):
        self.assertEqual(len(owner.pinned_inputs()), 6)
        for path, expected in owner.pinned_inputs().items():
            self.assertEqual(hashlib.sha256((ROOT / path).read_bytes()).hexdigest(), expected)
        source = OWNER.read_text()
        for required in ('compiler_copies', 'RUSTC_SHA', 'GCC_SHA', 'recover_cleanup',
                         'watchdog-config.json', 'original-tree-inventory.json',
                         "'--rustc', RUSTC", "'--cc', GCC"):
            self.assertIn(required, source)

    def test_result_rejects_rustup_and_inventory_drift_before_artifact_binding(self):
        with tempfile.TemporaryDirectory() as td:
            mount, host = Path(td) / 'mount', Path(td) / 'host'; output = mount / owner.OUTPUT_NAME
            output.mkdir(parents=True); host.mkdir()
            commands = []
            labels = ['bash-syntax', 'rustc-identity', 'cc-identity', 'rust-compile', 'rust-run', 'c-compile', 'c-run', 'mutant-compile', 'mutant-run'] + ['trait-' + x for x in ('Copy', 'Clone', 'Unpin', 'Send', 'Sync')] + ['diff-check']
            for label in labels:
                commands.append({'label': label, 'argv': [owner.RUSTC, '--version', '--verbose'] if label == 'rustc-identity' else [owner.GCC, '--version'] if label == 'cc-identity' else ['fixture'], 'cwd': '/workspace', 'environment': {'PATH': '/usr/bin:/bin'}, 'started_ns': 1, 'finished_ns': 2, 'returncode': 1 if label.startswith('trait-') else 0, 'stdout_sha256': '0' * 64, 'stderr_sha256': '0' * 64})
            manifest = {'status': 'PASS_PENDING_FREE_BATCH_FOCUSED_EQUIVALENCE_ONLY', 'scope': 'source fixture only; no runtime or production credit', 'inputs': owner.pinned_inputs(), 'commands': commands, 'expected': [['one']], 'rust_rows': [], 'c_rows': [], 'mutant_detected': {}, 'trait_negatives': {}}
            (output / 'manifest.json').write_text(json.dumps(manifest))
            (output / 'rustc-identity.stdout').write_text('rustc\n' + owner.RUSTC_RELEASE + '\n' + owner.RUSTC_COMMIT + '\n')
            (output / 'cc-identity.stdout').write_text('gcc\n')
            (output / 'input-manifest.json').write_text(json.dumps({'inputs': owner.pinned_inputs(), 'environment': {}, 'platform': 'x', 'harness_argv': ['x', '--rustc', owner.RUSTC, '--cc', owner.GCC], 'cwd': '/workspace'}))
            (output / 'inputs').mkdir()
            for relative in owner.pinned_inputs(): (output / 'inputs' / Path(relative).name).write_bytes((ROOT / relative).read_bytes())
            (output / 'commands.json').write_text(json.dumps(commands))
            artifacts = {'manifest.json': hashlib.sha256((output / 'manifest.json').read_bytes()).hexdigest(), 'commands.json': hashlib.sha256((output / 'commands.json').read_bytes()).hexdigest(), 'input-manifest.json': hashlib.sha256((output / 'input-manifest.json').read_bytes()).hexdigest(), 'rustc-identity.stdout': hashlib.sha256((output / 'rustc-identity.stdout').read_bytes()).hexdigest(), 'cc-identity.stdout': hashlib.sha256((output / 'cc-identity.stdout').read_bytes()).hexdigest()}
            (output / 'artifact-manifest.json').write_text(json.dumps(artifacts))
            owner.verify_result(mount, host, owner.pinned_inputs())
            commands[0]['environment']['RUSTUP_HOME'] = '/bad'
            (output / 'manifest.json').write_text(json.dumps(manifest))
            artifacts['manifest.json'] = hashlib.sha256((output / 'manifest.json').read_bytes()).hexdigest()
            (output / 'artifact-manifest.json').write_text(json.dumps(artifacts))
            rejected_host = Path(td) / 'rejected-host'; rejected_host.mkdir()
            with self.assertRaises(ValueError): owner.verify_result(mount, rejected_host, owner.pinned_inputs())


if __name__ == '__main__':
    unittest.main(verbosity=2)
