#include <stdio.h>
#include <string.h>
#include "native-application-c-reference.h"

static void emit(const char *tag, struct ikc_scd_packet *p) {
    printf("%s ",tag); for(unsigned i=0;i<sizeof(*p);++i)printf("%02x",((unsigned char *)p)[i]); puts("");
}
int main(void) {
    struct ikc_scd_packet p={0};p.msg=SCD_MSG_SCHEDULE_PROCESS;p.reply=(void *)7UL;p.ref=2;p.osnum=3;p.pid=723;p.arg=0xffff880012345000UL;emit("SCHEDULE",&p);
    p.msg=SCD_MSG_CLEANUP_PROCESS;p.arg=0;memcpy(&p.resp_pa,"MCRQ0001",8);emit("QUERY",&p);
    p.msg=SCD_MSG_CLEANUP_PROCESS_RESP;memcpy(&p.resp_pa,"MCRE0001",8);emit("ABSENT",&p);
    p.err=-11;emit("PRESENT",&p);p.err=0;p.resp_pa=0;p.pid=0;p.osnum=0;emit("LEGACY",&p);return 0;
}
