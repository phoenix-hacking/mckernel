#!/usr/bin/env python3
"""Small container preflight; does not load modules or execute guest helpers."""
import json
import os
from pathlib import Path
import subprocess

assert os.geteuid() == 1000
assert sorted(os.sched_getaffinity(0)) == [2, 3, 4, 5]
status = dict(line.split(':', 1) for line in Path('/proc/self/status').read_text().splitlines() if ':' in line)
assert int(status['CapEff'].strip(), 16) == 0
assert status['NoNewPrivs'].strip() == '1'
assert sorted(path.name for path in Path('/sys/class/net').iterdir()) == ['lo']
for forbidden in ('/var/run/docker.sock', '/dev/kvm', '/dev/mcd0'):
    assert not Path(forbidden).exists(), forbidden
assert not list(Path('/dev').glob('nvme*'))
assert not list(Path('/dev').glob('mcos*'))
mounts = {line.split()[4]: line.split()[5].split(',') for line in Path('/proc/self/mountinfo').read_text().splitlines()}
for mount in ('/', '/workspace', '/guests'):
    assert 'ro' in mounts[mount], mount
assert 'rw' in mounts['/work']
cgroups = {}
for line in Path('/proc/self/cgroup').read_text().splitlines():
    _, controllers, relative = line.split(':', 2)
    for controller in controllers.split(','):
        cgroups[controller] = relative
def read_limit(controller, name):
    root = Path('/sys/fs/cgroup') / controller
    candidates = [root / cgroups[controller].lstrip('/') / name, root / name]
    for path in candidates:
        if path.is_file():
            return path.read_text().strip()
    raise AssertionError('Missing controller limit: ' + controller + '/' + name)
limits = {
    'memory_bytes': read_limit('memory', 'memory.limit_in_bytes'),
    'memory_and_swap_bytes': read_limit('memory', 'memory.memsw.limit_in_bytes'),
    'cpu_period_us': read_limit('cpu', 'cpu.cfs_period_us'),
    'cpu_quota_us': read_limit('cpu', 'cpu.cfs_quota_us'),
    'max_tasks': read_limit('pids', 'pids.max'),
}
assert limits == {
    'memory_bytes': '12884901888', 'memory_and_swap_bytes': '12884901888',
    'cpu_period_us': '100000', 'cpu_quota_us': '400000', 'max_tasks': '512',
}, limits
print(json.dumps({
    'uid': os.geteuid(), 'cpus': sorted(os.sched_getaffinity(0)),
    'capabilities': 0, 'no_new_privileges': True, 'network': 'loopback only',
    'readonly_mounts': ['/', '/workspace', '/guests'],
    'host_devices_and_docker_socket': 'absent', 'limits': limits,
    'rustc': subprocess.check_output(['rustc', '--version'], universal_newlines=True).strip(),
}, indent=2))
