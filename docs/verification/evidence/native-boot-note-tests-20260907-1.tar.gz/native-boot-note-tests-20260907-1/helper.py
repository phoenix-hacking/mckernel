from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,os,shutil,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace')
out=Path('/work/native-boot-note-tests-20260907-'+sys.argv[1]);out.mkdir()
paths=['host-kernel/native-rust/smp_image.rs','host-kernel/native-rust/ihk_mapping.rs','host-kernel/native-rust/smp_resource.rs','scripts/tests/fixtures/ihk_smp_image_compile.rs','kernel/rust/x86_setup.rs']
record=dict(started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),commands=[],production_gate_credit=False)
for relative in paths:
    target=out/'source'/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/relative,target)
commands=[['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false']+[str(out/'source'/p) for p in paths if p in (paths[0],paths[3],paths[4])],['rustc','--edition=2021','--test','-Dwarnings',str(out/'source/scripts/tests/fixtures/ihk_smp_image_compile.rs'),'-o',str(out/'image-tests')],[str(out/'image-tests'),'--test-threads=1']]
try:
    for i,command in enumerate(commands):
        with (out/('step-'+str(i)+'.log')).open('wb') as log:
            result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
        record['commands'].append(dict(command=command,exit_code=result.returncode))
        if result.returncode: raise RuntimeError((command,(out/('step-'+str(i)+'.log')).read_text()))
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    record['inputs']=[dict(path=str(out/'source'/p),size=(out/'source'/p).stat().st_size,sha256=hashlib.sha256((out/'source'/p).read_bytes()).hexdigest()) for p in paths]
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    shutil.copyfile(__file__,out/'helper.py')
    print(record['status'],out,flush=True)
