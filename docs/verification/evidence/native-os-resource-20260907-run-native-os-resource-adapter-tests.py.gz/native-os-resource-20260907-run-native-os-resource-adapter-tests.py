import os,sys,json,hashlib,shutil,subprocess
from pathlib import Path
from datetime import datetime,timezone
repo=Path('/workspace');out=Path('/work/native-os-resource-adapter-tests-20260907');out.mkdir()
shutil.copytree(repo/'host-kernel/native-rust',out/'host-kernel/native-rust')
paths=['scripts/tests/test_ihk_os_runtime.py','scripts/tests/test_ihk_smp_resource.py','scripts/tests/test_ihk_smp_buildid.py','scripts/ihk_smp_native_lifecycle_check.py','scripts/native_rust_host_audit.py']
for rel in paths:
 target=out/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/rel,target)
shutil.copytree(repo/'scripts/tests/fixtures',out/'scripts/tests/fixtures')
format_names=['ihk_smp_x86_64.rs','smp_cpu.rs','smp_memory.rs','os_runtime.rs']
record={'started_utc':datetime.now(timezone.utc).isoformat(),'paths':[],'preformat':{},'scope':'prototype policy, complete IHK adapter mocks and extracted device dispatch; authority bindings pending'}
for name in format_names:
 path=out/'host-kernel/native-rust'/name;record['preformat'][name]=hashlib.sha256(path.read_bytes()).hexdigest()
 subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(path)],check=True)
for path in sorted((out/'host-kernel/native-rust').glob('*.rs')):
 b=path.read_bytes();record['paths'].append({'path':str(path.relative_to(out)),'sha256':hashlib.sha256(b).hexdigest(),'size':len(b)})
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',MCKERNEL_RUSTC_1_92='/usr/bin/rustc',RUSTC='/usr/bin/rustc')
command=['python3','-m','unittest','scripts.tests.test_ihk_smp_resource','scripts.tests.test_ihk_os_runtime','-f']
with (out/'tests.log').open('wb') as log:
 result=subprocess.run(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT)
record.update(command=command,exit_code=result.returncode,finished_utc=datetime.now(timezone.utc).isoformat())
(out/'record.json').write_text(json.dumps(record,indent=2)+'\n')
print('OS_RESOURCE_ADAPTER_TEST_EXIT',result.returncode,flush=True)
print((out/'tests.log').read_text()[-9000:],flush=True)
sys.exit(result.returncode)
