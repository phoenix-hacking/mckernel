from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');out=Path('/work/native-application-failure-build-20260909-'+sys.argv[1]);out.mkdir()
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),commands=[],inputs=[],runtime_libraries=[],scope='Ordinary dynamically linked libc application smokes: memory, file I/O, pthread barrier/mutex/TLS/join, blocked and alternate-stack signals. Linux reference only at this build step.',mckernel_application_executed=False,production_gate_credit=False)
def identity(p):
 b=p.read_bytes();return dict(path=str(p),size=len(b),sha256=hashlib.sha256(b).hexdigest())
def run(label,command,expected=0,timeout=60,input_data=None):
 print('RUN',label,flush=True);(out/'phase').write_text(label+'\n')
 with (out/(label+'.log')).open('wb') as stream:r=subprocess.run(command,cwd=str(out),stdout=stream,stderr=subprocess.STDOUT,timeout=timeout,input=input_data)
 record['commands'].append(dict(label=label,command=command,expected=expected,exit_code=r.returncode));assert r.returncode==expected,(label,(out/(label+'.log')).read_text()[-8000:])
 return (out/(label+'.log')).read_text()
try:
 shutil.copyfile(__file__,out/'helper.py')
 run('diff-check',['git','-C',str(repo),'diff','--check'])
 record['compiler']=run('compiler',['cc','--version'])
 record['binaries']=[]
 for name in ['native-application-failure','native-application-failure-control']:
  source=out/(name+'.c');shutil.copyfile(repo/'scripts/tests/fixtures'/(name+'.c'),source);record['inputs'].append(identity(source))
  binary=out/name
  run(name+'-build',['cc','-O2','-g','-Wall','-Wextra','-Werror','-fno-pie','-no-pie','-Wl,-z,noexecstack','-MD','-MF',str(out/(name+'.d')),str(source),'-o',str(binary)])
  header=run(name+'-elf',['readelf','-h','-l',str(binary)]);assert 'ELF64' in header and 'EXEC' in header and 'INTERP' in header
  run(name+'-disassembly',['objdump','-d',str(binary)])
  libs=run(name+'-libraries',['ldd',str(binary)]);assert 'not found' not in libs
  for lib in sorted(set(re.findall(r'(/[^\s()]+)\s+\(0x[0-9a-f]+\)',libs))):
   original=Path(lib);target=out/'runtime'/lib.lstrip('/');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,target)
   record['runtime_libraries'].append(dict(original=identity(original),captured=identity(target)))
  record['binaries'].append(identity(binary))
 record['scope']='Ordinary guarded-read payload plus Linux-only supervisor using owned pipes/child, real proc task state and SIGKILL. Both Linux references only; actual McKernel owner failure pending. pid_max mutation is confined to the explicitly selected isolated guest mode.'
 payload=out/'native-application-failure';controller=out/'native-application-failure-control'
 stdin=bytes([0xa5])*16;(out/'linux-reference-stdin.bin').write_bytes(stdin)
 stdout=run('linux-reference-read',[str(payload)],37,20,stdin)
 assert stdout=='NATIVE_FAILURE_READY\nNATIVE_FAILURE_PASS\n',repr(stdout)
 stdout=run('linux-reference-kill',[str(controller),'--linux-reference',str(payload)],0,25)
 blocked=re.findall(r'NATIVE_FAILURE_BLOCKED pid=(\d+) tid=(\d+) syscall=0 0x0 (0x[0-9a-f]+) 0x10\b',stdout)
 assert len(blocked)==1,stdout
 pid,tid,address=blocked[0]
 assert 'NATIVE_FAILURE_KILLED pid='+pid+' tid='+tid+' signal=9\n' in stdout
 assert 'NATIVE_FAILURE_CONTROL PASS guest=0 pid='+pid+' tid='+tid+'\n' in stdout
 assert 'NATIVE_FAILURE_PASS' not in stdout and 'NATIVE_FAILURE_REUSE' not in stdout
 record['linux_reference']=dict(guarded_read=dict(bytes=16,exit_code=37),blocked_read_sigkill=dict(pid=int(pid),tid=int(tid),buffer=address,signal=9,controller_exit_code=0),mckernel=False)
 record['compiler_dependencies']=[]
 for dep in out.glob('*.d'):
  for name in dep.read_text().replace('\\\n',' ').split()[1:]:
   path=Path(name)
   if path.is_absolute() and path.is_file():record['compiler_dependencies'].append(identity(path))
 assert record['compiler_dependencies']
 record.update(status='PASS')
except BaseException as error:record.update(status='FAIL',error=str(error));raise
finally:
 record['finished_utc']=datetime.now(timezone.utc).isoformat();record['outputs']=[identity(p) for p in out.iterdir() if p.is_file() and p.name not in ('record.json','phase')];(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],out,flush=True)
