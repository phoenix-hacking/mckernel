"""Preserve durable RS-011 identities while adding owned startup page tables."""
import collections, copy, json, sys
from pathlib import Path
sys.path.insert(0, '/workspace/scripts')
import native_rust_unsafe_ffi_ledger as checker
repo = '/workspace'
ledger = json.loads(Path(repo, checker.LEDGER_PATH).read_text())
discovery = checker.discover(repo)
remaining = {site['id']: site for site in ledger['sites']}
original_ids = set(remaining)
allowed_changed = {'RS011-SMP-0044'}
next_smp = max(int(sid.rsplit('-', 1)[1]) for sid in remaining if sid.startswith('RS011-SMP-')) + 1
def key(site):
    return (site['path'], site['kind'], site['expression_sha256'], json.dumps(site['macro_context'], sort_keys=True))
constraints = [
    'Pinned Linux 6.12 x86_64 ABI; IHK supplies an exact live slot/generation lease and retains the SMP provider module through each synchronous callback.',
    'Process context under the per-OS operation mutex, CPU then memory controller locks; image loading starts no CPUs and publishes no executable capability.',
    'Keep existing strict-node resource allocations on __alloc_pages_noprof with an explicitly validated concrete node and THISNODE. Never pass NUMA_NO_NODE to that low-level API.',
    'For startup tables use exported alloc_pages_noprof: Linux resolves the current NUMA policy. GFP_KERNEL, ZERO, COMP, NORETRY, NOWARN and DMA32 request a bounded order-9 non-movable allocation without THISNODE; ENOMEM has no image effect.',
    'Retain the original PageOwner and compound order on every success and error path. Validate exact vmemmap/page-node layout and the entire useful 260-page extent below 4 GiB and disjoint from owned bootstrap RAM.',
    'Fill and physically read back only the useful u64-aligned extent of one exclusive original Linux allocation. No reference crosses allocations, no temporary page reaches the Linux stack, and no pointer escapes.',
    'LoadedImage is noncopy and retains StartupTables and PageOwner for the exact OS generation. Replacement and invalid input retire the prior image before reading the new file; memory changes and unbooted destruction also retire tables.',
    'All ELF and startup-space checks and the complete startup allocation/fill precede the first image write. Failed allocation cannot publish LoadedImage or authorize boot. The OS operation lock serializes invalidation and destruction.',
    'The guest checks independent identity/straight/kernel mappings, high-NUMA image placement, original-owner cleanup, and forced order-9 failure/recovery. CPU wakeup, trampoline, IKC and native McKernel boot remain pending; no production credit.',
]
records, changed, added = [], [], []
for found in discovery['sites']:
    candidates = [site for site in remaining.values() if key(site) == key(found)]
    if not candidates:
        candidates = [site for site in remaining.values() if site['id'] in allowed_changed
                      and site['path'] == found['path'] and site['kind'] == found['kind']
                      and 'low-level allocator never receives NUMA_NO_NODE' in found['safety_comment']['text']]
        if candidates:
            if len(candidates) != 1:
                raise SystemExit('Ambiguous changed boundary identity')
            changed.append(candidates[0]['id'])
    if candidates:
        record = copy.deepcopy(candidates[0])
        del remaining[record['id']]
        record.update(checker.mechanical_site(found))
    else:
        if found['kind'] != 'unsafe_block' or found['path'] not in {
            'host-kernel/native-rust/smp_loader.rs', 'host-kernel/native-rust/smp_memory.rs',
            'host-kernel/native-rust/smp_cpu.rs',
        }:
            raise SystemExit('Unexpected new boundary: ' + repr(found))
        record = checker.mechanical_site(found)
        record.update(id='RS011-SMP-%04d' % next_smp,
                      owner={'component': 'native Rust SMP owned startup page tables', 'accountable_role': 'host-module maintainer'},
                      caller_obligations=[found['safety_comment']['text']],
                      context_constraints=list(constraints),
                      compiler_capture={'required': True, 'status': 'not_captured', 'evidence_sha256': None},
                      independent_review={'required': True, 'status': 'pending', 'reviewer': None, 'evidence_sha256': None})
        next_smp += 1
        added.append(record['id'])
    if record['id'] in allowed_changed:
        record['caller_obligations'] = [found['safety_comment']['text']]
        record['context_constraints'] = list(constraints)
    if record['id'] in original_ids and found['path'].endswith('/smp_memory.rs'):
        record['context_constraints'] = [line.replace(
            'Native boot and guest access remain unimplemented.',
            'The image loader writes and reads back exclusively assigned unbooted RAM while retaining the original PageOwners; native CPU startup and user VMA access remain unimplemented.')
            for line in record['context_constraints']]
    if found['path'].endswith('/smp_memory.rs'):
        record['context_constraints'] = list(dict.fromkeys(record['context_constraints'] + constraints))
    records.append(record)
if remaining or set(changed) != allowed_changed or len(added) != 2:
    raise SystemExit('Unexpected retirement or boundary changes: ' + repr((remaining, changed, added)))
ledger['sites'] = records
ledger['repository_locks'], ledger['target'] = checker.expected_locks(repo)
ledger['crate_roots'] = discovery['roots']
ledger['source_inputs'] = discovery['inputs']
ledger['source_closure_sha256'] = discovery['source_closure_sha256']
ledger['coverage'] = dict(source_input_count=len(discovery['inputs']), site_count=len(records),
    site_ids_sha256=checker.sha256_bytes(checker.canonical_bytes([site['id'] for site in records])),
    by_kind=dict(sorted(collections.Counter(site['kind'] for site in records).items())),
    by_crate={crate: sum(crate in site['crate_roots'] for site in records) for crate in checker.EXPECTED_CRATES},
    source_inventory_status='complete_for_locked_source_bytes')
ledger['ledger_sha256'] = checker.ledger_digest(ledger)
checker.validate_ledger(ledger, repo)
out = Path('/work/native-startup-updated-ffi-ledger-20260907.json')
with out.open('x') as stream:
    stream.write(checker.pretty(ledger))
with out.with_suffix('.changes.json').open('x') as stream:
    stream.write(checker.pretty(dict(changed_existing_ids=changed, new_ids=added, preserved_ids=sorted(original_ids))))
print(checker.pretty(ledger['coverage']), flush=True)
