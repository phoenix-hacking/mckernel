type FutexWaitGetKeyFn = unsafe extern "C" fn(usize, CInt, usize) -> CInt;
type FutexWaitQueueLockFn = unsafe extern "C" fn(usize) -> usize;
type FutexWaitGetValueFn = unsafe extern "C" fn(usize, usize) -> CInt;
type FutexWaitQueueUnlockFn = unsafe extern "C" fn(usize, usize);
type FutexWaitPutKeyFn = unsafe extern "C" fn(CInt, usize);
type FutexWaitSpinLockFn = unsafe extern "C" fn(usize) -> CULong;
type FutexWaitSpinUnlockFn = unsafe extern "C" fn(usize, CULong);
type FutexWaitQueueMeFn = unsafe extern "C" fn(usize, usize);
type FutexWaitScheduleTimeoutFn = unsafe extern "C" fn(u64) -> i64;
type FutexWaitScheduleDirectFn = unsafe extern "C" fn();
type FutexWaitQueueLogFn = unsafe extern "C" fn(CInt, usize, CInt);
type FutexWaitSetupCallFn = unsafe extern "C" fn(usize, u32, CInt, usize, usize) -> CInt;
type FutexWaitQueueCallFn = unsafe extern "C" fn(usize, usize, u64) -> i64;
type FutexWaitUnqueueFn = unsafe extern "C" fn(usize) -> CInt;
type FutexWaitHasSignalFn = unsafe extern "C" fn(usize) -> CInt;
type FutexWaitLogFn = unsafe extern "C" fn(CInt, usize, CInt, CInt);
type FutexWaitTimestampFn = unsafe extern "C" fn() -> usize;
type FutexWaitBodyEntryFn =
    unsafe extern "C" fn(usize, CInt, u32, u64, u32, usize, usize, usize) -> CInt;
type TimerSpinInitFn = unsafe extern "C" fn(usize);
type TimerSpinLockFn = unsafe extern "C" fn(usize) -> CULong;
type TimerSpinUnlockFn = unsafe extern "C" fn(usize, CULong);
type TimerRdtscFn = unsafe extern "C" fn() -> u64;
type TimerVoidFn = unsafe extern "C" fn();
type TimerSetStatusFn = unsafe extern "C" fn(usize, CInt);
type TimerLapicEnableFn = unsafe extern "C" fn(u32);
type TimerLapicDisableFn = unsafe extern "C" fn();
type TimerWaitqWakeupFn = unsafe extern "C" fn(usize);
type TimerLogWakeFn = unsafe extern "C" fn(usize, usize);
const EINVAL: CInt = 22;
const FUTEX_WAIT_POST_SUCCESS: CInt = 0;
const FUTEX_WAIT_POST_RETRY: CInt = 1;
const FUTEX_WAIT_POST_TIMEOUT: CInt = 2;
const FUTEX_WAIT_POST_INTERRUPT: CInt = 3;
const FUTEX_WAIT_LOG_SETUP_RET: CInt = 1;
const FUTEX_WAIT_LOG_SUCCESS: CInt = 2;
const FUTEX_WAIT_LOG_TIMEOUT: CInt = 3;
const FUTEX_WAIT_LOG_INTERRUPT: CInt = 4;
const EINTR: CInt = 4;
const ETIMEDOUT: CInt = 110;
const ERESTARTSYS: i64 = 512;
const PS_RUNNING: CInt = 0x1;
#[repr(C)]
pub struct TimerRuntimeOffsets {
    pub thread_status_offset: usize,
    pub thread_sched_list_offset: usize,
    pub thread_spin_sleep_lock_offset: usize,
    pub thread_spin_sleep_offset: usize,
    pub thread_itimer_enabled_offset: usize,
    pub cpu_runq_lock_offset: usize,
    pub cpu_runq_offset: usize,
    pub cpu_runq_len_offset: usize,
    pub cpu_current_offset: usize,
    pub cpu_timer_enabled_offset: usize,
    pub cpu_backlog_list_offset: usize,
    pub timer_timeout_offset: usize,
    pub timer_waitq_offset: usize,
    pub timer_list_offset: usize,
    pub timer_thread_offset: usize,
}
pub extern "C" fn timer_spin_sleep_remaining_result(timeout: u64, elapsed: u64) -> u64 {
    if elapsed < timeout {
        timeout - elapsed
    } else {
        1
    }
}
pub extern "C" fn timer_runq_should_schedule_result(runq_len: CInt) -> CInt {
    (runq_len > 1) as CInt
}
pub extern "C" fn timer_after_spin_remaining_result(timeout: u64, loop_timeout: u64) -> u64 {
    if timeout < loop_timeout {
        0
    } else {
        timeout - loop_timeout
    }
}
pub unsafe extern "C" fn timer_schedule_timeout_body_result(
    thread_addr: usize,
    cpu_local_addr: usize,
    mut timeout: u64,
    loop_timeout: u64,
    offsets: *const TimerRuntimeOffsets,
    rdtsc_fn: Option<TimerRdtscFn>,
    spin_lock_fn: Option<TimerSpinLockFn>,
    spin_unlock_fn: Option<TimerSpinUnlockFn>,
    set_status_fn: Option<TimerSetStatusFn>,
    schedule_fn: Option<TimerVoidFn>,
    zero_free_fn: Option<TimerVoidFn>,
    pause_fn: Option<TimerVoidFn>,
) -> u64 {
    if thread_addr == 0 || cpu_local_addr == 0 || offsets.is_null() || loop_timeout == 0 {
        return timeout;
    }
    let (
        Some(rdtsc),
        Some(spin_lock),
        Some(spin_unlock),
        Some(set_status),
        Some(schedule),
        Some(zero_free),
        Some(pause),
    ) = (
        rdtsc_fn,
        spin_lock_fn,
        spin_unlock_fn,
        set_status_fn,
        schedule_fn,
        zero_free_fn,
        pause_fn,
    )
    else {
        return timeout;
    };

    let offsets = unsafe { &*offsets };
    let thread_spin_lock_addr = thread_addr.wrapping_add(offsets.thread_spin_sleep_lock_offset);
    let thread_spin_sleep_addr = thread_addr.wrapping_add(offsets.thread_spin_sleep_offset);
    let thread_status_addr = thread_addr.wrapping_add(offsets.thread_status_offset);
    let runq_lock_addr = cpu_local_addr.wrapping_add(offsets.cpu_runq_lock_offset);
    let runq_len_addr = cpu_local_addr.wrapping_add(offsets.cpu_runq_len_offset);

    #[cfg(native_linux_irq_work_v6_12)]
    let (native_started, native_duration) = (unsafe { rdtsc() }, timeout);

    loop {
        let t_s = unsafe { rdtsc() };
        #[cfg(native_linux_irq_work_v6_12)]
        {
            timeout = native_duration.saturating_sub(t_s.wrapping_sub(native_started));
        }
        let irqstate = unsafe { spin_lock(thread_spin_lock_addr) };

        if unsafe { read_volatile(thread_spin_sleep_addr as *const CInt) } == 0 {
            let t_e = unsafe { rdtsc() };
            timeout = timer_spin_sleep_remaining_result(timeout, t_e.wrapping_sub(t_s));
            unsafe {
                spin_unlock(thread_spin_lock_addr, irqstate);
            }
            break;
        }

        #[cfg(native_linux_irq_work_v6_12)]
        if timeout == 0 {
            unsafe {
                write_volatile(thread_spin_sleep_addr as *mut CInt, 0);
                spin_unlock(thread_spin_lock_addr, irqstate);
            }
            break;
        }

        unsafe {
            spin_unlock(thread_spin_lock_addr, irqstate);
        }

        let irqstate = unsafe { spin_lock(runq_lock_addr) };
        let runq_len = unsafe { read_volatile(runq_len_addr as *const usize) };
        let need_schedule = timer_runq_should_schedule_result(runq_len as CInt) != 0;
        if need_schedule {
            unsafe {
                set_status(thread_status_addr, PS_RUNNING);
                spin_unlock(runq_lock_addr, irqstate);
                schedule();
            }
            continue;
        }
        unsafe {
            spin_unlock(runq_lock_addr, irqstate);
        }

        #[cfg(native_linux_irq_work_v6_12)]
        let spin_budget = loop_timeout.min(timeout);
        #[cfg(not(native_linux_irq_work_v6_12))]
        let spin_budget = loop_timeout;
        while unsafe { rdtsc().wrapping_sub(t_s) } < spin_budget {
            unsafe {
                zero_free();
                pause();
            }
        }

        #[cfg(native_linux_irq_work_v6_12)]
        {
            timeout = native_duration.saturating_sub(unsafe { rdtsc() }.wrapping_sub(native_started));
        }
        #[cfg(not(native_linux_irq_work_v6_12))]
        {
            timeout = timer_after_spin_remaining_result(timeout, loop_timeout);
        }
        if timeout == 0 {
            let irqstate = unsafe { spin_lock(thread_spin_lock_addr) };
            unsafe {
                write_volatile(thread_spin_sleep_addr as *mut CInt, 0);
                spin_unlock(thread_spin_lock_addr, irqstate);
            }
            break;
        }
    }

    timeout
}
pub unsafe extern "C" fn futex_wait_prepare_q_result(
    q_addr: usize,
    bitset_offset: usize,
    requeue_pi_key_offset: usize,
    uti_futex_resp_offset: usize,
    bitset: u32,
    uti_futex_resp: usize,
) {
    if q_addr == 0 {
        return;
    }

    unsafe {
        write_volatile(q_addr.wrapping_add(bitset_offset) as *mut u32, bitset);
        write_volatile(q_addr.wrapping_add(requeue_pi_key_offset) as *mut usize, 0);
        write_volatile(
            q_addr.wrapping_add(uti_futex_resp_offset) as *mut usize,
            uti_futex_resp,
        );
    }
}
pub extern "C" fn futex_wake_bitset_valid_result(bitset: u32) -> CInt {
    (bitset != 0) as CInt
}
pub extern "C" fn futex_wait_post_action_result(
    unqueued: CInt,
    timeout: u64,
    time_remain: i64,
    has_pending_signal: CInt,
    restart_sys: CInt,
) -> CInt {
    if unqueued == 0 {
        return FUTEX_WAIT_POST_SUCCESS;
    }
    if timeout != 0 && time_remain == 0 {
        return FUTEX_WAIT_POST_TIMEOUT;
    }
    if has_pending_signal != 0 || restart_sys != 0 {
        return FUTEX_WAIT_POST_INTERRUPT;
    }
    FUTEX_WAIT_POST_RETRY
}
pub unsafe extern "C" fn futex_wait_body_result(
    uaddr: usize,
    fshared: CInt,
    val: u32,
    timeout: u64,
    bitset: u32,
    q_addr: usize,
    thread_addr: usize,
    uti_futex_resp: usize,
    q_bitset_offset: usize,
    q_requeue_pi_key_offset: usize,
    q_uti_futex_resp_offset: usize,
    q_key_offset: usize,
    thread_tid_offset: usize,
    setup_fn: Option<FutexWaitSetupCallFn>,
    wait_queue_fn: Option<FutexWaitQueueCallFn>,
    unqueue_fn: Option<FutexWaitUnqueueFn>,
    has_signal_fn: Option<FutexWaitHasSignalFn>,
    put_key_fn: Option<FutexWaitPutKeyFn>,
    log_fn: Option<FutexWaitLogFn>,
) -> CInt {
    if q_addr == 0 || thread_addr == 0 {
        return -EINVAL;
    }
    let Some(setup) = setup_fn else {
        return -EINVAL;
    };
    let Some(wait_queue) = wait_queue_fn else {
        return -EINVAL;
    };
    let Some(unqueue) = unqueue_fn else {
        return -EINVAL;
    };
    let Some(has_signal) = has_signal_fn else {
        return -EINVAL;
    };
    let Some(put_key) = put_key_fn else {
        return -EINVAL;
    };
    let Some(log) = log_fn else {
        return -EINVAL;
    };

    if futex_wake_bitset_valid_result(bitset) == 0 {
        return -EINVAL;
    }

    unsafe {
        futex_wait_prepare_q_result(
            q_addr,
            q_bitset_offset,
            q_requeue_pi_key_offset,
            q_uti_futex_resp_offset,
            bitset,
            uti_futex_resp,
        );
    }
    let tid = unsafe { read_cint_field(thread_addr, thread_tid_offset) };

    #[cfg(native_linux_irq_work_v6_12)]
    let native_started = crate::native_futex::ticks_now();

    loop {
        let mut hb_addr = 0usize;
        let ret = unsafe { setup(uaddr, val, fshared, q_addr, (&raw mut hb_addr) as usize) };
        if ret != 0 {
            unsafe {
                log(FUTEX_WAIT_LOG_SETUP_RET, thread_addr, tid, ret);
            }
            return ret;
        }

        #[cfg(native_linux_irq_work_v6_12)]
        let remaining = if timeout == 0 {
            0
        } else {
            timeout
                .saturating_sub(crate::native_futex::ticks_now().wrapping_sub(native_started))
                .max(1)
        };
        #[cfg(not(native_linux_irq_work_v6_12))]
        let remaining = timeout;
        let time_remain = unsafe { wait_queue(hb_addr, q_addr, remaining) };
        let unqueued = unsafe { unqueue(q_addr) };
        let mut has_pending_signal = 0;
        if unqueued != 0 && !(timeout != 0 && time_remain == 0) {
            has_pending_signal = unsafe { has_signal(thread_addr) };
        }
        let post_action = futex_wait_post_action_result(
            unqueued,
            timeout,
            time_remain,
            has_pending_signal,
            (time_remain == -ERESTARTSYS) as CInt,
        );
        if post_action == FUTEX_WAIT_POST_SUCCESS {
            unsafe {
                log(FUTEX_WAIT_LOG_SUCCESS, thread_addr, tid, 0);
                put_key(fshared, q_addr.wrapping_add(q_key_offset));
            }
            return 0;
        }
        if post_action == FUTEX_WAIT_POST_TIMEOUT {
            let ret = -ETIMEDOUT;
            unsafe {
                log(FUTEX_WAIT_LOG_TIMEOUT, thread_addr, tid, ret);
                put_key(fshared, q_addr.wrapping_add(q_key_offset));
            }
            return ret;
        }
        if post_action == FUTEX_WAIT_POST_INTERRUPT {
            let ret = -EINTR;
            unsafe {
                log(FUTEX_WAIT_LOG_INTERRUPT, thread_addr, tid, ret);
                put_key(fshared, q_addr.wrapping_add(q_key_offset));
            }
            return ret;
        }

        unsafe {
            put_key(fshared, q_addr.wrapping_add(q_key_offset));
        }
    }
}
unsafe fn read_cint_field(base: usize, offset: usize) -> CInt {
    read_volatile(base.wrapping_add(offset) as *const CInt)
}
