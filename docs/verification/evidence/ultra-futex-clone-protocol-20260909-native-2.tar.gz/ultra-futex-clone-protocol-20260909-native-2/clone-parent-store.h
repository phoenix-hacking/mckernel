	if (clone_parent_tid_store_needed_result(clone_flags)) {
		dkprintf("clone_flags & CLONE_PARENT_SETTID: 0x%lX\n",
		         parent_tidptr);

		err = setint_user((int *)parent_tidptr, new->tid);
#ifdef MCKERNEL_NATIVE_CLONE_TID
		/* Linux kernel_clone() ignores a failed parent-TID put_user. */
		err = 0;
#endif
		if (err) {
			goto release_ids;
		}
	}
