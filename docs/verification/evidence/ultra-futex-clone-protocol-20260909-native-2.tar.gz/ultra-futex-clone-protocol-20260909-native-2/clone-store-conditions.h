SYSCALL_POLICY_HELPER_SCOPE int
clone_parent_tid_store_needed_result(int clone_flags)
{
	return !!(clone_flags & CLONE_PARENT_SETTID);
}
SYSCALL_POLICY_HELPER_SCOPE int
clone_child_tid_store_needed_result(int clone_flags)
{
	return !!(clone_flags & CLONE_CHILD_SETTID);
}
