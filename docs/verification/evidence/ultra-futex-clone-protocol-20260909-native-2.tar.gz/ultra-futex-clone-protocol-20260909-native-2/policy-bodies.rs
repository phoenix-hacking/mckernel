type FutexSyscallTimeFn = unsafe extern "C" fn(CInt, CInt, *mut TimeSpec) -> CInt;
type FutexLocalTimeFn = unsafe extern "C" fn(*mut TimeSpec);
type FutexLinuxTimeFn = unsafe extern "C" fn(CInt, *mut TimeSpec) -> CInt;
type FutexNsPerTscFn = unsafe extern "C" fn() -> CULong;
type FutexDispatchFn = unsafe extern "C" fn(CULong, CInt, u32, u64, CULong, u32, u32, CInt) -> CInt;
type FutexLogFn = unsafe extern "C" fn(*const FutexLogRecord);
const EINVAL: CInt = 22;
const EFAULT: CInt = 14;
const FUTEX_WAIT: CInt = 0;
const FUTEX_REQUEUE: CInt = 3;
const FUTEX_CMP_REQUEUE: CInt = 4;
const FUTEX_WAKE_OP: CInt = 5;
const FUTEX_WAIT_BITSET: CInt = 9;
const FUTEX_PRIVATE_FLAG: CInt = 128;
const FUTEX_CLOCK_REALTIME: CInt = 256;
const FUTEX_CMD_MASK: CInt = !(FUTEX_PRIVATE_FLAG | FUTEX_CLOCK_REALTIME);
const DO_FUTEX_LOG_ENTER: CInt = 1;
const DO_FUTEX_LOG_TIMEOUT: CInt = 2;
const DO_FUTEX_LOG_ABSOLUTE_TIME: CInt = 3;
const DO_FUTEX_LOG_EXIT: CInt = 4;
#[repr(C)]
pub struct FutexLogRecord {
    event: CInt,
    flags: CInt,
    op: CInt,
    uaddr: CULong,
    val: u32,
    utime: CULong,
    uaddr2: CULong,
    val3: u32,
    fshared: CInt,
    ret: CInt,
    sec: CLong,
    nsec: CLong,
}
pub unsafe extern "C" fn futex_decode_flags_result(
    flags: CInt,
    opp: *mut CInt,
    fsharedp: *mut CInt,
) -> CInt {
    write(
        fsharedp,
        if (flags & FUTEX_PRIVATE_FLAG) != 0 {
            0
        } else {
            1
        },
    );
    write(opp, flags & FUTEX_CMD_MASK);
    0
}
pub extern "C" fn futex_requeue_val2_result(op: CInt, arg3: CULong) -> u32 {
    if op == FUTEX_CMP_REQUEUE || op == FUTEX_WAKE_OP {
        arg3 as u32
    } else {
        0
    }
}
unsafe fn do_futex_log(
    log: Option<FutexLogFn>,
    event: CInt,
    flags: CInt,
    op: CInt,
    uaddr: CULong,
    val: u32,
    utime: CULong,
    uaddr2: CULong,
    val3: u32,
    fshared: CInt,
    ret: CInt,
    sec: CLong,
    nsec: CLong,
) {
    let Some(log) = log else {
        return;
    };

    let mut record = MaybeUninit::<FutexLogRecord>::uninit();
    let ptr = record.as_mut_ptr();
    write_volatile(&raw mut (*ptr).event, event);
    write_volatile(&raw mut (*ptr).flags, flags);
    write_volatile(&raw mut (*ptr).op, op);
    write_volatile(&raw mut (*ptr).uaddr, uaddr);
    write_volatile(&raw mut (*ptr).val, val);
    write_volatile(&raw mut (*ptr).utime, utime);
    write_volatile(&raw mut (*ptr).uaddr2, uaddr2);
    write_volatile(&raw mut (*ptr).val3, val3);
    write_volatile(&raw mut (*ptr).fshared, fshared);
    write_volatile(&raw mut (*ptr).ret, ret);
    write_volatile(&raw mut (*ptr).sec, sec);
    write_volatile(&raw mut (*ptr).nsec, nsec);
    log(ptr as *const FutexLogRecord);
}
pub unsafe extern "C" fn do_futex_body_result(
    n: CInt,
    arg0: CULong,
    arg1: CULong,
    arg2: CULong,
    arg3: CULong,
    arg4: CULong,
    arg5: CULong,
    has_uti_clv: CInt,
    local_gettime_support: CInt,
    syscall_time_fn: Option<FutexSyscallTimeFn>,
    local_time_fn: Option<FutexLocalTimeFn>,
    linux_time_fn: Option<FutexLinuxTimeFn>,
    ns_per_tsc_fn: Option<FutexNsPerTscFn>,
    futex_fn: Option<FutexDispatchFn>,
    log_fn: Option<FutexLogFn>,
) -> CLong {
    #[cfg(not(native_linux_irq_work_v6_12))]
    let mut timeout: u64 = 0;
    let mut fshared: CInt = 1;
    let mut op = arg1 as CInt;
    let flags = op;
    let uaddr = arg0;
    let val = arg2 as u32;
    let utime_addr = arg3;
    #[cfg(not(native_linux_irq_work_v6_12))]
    let utime = utime_addr as *const TimeSpec;
    let uaddr2 = arg4;
    let val3 = arg5 as u32;

    futex_decode_flags_result(flags, &mut op as *mut CInt, &mut fshared as *mut CInt);

    do_futex_log(
        log_fn,
        DO_FUTEX_LOG_ENTER,
        flags,
        op,
        uaddr,
        val,
        utime_addr,
        uaddr2,
        val3,
        fshared,
        0,
        0,
        0,
    );

    #[cfg(native_linux_irq_work_v6_12)]
    let timeout = match crate::native_futex::timeout(
        flags,
        utime_addr,
        has_uti_clv,
        Some(syscall_copy_from_user_bridge),
        |clock_id| {
            if let Some(now) = crate::native_vdso::clock(clock_id) {
                return Ok(now);
            }
            let clock = syscall_time_fn.ok_or(-(EFAULT as i64))?;
            let mut now = TimeSpec { tv_sec: 0, tv_nsec: 0 };
            let error = clock(n, clock_id, &mut now);
            if error != 0 { Err(error as i64) } else { Ok(now) }
        },
        || ns_per_tsc_fn.map(|clock| clock()).ok_or(-(EINVAL as i64)),
    ) {
        Ok(timeout) => timeout,
        Err(error) => return error,
    };
    #[cfg(native_linux_irq_work_v6_12)]
    let _ = (local_gettime_support, local_time_fn, linux_time_fn);

    #[cfg(not(native_linux_irq_work_v6_12))]
    if futex_wait_timeout_needed_result(op, (!utime.is_null()) as CInt) != 0 {
        let time_sec = read_volatile(&(*utime).tv_sec);
        let time_nsec = read_volatile(&(*utime).tv_nsec);
        do_futex_log(
            log_fn,
            DO_FUTEX_LOG_TIMEOUT,
            flags,
            op,
            uaddr,
            val,
            utime_addr,
            uaddr2,
            val3,
            fshared,
            0,
            time_sec,
            time_nsec,
        );

        if has_uti_clv == 0 {
            let nsec_timeout = if futex_timeout_is_absolute_result(op) != 0 {
                let mut ats = MaybeUninit::<TimeSpec>::uninit();
                let ats_ptr = ats.as_mut_ptr();
                if local_gettime_support == 0 || (flags & FUTEX_CLOCK_REALTIME) == 0 {
                    let Some(syscall_time) = syscall_time_fn else {
                        return -(EFAULT as CLong);
                    };
                    if syscall_time(n, futex_clock_id_result(flags), ats_ptr) < 0 {
                        return -(EFAULT as CLong);
                    }
                } else {
                    let Some(local_time) = local_time_fn else {
                        return -(EFAULT as CLong);
                    };
                    local_time(ats_ptr);
                }
                let ats_sec = read_volatile(&(*ats_ptr).tv_sec);
                let ats_nsec = read_volatile(&(*ats_ptr).tv_nsec);
                futex_timeout_ns_result(op, time_sec, time_nsec, ats_sec, ats_nsec)
            } else {
                futex_timeout_ns_result(op, time_sec, time_nsec, 0, 0)
            };

            let Some(ns_per_tsc_fn) = ns_per_tsc_fn else {
                return -(EINVAL as CLong);
            };
            let ns_per_tsc = ns_per_tsc_fn();
            if ns_per_tsc == 0 {
                return -(EINVAL as CLong);
            }
            timeout = nsec_timeout.wrapping_mul(1000) / ns_per_tsc;
        } else if futex_timeout_is_absolute_result(op) != 0 {
            let Some(linux_time) = linux_time_fn else {
                return -(EFAULT as CLong);
            };
            let mut ats = MaybeUninit::<TimeSpec>::uninit();
            let ats_ptr = ats.as_mut_ptr();
            let ret = linux_time(futex_clock_id_result(flags), ats_ptr);
            if ret != 0 {
                return ret as CLong;
            }
            let ats_sec = read_volatile(&(*ats_ptr).tv_sec);
            let ats_nsec = read_volatile(&(*ats_ptr).tv_nsec);
            do_futex_log(
                log_fn,
                DO_FUTEX_LOG_ABSOLUTE_TIME,
                flags,
                op,
                uaddr,
                val,
                utime_addr,
                uaddr2,
                val3,
                fshared,
                0,
                ats_sec,
                ats_nsec,
            );
            timeout = futex_timeout_ns_result(op, time_sec, time_nsec, ats_sec, ats_nsec);
        } else {
            timeout = futex_timeout_ns_result(op, time_sec, time_nsec, 0, 0);
        }
    }

    #[cfg(native_linux_irq_work_v6_12)]
    let val2 = if op == FUTEX_REQUEUE { arg3 as u32 } else { futex_requeue_val2_result(op, arg3) };
    #[cfg(not(native_linux_irq_work_v6_12))]
    let val2 = futex_requeue_val2_result(op, arg3);
    let Some(futex) = futex_fn else {
        return -(EINVAL as CLong);
    };
    let ret = futex(uaddr, op, val, timeout, uaddr2, val2, val3, fshared);
    do_futex_log(
        log_fn,
        DO_FUTEX_LOG_EXIT,
        flags,
        op,
        uaddr,
        val,
        utime_addr,
        uaddr2,
        val3,
        fshared,
        ret,
        0,
        0,
    );
    ret as CLong
}
