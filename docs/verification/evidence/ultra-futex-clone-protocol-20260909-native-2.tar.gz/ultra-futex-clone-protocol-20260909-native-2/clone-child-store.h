	if (clone_child_tid_store_needed_result(clone_flags)) {
#ifdef MCKERNEL_NATIVE_CLONE_TID
		/* The child is held and not runnable yet. Use its explicit VM so
		 * private mappings fault/COW there, and copy the complete int by
		 * virtual page with normal user-write permissions. Like Linux's
		 * child-start put_user, a failed store does not cancel the clone.
		 */
		(void)write_process_vm(new->vm, (void *)child_tidptr,
				      &new->tid, sizeof(new->tid));
#else
		unsigned long phys;
		dkprintf("clone_flags & CLONE_CHILD_SETTID: 0x%lX\n",
				child_tidptr);

		if (ihk_mc_pt_virt_to_phys(new->vm->address_space->page_table, 
					(void *)child_tidptr, &phys)) { 
			kprintf("ERROR: looking up physical addr for child process\n");
			err = -EFAULT;
			goto release_ids;
		}
	
		*((int*)phys_to_virt(phys)) = new->tid;
#endif
	}
