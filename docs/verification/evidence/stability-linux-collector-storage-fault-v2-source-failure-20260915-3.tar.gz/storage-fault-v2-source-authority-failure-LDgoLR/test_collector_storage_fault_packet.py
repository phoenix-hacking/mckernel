import copy
import hashlib
import importlib.util
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest import mock

HERE = (Path(__file__).resolve().parent /
        "fixtures/application-collector-v1/linux-sealed-v1/storage-fault-v1")

def module(name):
    spec = importlib.util.spec_from_file_location("storage_fault_v2_" + name,
                                                  HERE / (name + ".py"))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

prepare = module("prepare")
oracle = module("oracle")
owner = module("witness_owner")

class StorageFaultV2SourceTests(unittest.TestCase):
    SOURCE_SHA = "09a63a343fa8cc9f511a26693371f5ba4f55ac5ca56fcb47abdc44759830cf1f"
    COUNTS = [21, 10, 17, 21, 16, 21, 17]
    WAITS = [0, 256, 256, 256, 32000, 32000, 32000]
    PHASES = ["post-fork", "pre-fork", "pre-fork", "post-fork",
              "post-fork", "post-fork", "pre-fork"]
    HASHES = {"generated_sha256": "a" * 64,
              "header_sha256": "b" * 64, "elf_sha256": "c" * 64}
    NONCE = "d" * 32

    def setUp(self):
        self.paths = [HERE / name for name in (
            "packet.json", "prepare.py", "inject.h", "collector.patch",
            "oracle.py", "witness_owner.py", "tests.md")]
        self.paths += [HERE.parent / "collector.c"]
        self.hashes = {path: hashlib.sha256(path.read_bytes()).hexdigest()
                       for path in self.paths}

    def tearDown(self):
        self.assertEqual({path: hashlib.sha256(path.read_bytes()).hexdigest()
                          for path in self.paths}, self.hashes)

    def test_packet_source_and_exact_generated_diff(self):
        record = prepare.packet((HERE / "packet.json").resolve())
        self.assertEqual([case["selector"] for case in record["cases"]],
                         list(range(7)))
        self.assertEqual([case["witness_packets"] for case in record["cases"]],
                         self.COUNTS)
        self.assertTrue(all(count < 32 for count in self.COUNTS))
        raw = prepare.read(prepare.SOURCE)
        self.assertEqual(hashlib.sha256(raw).hexdigest(), self.SOURCE_SHA)
        generated = prepare.generate(raw)
        patch = prepare.diff(raw, generated)
        self.assertEqual(patch, (HERE / "collector.patch").read_bytes())
        self.assertEqual(generated.count(b'#include "storage-fault-v1/inject.h"'), 1)
        for token, count in {
            b"sf_open(SF_EVENTS_CREATE": 1,
            b"sf_write(SF_REQUEST": 1,
            b"sf_sync(SF_REQUEST_SYNC": 1,
            b"sf_open(SF_REPORT_CREATE": 1,
            b"sf_flush(fd, f)": 1,
            b"sf_sync(SF_REPORT_SYNC": 1,
            b"sf_observe_reap": 1,
            b"sf_observe_eof": 1,
            b"sf_observe_cleanup_ready": 1,
            b"sf_observe_cleanup_final": 1,
            b"sf_startup()": 1,
            b"sf_child_close()": 1,
        }.items():
            self.assertEqual(generated.count(token), count, token)
        self.assertNotIn(b"#define open", generated)
        self.assertNotIn(b"#define write", generated)
        self.assertNotIn(b"#define fsync", generated)
        with self.assertRaisesRegex(ValueError, "collector hash"):
            prepare.generate(raw + b"\n")

    def test_header_protocol_and_target_only_contract(self):
        header = (HERE / "inject.h").read_text()
        for token in (
            "M02_STORAGE_FAULT_TEST_ONLY != 1", "M02_STORAGE_FAULT_CASE > 6",
            "SF_WITNESS_FD 198", "SF_PACKET_MAX 4096", "SF_PACKET_LIMIT 32",
            '"RELEASE %s\\n"', '"ACK %s %u\\n"', "packet_sequence",
            "deadline - now", "sf_sequence = 1",
            "sf_acquisition_next", "sf_open_stat_valid", "SOCK_SEQPACKET",
            "sf_observe_reap", "sf_observe_eof", "sf_observe_cleanup_ready",
            "sf_observe_cleanup_final", "sf_transport_failed"):
            self.assertIn(token, header)
        self.assertEqual(header.count("static int sf_open("), 1)
        self.assertEqual(header.count("static ssize_t sf_write("), 1)
        self.assertEqual(header.count("static int sf_sync("), 1)
        self.assertEqual(header.count("static int sf_flush("), 1)
        self.assertNotIn("#define open", header)
        self.assertNotIn("#define write", header)
        self.assertNotIn("#define fsync", header)

    def test_prepare_fresh_root_durability_and_stable_rejection(self):
        unexpected = RuntimeError("execution forbidden")
        with tempfile.TemporaryDirectory() as temporary, \
             mock.patch.object(subprocess, "run", side_effect=unexpected) as run_call, \
             mock.patch.object(subprocess, "Popen", side_effect=unexpected) as popen_call, \
             mock.patch.object(owner, "launch", side_effect=unexpected) as launch_call:
            root = (Path(temporary) / "attempt").resolve()
            result = prepare.prepare((HERE / "packet.json").resolve(), root)
            self.assertEqual(result["status"], "PREPARED_NOT_BUILT")
            self.assertFalse(result["backend_enabled"] or result["application_acceptance"])
            expected = {"source.collector.c", "storage-fault-v2-collector.c",
                        "inject.h", "generated.diff", "prepare.json"}
            self.assertEqual({path.name for path in root.iterdir()}, expected)
            before = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                      for path in root.iterdir()}
            with self.assertRaisesRegex(FileExistsError, "attempt root exists"):
                prepare.prepare((HERE / "packet.json").resolve(), root)
            self.assertEqual({path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                              for path in root.iterdir()}, before)
            run_call.assert_not_called()
            popen_call.assert_not_called()
            launch_call.assert_not_called()

    def packet(self, selector, sequence, kind, phase=None, **extra):
        value = {"schema_version": 2, "nonce": self.NONCE,
                 "selector": selector, "sequence": sequence, "kind": kind,
                 "phase": phase or self.PHASES[selector],
                 "monotonic_ns": 1000 + sequence, "collector_pid": 50,
                 "collector_startticks": 60, "source_sha256": self.SOURCE_SHA,
                 **self.HASHES}
        value.update(extra)
        return value

    def packets(self, selector):
        count = self.COUNTS[selector]
        post = selector in (0, 3, 4, 5)
        observation_count = 6 if post else 0
        body_count = count - 1 - observation_count
        bind_count = 1 if selector in (1, 4) else 0
        pair_count = (body_count - bind_count) // 2
        values = [self.packet(selector, 0, "READY", phase="pre-fork")]
        for pair in range(pair_count):
            site = "report-sync" if (selector in (5, 6) and pair == pair_count - 1) \
                else "site-%d" % pair
            common = {"site": site, "object": "request.bin", "occurrence": 1}
            values.append(self.packet(selector, len(values), "BEFORE",
                                      **common, **{"return": None,
                                      "errno_authoritative": False, "errno": None}))
            failed = site == "report-sync" and selector in (5, 6)
            values.append(self.packet(selector, len(values), "AFTER",
                                      **common, **{"return": -1 if failed else 0,
                                      "errno_authoritative": failed,
                                      "errno": 5 if failed else None}))
        if bind_count:
            values.append(self.packet(selector, len(values), "BIND",
                                      site="report-create", object="report.json",
                                      occurrence=1, acquisition=2))
        if post:
            values.append(self.packet(selector, len(values), "REAP",
                                      raw_wait_status=0))
            for stream in range(3):
                values.append(self.packet(selector, len(values), "EOF", stream=stream))
            values.append(self.packet(selector, len(values), "CLEANUP_READY",
                                      echild=True, eofs=[True, True, True]))
            values.append(self.packet(selector, len(values), "CLEANUP_FINAL",
                                      cleanup_start_ns=10, cleanup_finished_ns=20,
                                      cleanup_deadline_ns=30, cleanup_complete=True))
        self.assertEqual(len(values), count)
        return values

    def write_fixture(self, root, selector):
        root.mkdir()
        collection = root / "collection"
        collection.mkdir()
        report_status = oracle.EXPECTED[selector]
        if report_status[2] != "absent":
            (collection / "report.json").write_text(json.dumps({
                "status": report_status[3], "first_failure": report_status[4],
                "first_failure_errno": report_status[5]}, separators=(",", ":")))
        request = oracle.PREFIX if selector in (2, 6) else b"request"
        (collection / "request.bin").write_bytes(request)
        owner_result = {"schema_version": 2, "selector": selector,
            "nonce": self.NONCE, "raw_wait_status": self.WAITS[selector],
            "owner_failure": None, "cleanup_complete": True,
            "application_acceptance": False, "hashes": self.HASHES,
            "request_artifact_sha256": hashlib.sha256(request).hexdigest()}
        (root / "owner-result.json").write_text(
            json.dumps(owner_result, sort_keys=True, separators=(",", ":")))
        rows = [{"packet": packet, "receipt_monotonic_ns": 2000 + index}
                for index, packet in enumerate(self.packets(selector))]
        rows.append({"packet": {"kind": "OWNER_RESULT", **owner_result},
                     "receipt_monotonic_ns": 2000 + len(rows)})
        (root / "witness.jsonl").write_bytes(b"".join(
            json.dumps(row, sort_keys=True, separators=(",", ":")).encode() + b"\n"
            for row in rows))

    def mutate(self, selector, mutation, message):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "case"
            self.write_fixture(root, selector)
            mutation(root)
            with self.assertRaisesRegex((ValueError, OSError), message):
                oracle.validate(root, selector)

    def test_oracle_seven_positive_fixtures(self):
        unexpected = RuntimeError("execution forbidden")
        with mock.patch.object(subprocess, "run", side_effect=unexpected) as run_call, \
             mock.patch.object(subprocess, "Popen", side_effect=unexpected) as popen_call, \
             mock.patch.object(owner.os, "fork", side_effect=unexpected) as fork_call:
            for selector in range(7):
                with self.subTest(selector=selector), tempfile.TemporaryDirectory() as temporary:
                    root = Path(temporary) / "case"
                    self.write_fixture(root, selector)
                    self.assertTrue(oracle.validate(root, selector))
            run_call.assert_not_called()
            popen_call.assert_not_called()
            fork_call.assert_not_called()

    def rewrite_json(self, path, edit):
        value = json.loads(path.read_text())
        edit(value)
        path.write_text(json.dumps(value, sort_keys=True, separators=(",", ":")))

    def rewrite_journal(self, path, edit):
        rows = [json.loads(line) for line in path.read_text().splitlines()]
        edit(rows)
        path.write_bytes(b"".join(json.dumps(row, sort_keys=True,
            separators=(",", ":")).encode() + b"\n" for row in rows))

    def test_oracle_independent_negative_matrix(self):
        self.mutate(0, lambda root: self.rewrite_json(root / "owner-result.json",
                    lambda value: value.__setitem__("raw_wait_status", 1)), "owner result")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: rows[1]["packet"].__setitem__("sequence", 7)), "witness identity")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: rows[0]["packet"].__setitem__("nonce", "e" * 32)), "witness identity")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: rows[0]["packet"].__setitem__("elf_sha256", "0" * 64)), "generated hash")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: rows.pop(-2)), "witness packet count")
        self.mutate(0, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: rows.insert(2, copy.deepcopy(rows[1]))), "witness packet count")
        self.mutate(0, lambda root: self.rewrite_json(root / "collection/report.json",
                    lambda value: value.__setitem__("status", "COLLECTOR_ERROR")), "report result")
        self.mutate(4, lambda root: (root / "collection/report.json").write_text("{}"),
                    "fabricated report")
        self.mutate(2, lambda root: (root / "collection/request.bin").write_bytes(b"BROKEN!"),
                    "request prefix")
        self.mutate(5, lambda root: self.rewrite_journal(root / "witness.jsonl",
                    lambda rows: next(row for row in rows
                        if row["packet"].get("site") == "report-sync" and
                        row["packet"].get("kind") == "AFTER" and
                        row["packet"].get("return") == -1)["packet"].__setitem__("errno", 0)),
                    "report sync failure")
        self.mutate(0, lambda root: (root / "witness.jsonl").write_bytes(
                    (root / "witness.jsonl").read_bytes()[:-1]), "journal terminal newline")

    def test_durable_journal_and_protocol_helpers(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "journal"
            journal = owner.DurableJournal(root)
            journal.append({"kind": "READY"}, 1)
            journal.close()
            raw = (root / "witness.jsonl").read_bytes()
            self.assertTrue(raw.endswith(b"\n"))
            self.assertEqual(json.loads(raw)["packet"], {"kind": "READY"})
        packet = self.packet(0, 0, "READY", phase="pre-fork")
        owner.validate_common(packet, self.NONCE, 0, 0,
                              {"source_sha256": self.SOURCE_SHA, **self.HASHES})
        wrong = copy.deepcopy(packet)
        wrong["sequence"] = 1
        with self.assertRaisesRegex(ValueError, "witness identity"):
            owner.validate_common(wrong, self.NONCE, 0, 0,
                                  {"source_sha256": self.SOURCE_SHA, **self.HASHES})

if __name__ == "__main__":
    unittest.main()
