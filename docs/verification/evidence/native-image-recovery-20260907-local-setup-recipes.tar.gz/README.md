# Local McKernel development environment

Source checkout: `/home/holden/mckernel`, branch
`codex/local-native-staging-repair`, starting at
`24a151fef5b9fcf303fdbb8cf9762340cd4100fd`.

Setup verified on 2026-09-06 (America/Los_Angeles): both installed containers
passed isolation and resource-limit checks; all 23 selected native tests
passed (including the 41-case embedded adapter fixture); the compatibility
container compiled, linked, and executed a C/Rust ABI probe. QEMU 10.1.0 guest
preparation passed without booting. A two-second watchdog stopped a sleeping
test container and left zero McKernel worker tasks. See `setup-status.json`
and `logs/*-setup-validation.log` for the recorded results. No repository
implementation changes or GitHub writes were made during setup.

## Verification boundary

Run project source, compiler, and mock checks with `bin/mckernel-container`.
It runs as UID 1000 inside an offline container, drops every Linux capability,
enables no-new-privileges, and mounts the image root, source checkout, and
guest images read-only. Only the dedicated scratch filesystem is writable.
No host block devices, McKernel devices, KVM device, Docker socket, or host
network are passed into the container. A container still shares the Ubuntu
kernel: experimental kernel execution and module tests belong in a disposable
QEMU guest inside the container.

The resource ceiling is shared through the `mckernel-dev` cgroup:

- Four logical CPUs, with worker affinity restricted to CPU IDs 2–5.
- 12 GiB aggregate memory, with no additional swap allowance.
- 512 tasks, including descendant processes and threads.
- A dedicated 60 GiB ext4 scratch filesystem; filesystem metadata consumes
  part of that capacity. Guest overlays and build output must stay here.
- Three-hour command watchdog and explicit container stop/removal cleanup.
- One verification invocation at a time.

Image installation steps use the same four CPUs and cgroup parent with a
smaller 8 GiB per-step memory ceiling. Container images and pinned toolchains
are installed outside the scratch filesystem and consume additional host disk.

## Installed tools and recipes

- `toolchains/`: project-local Rust 1.92.0 and nightly-2026-02-19, with
  rustfmt and rust-src. This upstream Rust 1.92 is for local editing/helpers;
  native platform validation uses the Red Hat compiler in the Rocky image.
- `venv/`: separate Python environment for editing and development utilities.
- `setup/docker/Dockerfile.native`: Rocky 10.2, Red Hat Rust 1.92.0,
  LLVM/Clang 21.1.8, bindgen 0.72.1, native build dependencies and QEMU.
- `setup/docker/Dockerfile.compat`: Rocky 8.10 compatibility dependencies
  and nightly-2026-02-19. Kernel-devel is the repository-resolved Rocky 8.10
  build target, not the Ubuntu host kernel.
- `logs/image-*.json`: installed image identities; the runner uses their
  immutable image IDs, rather than trusting a mutable image tag.
- `guests/`: checksum-verified Rocky 8.10 cloud image, mounted read-only.
- `logs/`: setup, isolation, compiler and test results.

The local Dockerfiles pin their base images and required compiler versions.
They do not replace the repository's stricter source/RPM snapshot verification
or establish production readiness.

## Commands

For editor/tool access only (does not modify shell startup files):

```bash
source /home/holden/mckernel-work/env.sh
```

Run a source or mock test inside the isolated native environment:

```bash
/home/holden/mckernel-work/bin/mckernel-container native \
  python3 -B -m unittest -v scripts.tests.test_ihk_os_runtime
```

Prepare and print the VM configuration without booting it:

```bash
/home/holden/mckernel-work/bin/mckernel-vm-plan
```

The guest plan uses TCG, four virtual CPUs, 8 GiB guest RAM within the 12 GiB
container ceiling, a disposable 40 GiB overlay on the scratch filesystem, and
SSH bound to loopback inside the container. No host directories are exported
to the guest. Actual guest boot/runtime checks require explicit approval for
the particular run under the repository's `AGENTS.md`; setup alone does not
claim a successful boot.

## Host state and restart

Setup installs utilities, creates cgroups, and mounts a dedicated loopback
filesystem. It does not alter the host kernel, bootloader, host CPU online
state, sudoers, group membership, Docker configuration, or fstab. The cgroup
and scratch mount are transient and disappear after a host reboot; launchers
refuse to run when these controls are absent. Restore them with:

```bash
sudo /usr/bin/bash /home/holden/mckernel-work/setup/setup-host.sh
```

The setup script never formats an existing scratch image and rejects package
removals. Keep the existing `pkgconf` installation. Do not run McKernel's
module-loading, CPU-reservation, ioctl probes, or poweroff helpers directly on
the Ubuntu host. The `mckernel-limited` utility is an internal resource helper,
not a replacement for the container/VM isolation boundary.

Next project deliverable: review the completed original CI artifacts, repair
the link-closure validator's missing `os_runtime.rs` file/dependency entries,
and add a regression test using the stager's actual inputs. Retain the
production tracker at 350/10,000 until its acceptance gates pass.

Rust preservation/accounting update (2026-09-06): the repository's
`docs/verification/rust-reuse-plan.md` now maps the existing Rust implementation
to native adaptation work, backed by a revision-bound file/checksum inventory.
Future implementation changes must identify existing source symbols and record
their reuse/adaptation before writing replacement logic. The inventory includes
the existing mcctrl helpers and preserves the original Rust build paths.
