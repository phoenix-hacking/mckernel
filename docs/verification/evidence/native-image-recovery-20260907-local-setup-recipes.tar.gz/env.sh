# Source explicitly for McKernel work; existing shell startup files are unchanged.
export MCKERNEL_WORK=/home/holden/mckernel-work
export CARGO_HOME="$MCKERNEL_WORK/toolchains/cargo"
export RUSTUP_HOME="$MCKERNEL_WORK/toolchains/rustup"
export RUSTUP_TOOLCHAIN=1.92.0
export MCKERNEL_RUSTC_1_92="$RUSTUP_HOME/toolchains/1.92.0-x86_64-unknown-linux-gnu/bin/rustc"
export RUSTC="$MCKERNEL_RUSTC_1_92"
export PATH="$MCKERNEL_WORK/bin:$MCKERNEL_WORK/venv/bin:$CARGO_HOME/bin:/usr/bin:/bin:$PATH"
export CARGO_BUILD_JOBS=4
export CMAKE_BUILD_PARALLEL_LEVEL=4
export MAKEFLAGS=-j4
export PYTHONDONTWRITEBYTECODE=1
