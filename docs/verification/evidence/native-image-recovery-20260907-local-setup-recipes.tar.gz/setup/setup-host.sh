#!/usr/bin/env bash
# Run once with sudo. Does not change sudoers, group membership, boot settings,
# host kernel/modules, Docker configuration, or fstab. Re-run after a host reboot
# to restore the transient cgroups and scratch mount.
set -euo pipefail
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
test "$(id -u)" = 0
work=/home/holden/mckernel-work
test "$(id -u holden)" = 1000
test -d "$work/setup"
test ! -L "$work/setup"
exec > >(tee -a "$work/logs/host-setup.log") 2>&1
apt_directory=$(mktemp -d /tmp/mckernel-apt.XXXXXXXX)
trap 'rm -rf -- "$apt_directory"' EXIT
cat > "$apt_directory/sources.list" <<'SOURCES'
deb http://archive.ubuntu.com/ubuntu focal main universe restricted multiverse
deb http://archive.ubuntu.com/ubuntu focal-updates main universe restricted multiverse
deb http://security.ubuntu.com/ubuntu focal-security main universe restricted multiverse
SOURCES
apt_options=(-o "Dir::Etc::sourcelist=$apt_directory/sources.list" -o Dir::Etc::sourceparts=-)
apt-get "${apt_options[@]}" update
DEBIAN_FRONTEND=noninteractive apt-get "${apt_options[@]}" install -y --no-remove --no-upgrade --no-install-recommends \
  cgroup-tools cloud-image-utils jq python3-venv bc bison flex libelf-dev \
  libnuma-dev libssl-dev binutils-dev zstd unzip

# This host uses cgroup v1. Only process attachment is delegated to holden;
# resource-control files remain root-owned.
for controller in cpu memory pids; do
    test -d "/sys/fs/cgroup/$controller"
done
cgcreate -t holden:holden -g cpu,memory,pids:mckernel-dev
cgset -r cpu.cfs_period_us=100000 -r cpu.cfs_quota_us=400000 mckernel-dev
cgset -r memory.use_hierarchy=1 -r memory.limit_in_bytes=12884901888 -r memory.swappiness=0 mckernel-dev
if test -f /sys/fs/cgroup/memory/mckernel-dev/memory.memsw.limit_in_bytes; then
    cgset -r memory.memsw.limit_in_bytes=12884901888 mckernel-dev
fi
cgset -r pids.max=512 mckernel-dev

# Dedicated fixed-capacity filesystem for generated build files and guest
# overlays. Only format a newly created regular file, never an existing image.
scratch="$work/scratch"
disk="$work/scratch.ext4"
mkdir -p "$scratch"
if ! test -e "$disk"; then
    available=$(df --output=avail -B1 "$work" | tail -n 1 | tr -d ' ')
    test "$available" -gt 128849018880
    (set -o noclobber; : > "$disk")
    chmod 0600 "$disk"
    fallocate -l 60G "$disk"
    mkfs.ext4 -q -F -L mckernel-scratch -E nodiscard "$disk"
fi
test -f "$disk"
test ! -L "$disk"
test "$(stat -c %s "$disk")" = 64424509440
test "$(blkid -p -s LABEL -o value "$disk")" = mckernel-scratch
if ! mountpoint -q "$scratch"; then
    mount -o loop,nodev,nosuid "$disk" "$scratch"
fi
test "$(findmnt -n -o LABEL --target "$scratch")" = mckernel-scratch
chown holden:holden "$scratch"
chmod 0700 "$scratch"
cgget -r cpu.cfs_quota_us -r memory.limit_in_bytes -r pids.max mckernel-dev
df -h "$scratch"
printf '%s\n' 'Host utilities, 4-CPU/12-GiB/512-task cgroup, and 60-GiB scratch filesystem ready.'
