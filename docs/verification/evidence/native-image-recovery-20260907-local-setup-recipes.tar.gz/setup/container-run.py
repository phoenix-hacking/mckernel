#!/usr/bin/env python3
"""Run development commands unprivileged inside a bounded, offline container."""
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import uuid

WORK = Path('/home/holden/mckernel-work')
DOCKER = '/usr/bin/docker'


def main():
    if os.geteuid() != 0:
        raise SystemExit('Use bin/mckernel-container (sudo is required).')
    if len(sys.argv) < 3 or sys.argv[1] not in ('native', 'compat'):
        raise SystemExit('Usage: mckernel-container native|compat COMMAND [ARG ...]')
    target, command = sys.argv[1], sys.argv[2:]
    duration = int(os.environ.get('MCKERNEL_TIMEOUT_SECONDS', '10800'))
    if not 1 <= duration <= 10800:
        raise SystemExit('Timeout must be between 1 and 10800 seconds')
    expected = {
        '/sys/fs/cgroup/cpu/mckernel-dev/cpu.cfs_period_us': '100000',
        '/sys/fs/cgroup/cpu/mckernel-dev/cpu.cfs_quota_us': '400000',
        '/sys/fs/cgroup/memory/mckernel-dev/memory.limit_in_bytes': '12884901888',
        '/sys/fs/cgroup/memory/mckernel-dev/memory.use_hierarchy': '1',
        '/sys/fs/cgroup/pids/mckernel-dev/pids.max': '512',
    }
    for path, value in expected.items():
        if Path(path).read_text().strip() != value:
            raise SystemExit('Resource control differs: ' + path)
    subprocess.run(['/usr/bin/mountpoint', '-q', str(WORK / 'scratch')], check=True)
    label = subprocess.check_output(['/usr/bin/findmnt', '-n', '-o', 'LABEL', '--target', str(WORK / 'scratch')], text=True).strip()
    if label != 'mckernel-scratch':
        raise SystemExit('Dedicated scratch filesystem is missing')
    manifest = json.loads((WORK / ('logs/image-' + target + '.json')).read_text())
    image = manifest[0]['Id']
    for directory in ('tmp', 'home-' + target):
        path = WORK / 'scratch' / directory
        path.mkdir(exist_ok=True)
        os.chown(path, 1000, 1000)
    lock = open('/run/lock/mckernel-development.lock', 'w')
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise SystemExit('Another McKernel verification is already running')
    name = 'mckernel-dev-' + uuid.uuid4().hex[:12]
    args = [DOCKER, 'run', '--rm', '--init', '--name', name,
            '--cpus=4', '--cpuset-cpus=2-5', '--cgroup-parent=/mckernel-dev',
            '--memory=12g', '--memory-swap=12g', '--pids-limit=512',
            '--cap-drop=ALL', '--security-opt=no-new-privileges',
            '--read-only', '--network=none', '--user=1000:1000',
            '--ulimit', 'core=0', '--ulimit', 'nofile=4096:4096',
            '--tmpfs', '/tmp:rw,nodev,nosuid,size=256m',
            '--mount', 'type=bind,src=/home/holden/mckernel,dst=/workspace,readonly',
            '--mount', 'type=bind,src=' + str(WORK / 'scratch') + ',dst=/work',
            '--mount', 'type=bind,src=' + str(WORK / 'guests') + ',dst=/guests,readonly',
            '--mount', 'type=bind,src=' + str(WORK / ('scratch/home-' + target)) + ',dst=/home/builder',
            '--env', 'TMPDIR=/work/tmp', '--workdir=/workspace', image] + command
    def interrupted(signum, frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, interrupted)
    process = None
    try:
        process = subprocess.Popen(args)
        result = process.wait(timeout=duration)
    except (subprocess.TimeoutExpired, KeyboardInterrupt):
        result = 124
    finally:
        # Only this invocation's randomly named container is touched.
        for cleanup in ([DOCKER, 'stop', '--time=20', name], [DOCKER, 'rm', '--force', name]):
            try:
                subprocess.run(cleanup, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30)
            except subprocess.TimeoutExpired:
                print('Docker cleanup timed out for ' + name, file=sys.stderr)
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
    return result


if __name__ == '__main__':
    sys.exit(main())
