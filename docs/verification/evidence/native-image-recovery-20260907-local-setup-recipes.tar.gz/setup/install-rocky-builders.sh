#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
test "$(id -u)" = 0
work=/home/holden/mckernel-work
docker info --format '{{json .}}' > "$work/logs/docker-info.json"
python3 - "$work/logs/docker-info.json" <<'PY'
import json, sys
d = json.load(open(sys.argv[1]))
for key in ('MemoryLimit', 'SwapLimit', 'CpuCfsQuota', 'CPUSet', 'PidsLimit'):
    if d.get(key) is not True:
        raise SystemExit('Required Docker resource control unavailable: ' + key)
if d.get('CgroupDriver') != 'cgroupfs':
    raise SystemExit('This setup requires the verified cgroupfs parent; refusing a different driver')
print('Docker memory, swap, CPU quota and PID controls supported')
PY
cp "$work/cache/rustup-init-1.29.0" "$work/setup/docker/rustup-init-1.29.0"
cp /usr/bin/cloud-localds "$work/setup/docker/cloud-localds"
for target in native compat; do
    # The legacy builder supports these per-build-step resource limits.
    DOCKER_BUILDKIT=0 docker build --memory=8g --memory-swap=8g \
        --cpu-period=100000 --cpu-quota=400000 --cpuset-cpus=2-5 \
        --cgroup-parent=/mckernel-dev \
        --file "$work/setup/docker/Dockerfile.$target" \
        --tag "mckernel-dev:$target" "$work/setup/docker" \
        > "$work/logs/install-$target.log" 2>&1
    docker image inspect "mckernel-dev:$target" > "$work/logs/image-$target.json"
    printf '%s\n' "Installed mckernel-dev:$target"
done
chown holden:holden "$work"/logs/docker-info.json "$work"/logs/install-*.log "$work"/logs/image-*.json
