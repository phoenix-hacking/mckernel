#!/usr/bin/env bash
set -euo pipefail
work=/home/holden/mckernel-work
export CARGO_HOME="$work/toolchains/cargo"
export RUSTUP_HOME="$work/toolchains/rustup"
installer="$work/cache/rustup-init-1.29.0"
printf '%s  %s\n' 4acc9acc76d5079515b46346a485974457b5a79893cfb01112423c89aeb5aa10 "$installer" | sha256sum --check --strict
test "$(stat -c %s "$installer")" = 20838840
chmod 0755 "$installer"
"$installer" -y --profile minimal --default-toolchain none --no-modify-path
"$CARGO_HOME/bin/rustup" set auto-self-update disable
"$CARGO_HOME/bin/rustup" toolchain install 1.92.0 --profile minimal --component rust-src,rustfmt
"$CARGO_HOME/bin/rustup" toolchain install nightly-2026-02-19 --profile minimal --component rust-src,rustfmt
"$CARGO_HOME/bin/rustup" run 1.92.0 rustc -Vv
"$CARGO_HOME/bin/rustup" run nightly-2026-02-19 rustc -Vv
