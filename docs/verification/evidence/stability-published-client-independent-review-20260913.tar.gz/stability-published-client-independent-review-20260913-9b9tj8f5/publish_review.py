import pathlib,json,hashlib,shutil,stat,tarfile,difflib,re
base=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/home/holden/mckernel');source=repo/'scripts/tests/fixtures/stability-transport-fault/owner-published-hold-v1'
def sha(data):return hashlib.sha256(data).hexdigest()
def inventory(root):
 rows=[]
 for p in [root]+sorted(root.rglob('*')):
  s=p.lstat();r={'path':'.' if p==root else p.relative_to(root).as_posix(),'mode':stat.S_IMODE(s.st_mode)}
  if stat.S_ISDIR(s.st_mode):r['type']='directory'
  else:
   assert stat.S_ISREG(s.st_mode),str(p)
   b=p.read_bytes();r.update(type='file',size=len(b),sha256=sha(b))
  rows.append(r)
 return rows
bindings=[]
for label,old in [('author-first-source','/tmp/stability-published-client-source-20260913-sm0hlw0c'),('author-second-source','/tmp/stability-published-client-source2-20260913-rsb2qjo5')]:
 p=pathlib.Path(old);before=inventory(p);shutil.copytree(p,base/label,copy_function=shutil.copy2);assert inventory(p)==inventory(base/label)==before
 bindings.append({'original':old,'retained':label,'members':before})
final=base/'final-source';shutil.copytree(source,final,copy_function=shutil.copy2);assert inventory(source)==inventory(final)
for name in ['controller.c','phase_client.h']:
 a=(final/(name+'.original')).read_bytes();b=(final/name).read_bytes()
 for x,y,direction in [(a,b,'forward'),(b,a,'inverse')]:
  want=''.join(difflib.unified_diff(x.decode().splitlines(True),y.decode().splitlines(True),fromfile=name,tofile=name,n=0)).encode()
  assert want==(final/(name+'.'+direction+'.patch')).read_bytes()
# Static literal cross-binding only. Do not import/run the generator or validator.
spec=json.loads((final/'metadata-expectations.json').read_bytes());lines=[s for s in (final/'metadata_vectors.h').read_text().splitlines() if s.startswith(' {.name=')]
assert len(lines)==spec['case_count']==81

def fields(s):
 result={}
 for name,v in re.findall(r'\.(\w+)=(\{[^}]*\}|UINT64_C\(\d+\)|-?\d+|true|false)',s):
  if v.startswith('{'):result[name+'_hex']=bytes(int(w,16) for w in re.findall(r'0x[0-9a-f]{2}',v)).hex()
  elif v in ('true','false'):result[name]=v=='true'
  elif v.startswith('UINT64_C'):result[name]=int(v[9:-1])
  else:result[name]=int(v)
 return result
for line,row in zip(lines,spec['cases']):
 assert re.search(r'\.name="([^"]+)"',line).group(1)==row['name']
 assert int(re.search(r'\.phase=(\d+)',line).group(1))==row['phase']
 assert fields(line.split('.identity={',1)[1].split('},.request=',1)[0])==row['identity']
 assert fields(line.split('.after={',1)[1][:-3])==row['expected_after']
 raw=bytes(int(v,16) for v in re.findall('0x[0-9a-f]{2}',line.split('.request={',1)[1].split('},.observation=',1)[0]));assert len(raw)==256 and raw.hex()==row['request_hex']
 ob=fields(line.split('.observation={',1)[1].split('},.expected=',1)[0]);reply=ob.pop('reply_hex');assert len(bytes.fromhex(reply))==256 and reply==row['reply_hex'] and ob==row['collection']
 assert int(re.search(r'\.expected=(-?\d+)',line).group(1))==row['expected_result']
 assert (re.search(r'\.consumed=(true|false)',line).group(1)=='true')==row['expected_consumed']
assert sha((final/'controller.c').read_bytes())=='b8360dc502d53ee537e462815657d85510488a1820c10501c38cb49150b52d3c'
assert sha((final/'phase_client.h').read_bytes()).startswith('929f9fd0')
assert sha((final/'metadata_harness.c').read_bytes())=='42fd6e18c86cde6bf63326d301128e4ba20f061cbd23341b467d5c29ecb49bcc'
review={'schema_version':1,'status':'PASS_BOUNDED_C_CLIENT_CONTROLLER_AND_METADATA_HARNESS_SOURCE_REVIEW_ONLY','final_files':inventory(final),'original_to_retained':bindings,'case_count':81,'checks':[
'Actual originals match frozen polling-corrected controller2aa11489 and phase-v1 client03f17078; both exact forward/inverse zero-context patches independently match complete source bytes.',
'Private native version2/command0xc100f502, fixed256-byte fields and separate ioctl/UART/snapshot sequences match final native source review061d3969. Actual original key/nonce/generation and full expected request tail/digest now checked, including jointly changed request/reply identity.',
'Real blocked read input precedes original worker/ticks and complete RET sample, held-status query, STF2 AcceptedReturn capture/ACK and one-shot release submission. Native RET remains actual errno/value/timing authority; UNKNOWN running/incomplete samples cannot imply return.',
'Release_possible latches before any artifact/fork/ioctl; release never yields retry, including exact untouched EAGAIN or ambiguous child/copyout failure. Host independently must latch before first ACK transmission and reject every subsequent original-response physical read.',
'Full metadata output, consumed versus unchanged sequences, immutable key/timer/held timestamp/barrier counts and monotonic host-hold counts checked. Kernel timestamp interval must fit actual userspace call interval. Release/ACK uses original coarse deadline and mode3 reserve; later delays can conservatively fail and never reset native timer.',
'Op_call retains actual probe raw wait, response/probe bytes and metadata; direct child bounded5s collection plus separate15s cleanup is unchanged. Controller checks its own phase deadline after the full call/artifact work. Existing launcher WNOWAIT/EOF/raw streams and cleanup source unchanged.',
'All81 C literal request/reply arrays, identity/observation fields, full expected persistent state and result/consumed flags statically cross-bind JSON. Manual branch review found no expectation mismatch; original generator and pre-execution SELECT-key correction preserved.',
'Harness invokes actual op_validate only; no ioctl/fork/controller main/guest. Complete actual post-call identity+observation structs now retained before any mismatch exit; padding remains opaque. Five files per case are fsynced before line output; external supervisor must check full stdout/empty stderr/raw0 and complete cleanup.'
], 'findings_addressed':[
{'finding':'README mixed terminal operation numbers with snapshot sequence numbers.','resolution':'Explicit operations2/3 and snapshot sequences3/4.'},
{'finding':'Validator trusted request builder identity and release-tail construction; jointly changed request/reply identities were not independently rejected.','resolution':'Full op_request_valid checks expected identity/reserved tail/digest and13 dedicated negatives.'},
{'finding':'Harness compared complete persistent identity but omitted failure-only differing fields from artifacts.','resolution':'Complete post-call identity.bin and observation.bin retained before report; no expectations changed.'}
], 'definite_findings_remaining':[], 'limitations':[
'No compile/test/ioctl/fork/controller or guest execution in this review lane; static metadata parsing is not a test run.',
'81 cases cover metadata validation only. Initialization/digest helpers, actual child/ioctl collection and STF2 UART/host/QMP integration remain independently required.',
'Mode3 eight later sameOS HELLO runs and version2 AfterEightHello client remain uncomposed; new held-record/physical joins and exact compiled stack/build bindings are required before eligible guests.',
'Original permanent-backpressure polling false observation remains rejected and preserved; this source review does not repair historical reports or grant complete controller/runtime acceptance.',
'Native timers/ownership/physical evidence and raw payload outcomes remain separate. No catalog/application, whole transport, physical full ring or production gate credit.'
], 'compiler_execution':False,'tests_executed':False,'guest_execution':False,'subject_helpers_imported_or_executed':False,'application_acceptance':False,'transport_acceptance':False,'production_gate_credit':False}
(base/'review-final.json').write_text(json.dumps(review,indent=2,sort_keys=True)+'\n')
entries=inventory(base)
archive=repo/'docs/verification/evidence/stability-published-client-independent-review-20260913.tar.gz';pub=repo/'docs/verification/stability-published-client-independent-review-20260913.json'
assert not archive.exists() and not pub.exists()
with tarfile.open(archive,'x:gz') as tar:
 for row in entries:
  p=base if row['path']=='.' else base/row['path']; name=base.name if row['path']=='.' else base.name+'/'+row['path'];tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(entries)==len({m.name for m in members})
 for row,m in zip(entries,members):
  name=base.name if row['path']=='.' else base.name+'/'+row['path'];assert m.name==name and m.mode==row['mode']
  if row['type']=='directory':assert m.isdir()
  else:assert m.isfile() and m.size==row['size'] and sha(tar.extractfile(m).read())==row['sha256']
assert inventory(base)==entries
record={'schema_version':1,'status':review['status'],'review':{'retained':base.name+'/review-final.json','sha256':sha((base/'review-final.json').read_bytes())},'archive':{'path':str(archive.relative_to(repo)),'size':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(entries),'all_bytes_types_modes_membership_verified':True},'files':entries,'application_acceptance':False,'transport_acceptance':False,'production_gate_credit':False,'test_execution':False,'guest_execution':False}
pub.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(json.dumps({'path':str(pub),'sha256':sha(pub.read_bytes()),'archive':record['archive'],'review':record['review']},indent=2))
