# Storage-fault-v2 source tests

This is source-only infrastructure. It does not release a build or root run.

- Bind the exact collector, packet, header, generated source and complete diff.
- Require guard value one, selectors 0–6, target-only operation adapters and no
  global syscall replacement.
- Require packet schedules 21/10/17/21/16/21/17 below the hard bound 32.
- Validate READY sequence zero and exactly one RELEASE; ordinary records begin
  at one and receive durable ACKs.
- Validate distinct BEFORE/AFTER/BIND acquisition schemas and legitimate reuse
  of retired numeric descriptors.
- Prove collector-origin REAP, three EOF, CLEANUP_READY and CLEANUP_FINAL records
  for post-fork selectors, with none fabricated for pre-fork selectors.
- Prove selector 2/6 retains exactly `41435251303030` and its independent hash.
- Prove fresh-root rejection is stable and leaves all existing bytes unchanged.
- Start every oracle negative from a fresh valid fixture and mutate one distinct
  field: selector/wait; sequence/seam; identity/hashes/nonce; prefix; report
  presence/durability; EOF/reap/ECHILD/cleanup; first versus secondary failure;
  journal truncation/extra/oversize; and file/parent fsync state.
- Mock compiler, build, root, collector and payload execution. Passing these
  checks earns no storage-fault, application or production acceptance.
