"""Validate exact native metadata/RPC bodies against unchanged C and guest Rust."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, re, shutil, subprocess, sys
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2,3,4,5}
repo = Path('/workspace')
out = Path('/work/native-sysfs-request-tests-20260907-' + sys.argv[1]); out.mkdir()
source = out / 'source'
fixture = source / 'scripts/tests/fixtures'
record = dict(status='running', started_utc=datetime.now(timezone.utc).isoformat(), commands=[],
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    production_gate_credit=False, sysfs_service_completed=False, mckernel_boot_proven=False,
    scope='Actual native metadata and RPC state with unchanged C layouts and extracted guest response bodies')

def identity(path):
    data=path.read_bytes(); return dict(path=str(path),size=len(data),sha256=hashlib.sha256(data).hexdigest())

def run(name,args):
    print('RUN',name,flush=True)
    with (out/(name+'.log')).open('wb') as log: result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=name,command=args,exit_code=result.returncode))
    assert result.returncode==0,(name,(out/(name+'.log')).read_text()[-14000:])

def extract(data,name):
    match=re.search(r'(?m)^(?:pub )?(?:unsafe )?(?:extern "C" )?fn '+name+r'\(',data)
    assert match,name
    start=match.start();opening=data.index('{',start);depth=1;end=opening+1
    while depth:
        depth+=(data[end]=='{')-(data[end]=='}');end+=1
    body=data[start:end]
    record.setdefault('guest_bodies',[]).append(dict(name=name,start_byte=len(data[:start].encode()),end_byte=len(data[:end].encode()),sha256=hashlib.sha256(body.encode()).hexdigest()))
    return body

try:
    shutil.copyfile(__file__,out/'helper.py')
    names=['host-kernel/native-rust/abi/sysfs_request.rs','host-kernel/native-rust/sysfs_rpc.rs',
        'kernel/rust/abi.rs','kernel/rust/object_helpers.rs','executer/kernel/mcctrl/sysfs_msg.h',
        'scripts/tests/fixtures/native-sysfs-request-layout.c','scripts/tests/fixtures/native-sysfs-request-protocol.rs']
    for name in names:
        original=out/'original-inputs'/name;original.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,original)
        target=source/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,target)
    record['inputs']=[identity(out/'original-inputs'/name) for name in names]
    data=(source/'kernel/rust/object_helpers.rs').read_text()
    generated='use crate::abi::*;\nuse core::{ffi::c_void,ptr::write};\n'
    for name in ['EIO','EINVAL','SCD_MSG_SYSFS_RESP_SHOW','SCD_MSG_SYSFS_RESP_STORE','SCD_MSG_SYSFS_RESP_RELEASE']:
        match=re.search(r'(?m)^const '+name+r':[^\n]+;',data);assert match,name;generated+=match[0]+'\n'
    start=data.index('pub type SysfssShowFn');end=data.index('#[inline(always)]\nunsafe fn store_sysfs_response',start)
    generated+=data[start:end]
    for name in ['sysfs_response_error_result','sysfs_default_response_ssize_result','sysfs_release_response_error_result',
        'sysfss_packet_prepare_result','store_sysfs_response','sysfss_send','sysfss_req_show_body_result',
        'sysfss_req_store_body_result','sysfss_req_release_body_result']:
        generated+=extract(data,name)+'\n'
    (fixture/'native-sysfs-guest-reference.rs').write_text(generated)
    run('format',['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',
        str(source/'host-kernel/native-rust/abi/sysfs_request.rs'),str(source/'host-kernel/native-rust/sysfs_rpc.rs'),
        str(fixture/'native-sysfs-request-protocol.rs')])
    run('layout-build',['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror',str(fixture/'native-sysfs-request-layout.c'),'-o',str(out/'layout')])
    run('layout',[str(out/'layout')])
    shutil.copyfile(out/'layout.log',fixture/'native-sysfs-request-layout.txt')
    record['layout']=list(map(int,(out/'layout.log').read_text().split()))
    assert len(record['layout'])==32
    run('protocol-build',['rustc','--edition','2021','--test',str(fixture/'native-sysfs-request-protocol.rs'),'-o',str(out/'protocol-tests')])
    run('protocol-tests',[str(out/'protocol-tests'),'--nocapture'])
    record['compiler_inputs']=[identity(p) for p in sorted(source.rglob('*')) if p.is_file()]
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    record['outputs']=[identity(p) for p in sorted(out.iterdir()) if p.is_file() and p.name!='record.json']
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],out,flush=True)
