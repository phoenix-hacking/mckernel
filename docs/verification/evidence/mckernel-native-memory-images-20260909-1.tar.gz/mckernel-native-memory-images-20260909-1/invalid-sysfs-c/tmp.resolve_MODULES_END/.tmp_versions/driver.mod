/work/mckernel-native-memory-images-20260909-1/invalid-sysfs-c/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-memory-images-20260909-1/invalid-sysfs-c/tmp.resolve_MODULES_END/driver.o

