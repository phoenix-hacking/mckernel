"""Export the existing cacheinfo accessor; retain source and ABI evidence."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, shlex, shutil, struct, subprocess, sys

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
source = Path('/work/native-source/linux-6.12.0-211.44.1.el10_2')
build = Path('/work/native-build-base-24a151fe')
prior = Path('/work/native-irq-transport-exact-stage-20260907-1')
kernel = Path('/work/native-vdso-kernel-20260907-3')
out = Path('/work/native-topology-kernel-20260907-' + sys.argv[1]); out.mkdir()
patch = repo / 'host-kernel/kbuild/patches/0009-cacheinfo-export-existing-topology-accessor.patch'
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running',
    source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
    commands=[], inputs=[], production_gate_credit=False, sysfs_service_completed=False,
    scope='Existing Linux topology accessor export and configured C layout; native snapshot and guest checks remain pending')

def identity(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''): value.update(data)
    return dict(path=str(path), size=path.stat().st_size, sha256=value.hexdigest())

def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')

def run(label, command):
    print('RUN', label, flush=True)
    (out / 'phase').write_text(label + '\n')
    with (out / (label + '.log')).open('wb') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    record['commands'].append(dict(label=label, command=command, exit_code=result.returncode)); save()
    assert result.returncode == 0, (label, (out / (label + '.log')).read_text()[-6000:])

try:
    assert json.loads((kernel / 'record.json').read_text())['status'] == 'PASS'
    assert (build / '.config').read_bytes() == (kernel / 'resolved.config').read_bytes()
    shutil.copyfile(__file__, out / 'helper.py')
    shutil.copyfile(patch, out / patch.name)
    record['inputs'].append(identity(patch))
    targets = ['drivers/base/cacheinfo.c']
    headers = ['include/linux/cacheinfo.h', 'include/linux/cpumask.h',
               'include/linux/cpumask_types.h', 'include/linux/cpuhplock.h',
               'arch/x86/include/asm/processor.h', 'arch/x86/include/asm/topology.h',
               'arch/x86/include/asm/percpu.h', 'arch/x86/kernel/smpboot.c']
    for relative in targets + headers:
        target = out / 'before' / relative; target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / relative, target)
    shutil.copyfile(build / 'rust/bindings/bindings_generated.rs', out / 'before-bindings_generated.rs')
    run('diff-check', ['git', '-C', str(repo), 'diff', '--check', 'HEAD'])
    witness = out / 'witness'; witness.mkdir()
    fixture = repo / 'scripts/tests/fixtures/native_topology_layout.c'
    shutil.copyfile(fixture, witness / fixture.name); record['inputs'].append(identity(fixture))
    (witness / 'Kbuild').write_text('obj-m += native_topology_layout.o\n')
    base = shlex.split((prior / 'module-build.command').read_text())[:-3]
    run('preprocess-before', base + ['M=' + str(witness), 'native_topology_layout.i'])
    shutil.copyfile(witness / 'native_topology_layout.i', out / 'before-native-topology-layout.i')
    if sys.argv[1] != '1':
        previous = Path('/work/native-topology-kernel-20260907-' + str(int(sys.argv[1]) - 1))
        previous_patch = previous / patch.name
        record['previous_failed_attempt'] = str(previous)
        run('previous-patch-reverse-check', ['patch', '-d', str(source), '-p1', '--batch',
            '--dry-run', '--fuzz=0', '-R', '-i', str(previous_patch)])
        run('previous-patch-reverse', ['patch', '-d', str(source), '-p1', '--batch',
            '--fuzz=0', '-R', '-i', str(previous_patch)])
    run('patch-check', ['patch', '-d', str(source), '-p1', '--batch', '--dry-run', '--fuzz=0', '-i', str(patch)])
    run('patch-apply', ['patch', '-d', str(source), '-p1', '--batch', '--fuzz=0', '-i', str(patch)])
    for relative in targets:
        target = out / 'after' / relative; target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / relative, target)
    run('preprocess-after', base + ['M=' + str(witness), 'native_topology_layout.i'])
    shutil.copyfile(witness / 'native_topology_layout.i', out / 'after-native-topology-layout.i')
    def tokens(path):
        return '\n'.join(line for line in path.read_text().splitlines() if not line.startswith('# '))
    assert tokens(out / 'before-native-topology-layout.i') == tokens(out / 'after-native-topology-layout.i'), 'C topology declarations changed'
    record['normal_c_preprocessing_unchanged'] = True
    run('layout-witness', base + ['M=' + str(witness), 'native_topology_layout.o'])
    binary = out / 'native-topology-layout.bin'
    run('extract-layout', ['objcopy', '--dump-section', '.mckernel_native_topology_layout=' + str(binary),
        str(witness / 'native_topology_layout.o'), str(out / 'layout-copy.o')])
    actual = list(struct.unpack('<' + str(binary.stat().st_size // 8) + 'Q', binary.read_bytes()))
    assert len(actual) == 45, actual
    record['c_layout'] = actual; save()
    run('kernel-build', shlex.split((prior / 'kernel-build.command').read_text()))
    run('existing-prototype-module-build', shlex.split((prior / 'module-build.command').read_text()))
    for relative, name in [('.config', 'resolved.config'), ('Module.symvers', 'Module.symvers'),
                           ('arch/x86/boot/bzImage', 'bzImage'),
                           ('rust/bindings/bindings_generated.rs', 'bindings_generated.rs')]:
        shutil.copyfile(build / relative, out / name)
    for name in ('ihk.ko', 'ihk-smp-x86_64.ko', 'mcctrl.ko'):
        shutil.copyfile(build / 'drivers/misc/mckernel' / name, out / name)
    assert (out / 'bindings_generated.rs').read_bytes() == (out / 'before-bindings_generated.rs').read_bytes(), 'Generated Rust topology ABI changed'
    symbols = [line.split() for line in (out / 'Module.symvers').read_text().splitlines()]
    for name, export in [('get_cpu_cacheinfo', 'EXPORT_SYMBOL_GPL'), ('cpu_info', 'EXPORT_SYMBOL'),
                         ('cpu_core_map', 'EXPORT_SYMBOL'), ('cpu_sibling_map', 'EXPORT_SYMBOL')]:
        assert any(row[1:4] == [name, 'vmlinux', export] for row in symbols), name
    assert (out / 'resolved.config').read_bytes() == (kernel / 'resolved.config').read_bytes()
    shutil.copytree(source / 'drivers/misc/mckernel', out / 'staged-source')
    record['status'] = 'PASS'
except BaseException as error:
    record.update(status='FAIL', error=str(error)); raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    record['outputs'] = [identity(path) for path in sorted(out.iterdir())
                        if path.is_file() and path.name not in ('record.json', 'phase')]
    save(); print(record['status'], out, flush=True)
