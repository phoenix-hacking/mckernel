"""Retain independent worker/TGID reaping, original failures and real guest regressions."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, os, shutil, stat, subprocess, sys, tarfile
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-application-reaper-retained-20260908-'+sys.argv[1]);out.mkdir()
manifest=out/'native-application-reaper-checkpoint-20260908.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    artifacts=[],captures=[],references=[],native_compiler_bindings=[],guest_compiler_bindings=[],
    scope='Four actual guest image profiles with procfs lifetime fixes; current three native modules and both real Linux/McKernel ABI regressions. Actual procfs request/release service, scheduled cleanup, START and application execution remain pending.',
    native_procfs_service_integrated=False,live_procfs_retirement_observed=False,
    start_integrated=False,scheduled_cleanup_integrated=False,mckernel_application_executed=False,
    production_gate_credit=False,independent_acceptance=False,original_module_failures=1)
def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())

def check_tree(source, path, excluded):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen and relative not in excluded
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), relative
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert current.is_symlink() and os.readlink(current) == member.linkname
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), relative
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), relative
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected - excluded.keys(), (source, sorted((expected - excluded.keys()) - seen)[:5])

def artifact(source, name, tree=False, excluded=None):
    excluded = excluded or {}
    path = out / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                def select(member):
                    relative = str(PurePosixPath(*PurePosixPath(member.name).parts[1:]))
                    return None if relative in excluded else member
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name, filter=select)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    with gzip.open(path, 'rb') as stream:
        while stream.read(1 << 20):
            pass
    if tree:
        check_tree(source, path, excluded)
    else:
        assert gzip.decompress(path.read_bytes()) == source.read_bytes()
    row = identity(path)
    assert row['size'] < 95 * 1024**2, row
    row.update(path='docs/verification/evidence/' + name, source=str(source))
    if excluded:
        row['scope'] = 'Complete capture except mapped, verified copies of committed evidence; restore those blobs using archive_exclusions.'
    record['artifacts'].append(row)
    print('RETAINED', name, row['size'], flush=True)

def binding(current, compiled):
    left, right = identity(current), identity(compiled)
    assert (left['size'], left['sha256']) == (right['size'], right['sha256']), str(current)
    return dict(path=str(current.relative_to(repo)), size=left['size'], sha256=left['sha256'],
                compiler_capture=str(compiled), binding='identical compiler source')

def verify(row, old_prefix=None, retained_prefix=None):
    path=Path(row['path'])
    if old_prefix is not None and path.is_relative_to(old_prefix):
        path=retained_prefix/path.relative_to(old_prefix)
    actual=identity(path)
    assert (actual['size'],actual['sha256']) == (row['size'],row['sha256']), (row,actual)

record.update(scope='Independent actual Linux worker/TGID retirement in the existing mcctrl registry, with 72 quiet-window worker proofs and four inherited-binding group retirements. Root procfs and original guest regressions preserved. Scheduled cleanup, START and application execution remain pending.', native_procfs_service_integrated=True, live_procfs_retirement_observed=True, original_module_failures=0,original_guest_failures=3,independent_worker_reaper_integrated=True)
try:
    shutil.copyfile(__file__,out/'helper.py')
    captures=[('native-application-reaper-module-20260908-1','PASS'),('native-application-reaper-guest-20260908-x86_64-1','FAIL'),('native-application-reaper-guest-20260908-x86_64-2','FAIL'),('native-application-reaper-guest-20260908-x86_64-3','PASS'),('native-application-reaper-guest-20260908-x86_64-4','FAIL'),('native-application-reaper-guest-20260908-x86_64-5','PASS')]
    for name,expected in captures:
        directory=work/name;state=json.loads((directory/'record.json').read_text());assert state['status']==expected,name
        for row in state.get('inputs',[])+state.get('outputs',[])+state.get('compiler_inputs',[]):verify(row)
        for row in state.get('overlay',[]):verify(row,work/'native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel',directory/'staged-source')
        for capture in state.get('captures',[]):
            for row in capture['artifacts']:verify(row)
        artifact(directory,name+'.tar.gz',True)
        artifact(directory/'record.json',name+'-complete-record.json.gz')
        record['captures'].append(dict(path=str(directory),status=expected,complete_capture_retained=True,archive_exclusions={}))
    compiled=work/'native-application-reaper-module-20260908-1'
    for saved in sorted((compiled/'staged-source').rglob('*')):
        if saved.suffix not in ('.rs','.S'):continue
        relative=saved.relative_to(compiled/'staged-source');current=repo/'host-kernel/native-rust'/relative
        assert current.is_file(),current
        if current.read_bytes()==saved.read_bytes():record['native_compiler_bindings'].append(binding(current,saved))
        else:
            assert str(relative) in ('ihk_ioctl.rs','os_registry.rs','smp_resource.rs'),str(relative)
            replay=out/'format-replay'/relative;replay.parent.mkdir(parents=True,exist_ok=True)
            original=replay.with_suffix('.original.rs');shutil.copyfile(current,original);shutil.copyfile(current,replay)
            command=['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(replay)]
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            replay.with_suffix('.log').write_bytes(result.stdout);assert result.returncode==0,(command,result.stdout)
            assert replay.read_bytes()==saved.read_bytes(),str(current)
            row=identity(current);row['path']=str(current.relative_to(repo))
            row.update(binding='exact pinned rustfmt replay',compiler_capture=str(saved),formatted_sha256=identity(saved)['sha256'],replay_command=command)
            record['native_compiler_bindings'].append(row)
    if (out/'format-replay').exists():artifact(out/'format-replay','native-application-reaper-20260908-format-replay.tar.gz',True)
    guest=work/'native-application-reaper-guest-20260908-x86_64-5';state=json.loads((guest/'record.json').read_text())
    record['native_procfs']=state['native_procfs'];record['native_waiter']=state['native_waiter'];record['worker_reaper']=state['worker_reaper']
    record['module_guest_bindings']=[]
    for name in ('ihk.ko','ihk-smp-x86_64.ko','mcctrl.ko'):
        left,right=identity(compiled/name),identity(guest/'root/modules'/name)
        assert (left['size'],left['sha256'])==(right['size'],right['sha256'])
        record['module_guest_bindings'].append(dict(module=name,sha256=left['sha256']))
    record['probe_bindings']=[]
    for copied in sorted((guest/'probe-source').iterdir()):
        source=repo/'scripts/tests/fixtures'/copied.name
        if copied.name=='native-image-c-abi.h':source=repo/'executer/include/uprotocol.h'
        record['probe_bindings'].append(binding(source,copied))
    for name in ('build-native-application-reaper.py','run-native-application-reaper-guest.py','retain-native-application-reaper.py'):
        artifact(work/name,'native-application-reaper-20260908-'+name+'.gz')
    for name in ('native-procfs-images-checkpoint-20260908.json','native-procfs-lifetime-checkpoint-20260908.json','native-procfs-objects-checkpoint-20260908.json'):
        path=repo/'docs/verification'/name;assert json.loads(path.read_text())['status']=='PASS'
        row=identity(path);row['path']=str(path.relative_to(repo));record['references'].append(row)
    record.update(status='PASS',artifact_bytes=sum(row['size'] for row in record['artifacts']),pid_tid_runtime_proven=False,direct_io_runtime_proven=False,adversarial_live_requests_proven=False)
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    (out/'record.json').write_bytes(manifest.read_bytes())
    print(record['status'],out,flush=True)
