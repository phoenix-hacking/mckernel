from pathlib import Path
import hashlib
import io
import json
import tarfile

ROOT = Path('/home/holden/mckernel')
FIRST = Path('/tmp/stability-remaining-fault-contracts-source-20260913-1')
FINAL = Path('/tmp/stability-remaining-fault-contracts-source-20260913-2')
PEER = Path('/tmp/stability-remaining-mode-ownership-review-20260913-5vqxhjva')
FINAL.mkdir()
(FINAL / 'retention.py').write_bytes(Path(__file__).read_bytes())

def identity(path, raw=None):
    path = Path(path)
    if raw is None:
        raw = path.read_bytes()
    return {'path': str(path), 'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

first_inputs = json.loads((FIRST / 'inputs.json').read_text())
inputs = []
for item in first_inputs:
    relative = item['path']
    source = ROOT / relative
    raw = source.read_bytes()
    target = FINAL / 'source' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    inputs.append(dict(identity(relative, raw), changed_since_first_draft=hashlib.sha256(raw).hexdigest() != item['sha256']))
(FINAL / 'inputs.json').write_text(json.dumps(inputs, indent=2, sort_keys=True) + '\n')
document = next(row for row in inputs if row['path'].endswith('stability-remaining-fault-contracts-draft-20260913.md'))
if document['sha256'] != '679ec96c605f71c62a8841cdd2a97b9d1ab7648d23ba00870aa2098c87a61d9a':
    raise ValueError('final draft document drift')

definitions = [
    ('postpublish-notify', 2, 'postpublication-notify', -71, -5, 5, True),
    ('recoverable-backpressure', 3, 'recovery-before-deadline', 0, 0, None, True),
    ('permanent-backpressure', 4, 'permanent-pressure', -71, -110, 110, False),
]
modes = []
for mode, number, owner_mode, ret_errno, final_error, admission_errno, released in definitions:
    relative = 'scripts/application-tests/contracts/drafts/stability-' + mode + '-20260913-v1.json'
    raw = (FINAL / 'source' / relative).read_bytes()
    # JSON inspection is metadata only. Do not import/execute the frozen parser.
    contract = json.loads(raw)
    modes.append({
        'mode': mode, 'overlay_mode_id': number, 'owner_mode': owner_mode,
        'draft_contract': identity(relative, raw), 'runtime_enabled': False,
        'compilation_authorized': False, 'execution_authorized': False,
        'owner_contract': contract,
        'expected_runtime_and_application_transport_errno': final_error,
        'new_admission': {'required': number != 3, 'result': -1 if number != 3 else None,
                          'errno': admission_errno, 'successful_eight_hello_instead': number == 3},
        'expected_original_call_retained_at_final_phases': number == 4,
        'expected_original_application_retained_at_final_phases': number != 3,
        'expected_original_response_ledger_tag_retained_at_final_phases': number == 4,
        'expected_original_selected_worker_at_final_phases':
            'retained deliveryNone/completedOriginal' if number == 2 else
            'original application and worker absent' if number == 3 else
            'retained original delivery/TID, not completedOriginal',
        'selected_response_read_policy': 'BlockedRead only; never reread after publication or release' if released else
            'BlockedRead and terminal phases only after independent current retention/published0 checks',
        'expected_final_fault_counters': {
            'attempts': 'real_sends, 1..32' if number == 2 else 'greater than real_sends' if number == 3 else '>=1',
            'real_sends': '1..32' if released else 0,
            'published': int(released), 'notification_failures': int(number == 2),
            'barrier_attempts': 'equals AcceptedReturn barrier_attempts; can be0',
            'since_ns': 'exact immutable first post-barrier fault-attempt time'},
        'real_send_result_order': 'zero or more -11/-16, then exactly one0' if released else 'no real callback',
        'expected_ret': {'errno': ret_errno, 'accepted': 1, 'value': 16, 'maximum_elapsed_ns': 15000000000},
        'timer_requirement': 'actual retained publication_since Some; terminal BEGIN >= (timer_seconds+5)*1e9' if number == 4 else
            'first real send >= fault_since+2e9; actual final callback END < (observed original timer_seconds+5)*1e9; missing original timer remains OPEN' if number == 3 else
            'RET/controller bounds; no recovery-before-deadline acceptance in this terminal mode',
        'final_phase_comparison': 'all independent inventory rows plus selected/fault counters exactly equal over at least5 native monotonic seconds' if number != 3 else
            'selected/fault counters equal; both healthy with applications0; whole inventories may change through8 new launches',
        'eight_hello': {'required': number == 3, 'count': 8 if number == 3 else 0,
            'argv': ['/bin/mcexec', '-t', '1', '0', '/bin/native-application-hello'] if number == 3 else None,
            'stdout_hex': b'NATIVE_APPLICATION_HELLO\n'.hex() if number == 3 else None,
            'stderr_hex': '' if number == 3 else None,
            'raw_wait_status': 9472 if number == 3 else None,
            'same_os_and_generation': True, 'phase_label_counts_launches': False},
        'application_acceptance': False, 'transport_acceptance': False,
        'production_gate_credit': False, 'physical_full_ring_verified': False,
    })

record = {
    'schema_version': 1, 'record_kind': 'stability_remaining_fault_mode_drafts',
    'status': 'SOURCE_DERIVED_DRAFTS_NOT_RELEASED',
    'compilation_authorized': False, 'execution_authorized': False,
    'runtime_enabled': False, 'application_acceptance': False,
    'transport_acceptance': False, 'production_gate_credit': False,
    'physical_full_ring_verified': False, 'tests_executed': False,
    'guest_execution': False, 'frozen_production_and_runner_files_modified': False,
    'source_inputs': inputs, 'document': document, 'modes': modes,
    'independent_review': identity(PEER / 'review.json'),
    'independent_final_document_delta_review': identity(PEER / 'delta-review.json'),
    'independent_review_scope': 'source ownership/counter/RET/deadline and draft scan; no tested parser imports, compilation or runtime acceptance',
    'current_hard_contract_preserved': identity(ROOT / 'scripts/application-tests/contracts/stability-prepublish-hard-20260913-v1.json'),
    'common_open_gates': [
        'Root review and exact mode-specific compiler/module, workload/ELF/root and helper bindings before execution.',
        'Actual original read16 with stopped status0/wake2 before input ACK; readiness/labels cannot substitute.',
        'Mode-aware collector phase/ACK, counter, admission and raw-wait validation; frozen current runner remains hard-only.',
        'Modes2/3 must never dump the original response after publication/release in any normal or emergency/final path.',
        'AcceptedReturn metadata does not supply a stopped physical prepublication prefix. Existing automatic barrier may release before QMP capture.',
        'Mode2 needs selected original CALL/tag absence and WORKER completedOriginal checks in an additive checker.',
        'Mode3 needs exact observed original production timer,8 actual same-OS bounded HELLO launches, independent raw waits/outputs/retirements, and AfterEightHello client invocation.',
        'Combined recovery/controller/after-hello export must fit the existing256-entry/16-MiB limits; independently bounded clients cannot each assume the entire allowance.',
        'Modes2/3 need a source-bound positive real wake publication checker with retained counter intervals, not the current absence comparator.',
        'Physical-full-ring remains a separate reviewed workload: actual Full maps EBUSY(-16), also possible for producer contention; injection and errno labels supply no saturation proof.'
    ],
    'original_draft_preserved': str(FIRST),
}
(FINAL / 'draft-record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
archive = ROOT / 'docs/verification/evidence/stability-remaining-fault-contracts-draft-20260913.tar.gz'
report = ROOT / 'docs/verification/stability-remaining-fault-contracts-draft-20260913.json'
if archive.exists() or report.exists():
    raise ValueError('immutable output exists')
members = []
with archive.open('xb') as output:
    with tarfile.open(fileobj=output, mode='w:gz') as tar:
        for label, directory in [('source-attempt1', FIRST), ('source-attempt2', FINAL), ('peer-review', PEER)]:
            for path in sorted(directory.rglob('*')):
                if path.is_symlink():
                    raise ValueError('unexpected symlink: ' + str(path))
                if not path.is_file():
                    continue
                raw = path.read_bytes()
                member = label + '/' + path.relative_to(directory).as_posix()
                item = tarfile.TarInfo(member)
                item.size = len(raw)
                item.mode = 0o644
                tar.addfile(item, io.BytesIO(raw))
                members.append(dict(identity(path, raw), member=member))
with tarfile.open(archive, 'r:gz') as tar:
    actual = tar.getmembers()
    if len(actual) != len(members):
        raise ValueError('member count drift')
    for actual, expected in zip(actual, members):
        raw = tar.extractfile(actual).read()
        if actual.name != expected['member'] or len(raw) != expected['size'] or hashlib.sha256(raw).hexdigest() != expected['sha256']:
            raise ValueError('archive member drift: ' + actual.name)
record.update(archive=identity(archive), archive_members=members,
              archive_member_hashes_verified=True,
              retention_scope='metadata parsing and raw-byte hashing only; no tested helper/parser imports or execution')
report.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
result = {'report': identity(report), 'archive': identity(archive), 'members': len(members)}
(FINAL / 'retention-verification.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result))
