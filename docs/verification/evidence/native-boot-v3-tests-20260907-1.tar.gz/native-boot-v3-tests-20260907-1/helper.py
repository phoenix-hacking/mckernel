from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');out=Path('/work/native-boot-v3-tests-20260907-'+sys.argv[1]);out.mkdir()
paths=['host-kernel/native-rust/'+name for name in ['abi/x86_64.rs','device_registry.rs','os_registry.rs','ihk_ioctl.rs','os_runtime.rs']]+['scripts/tests/test_ihk_os_runtime.py','scripts/tests/fixtures/ihk_os_runtime_compile.rs']
for relative in paths:
    target=out/'source'/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/relative,target)
record=dict(started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),commands=[],production_gate_credit=False)
commands=[['rustfmt','--edition','2021','--config','skip_children=true',str(out/'source/host-kernel/native-rust/os_runtime.rs')],['python3','-B','-m','unittest','-v','-f','scripts.tests.test_ihk_os_runtime']]
try:
    for i,command in enumerate(commands):
        with (out/('step-'+str(i)+'.log')).open('wb') as log:
            result=subprocess.run(command,cwd=out/'source',env=dict(os.environ,MCKERNEL_RUSTC_1_92='/usr/bin/rustc'),stdout=log,stderr=subprocess.STDOUT)
        record['commands'].append(dict(command=command,exit_code=result.returncode))
        if result.returncode: raise RuntimeError((command,(out/('step-'+str(i)+'.log')).read_text()))
    record['status']='PASS'
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    record['inputs']=[dict(path=str(out/'source'/p),size=(out/'source'/p).stat().st_size,sha256=hashlib.sha256((out/'source'/p).read_bytes()).hexdigest()) for p in paths]
    (out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    shutil.copyfile(__file__,out/'helper.py');print(record['status'],out,flush=True)
