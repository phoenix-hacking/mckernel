"""Archive inspected source/result evidence; no tested-code imports or runs."""
from pathlib import Path
import hashlib
import json
import shutil
import stat
import tarfile

REPO = Path('/home/holden/mckernel')
CAPTURE = Path('/tmp/stability-decoder84-evidence-review-20260913-buuqxr38')
EVIDENCE = REPO / 'docs/verification/evidence'
NAME = 'stability-application-request-decoder-results-20260913-1'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def identity(p):
    raw = p.read_bytes()
    return {'path': str(p.relative_to(REPO)) if p.is_relative_to(REPO) else str(p),
            'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def save(p, obj):
    with p.open('x') as stream:
        json.dump(obj, stream, indent=2, sort_keys=True); stream.write('\n')


def inventory(root):
    rows, size = [], 0
    for p in [root] + sorted(root.rglob('*')):
        require(len(rows) < 2048, 'member cap')
        info = p.lstat()
        row = {'name': str(p.relative_to(root.parent)), 'mode': stat.S_IMODE(info.st_mode)}
        if stat.S_ISDIR(info.st_mode): row.update(kind='directory', size=0)
        else:
            require(stat.S_ISREG(info.st_mode), 'nonregular evidence object')
            item = identity(p); row.update(kind='file', size=item['size'], sha256=item['sha256'])
            size += item['size']; require(size < 32 * 1024 * 1024, 'content cap')
        rows.append(row)
    return rows


def main():
    review = json.loads((CAPTURE / 'review.json').read_bytes())
    require(review['status'] == 'PASS_RETAINED_DECODER_INFRASTRUCTURE_EVIDENCE_ONLY', 'inspection incomplete')
    original = json.loads((REPO / 'docs/verification/stability-application-request-decoder-review-20260913.json').read_bytes())
    for item in (original['archive'], original['member_manifest']):
        require(identity(REPO / item['path']) == item, 'prior full source evidence changed')
    shutil.copyfile(__file__, CAPTURE / 'retention-helper.py')
    before = inventory(CAPTURE)
    archive = EVIDENCE / (NAME + '.tar.gz')
    with tarfile.open(archive, 'x:gz', format=tarfile.PAX_FORMAT) as stream:
        for row in before:
            stream.add(CAPTURE.parent / row['name'], arcname=row['name'], recursive=False)
    actual = []
    with tarfile.open(archive, 'r:gz') as stream:
        for member in stream:
            require(len(actual) < 2048, 'decoded member cap')
            row = {'name': member.name, 'mode': member.mode}
            if member.isdir(): row.update(kind='directory', size=0)
            else:
                require(member.isfile() and member.size < 32 * 1024 * 1024, 'decoded member type/size')
                raw = stream.extractfile(member).read()
                row.update(kind='file', size=len(raw), sha256=hashlib.sha256(raw).hexdigest())
            actual.append(row)
    require(actual == before and inventory(CAPTURE) == before, 'archive/original members differ')
    manifest = EVIDENCE / (NAME + '.members.json')
    save(manifest, {'schema_version': 1, 'members': before, 'all_members_verified': True, 'originals_unchanged': True})
    publication = REPO / 'docs/verification/stability-application-request-decoder-tests-review-20260913-1.json'
    record = {k: review[k] for k in ('schema_version', 'kind', 'status', 'scope', 'parent_record', 'source_review',
              'passed_cases', 'actual_harness_raw_wait_status', 'actual_harness_elapsed_seconds',
              'actual_harness_executable', 'exact_stdout', 'empty_stderr', 'parent_tree_inventory',
              'parent_tree_members', 'parent_tree_content_bytes', 'parent_full_archive_owned_by_root',
              'compiler_dependencies_rehashed_from_retained_bytes', 'reviewer_test_execution',
              'reviewer_compiler_execution', 'guest_execution', 'application_execution',
              'execution_backend_enabled', 'application_acceptance', 'transport_acceptance', 'production_gate_credit', 'catalog_credit')}
    record.update(inspection=identity(CAPTURE / 'review.json'),
                  source_versions_archive=original['archive'], source_versions_members=original['member_manifest'],
                  result_archive=identity(archive), result_archive_members=identity(manifest),
                  retained_member_count=len(before), all_members_verified=True, originals_unchanged=True,
                  original_source_review_kept_NOT_RUN=True,
                  root_parent_full_archive_separate=True,
                  helper=identity(Path(__file__)), retained_helper_member=CAPTURE.name + '/retention-helper.py')
    save(publication, record)
    save(Path(__file__).parent / 'record.json', {'status': 'PASS_RETENTION_ONLY', 'publication': identity(publication)})
    print(json.dumps({'publication': identity(publication), 'archive': identity(archive),
                      'members': len(before)}, indent=2))


if __name__ == '__main__': main()
