"""Inspect retained decoder evidence only. Never import/run the decoder/tests."""
from pathlib import Path
import hashlib
import json
import shutil
import stat

OUT = Path(__file__).resolve().parent
REPO = Path('/home/holden/mckernel')
WORK = Path('/home/holden/mckernel-work/scratch')
PARENT = WORK / 'stability-application-request-decoder-tests-20260913-1'
checks, copies = [], []


def require(ok, message):
    if not ok:
        raise ValueError(message)


def identity(p):
    info = p.stat()
    require(stat.S_ISREG(info.st_mode) and info.st_size <= 8 * 1024 * 1024, 'invalid evidence file')
    raw = p.read_bytes()
    after = p.stat()
    require((info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns) ==
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns), 'evidence changed')
    return {'path': str(p), 'size': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def local(s):
    require(s.startswith('/work/'), 'nonretained evidence reference')
    return WORK / s[6:]


def check(row):
    got = identity(local(row['path']))
    require(all(got[k] == row[k] for k in ('size', 'sha256')), 'retained identity differs')
    checks.append({'recorded': row, 'observed': got})
    return local(row['path'])


def keep(p):
    target = OUT / 'parent-subset' / p.relative_to(PARENT)
    target.parent.mkdir(parents=True, exist_ok=True)
    got = identity(p)
    shutil.copyfile(p, target)
    require(identity(target)['sha256'] == got['sha256'], 'retention changed')
    copies.append({'original': got, 'retained': identity(target)})


def load(p):
    def pairs(rows):
        out = {}
        for key, value in rows:
            require(key not in out, 'duplicate JSON key')
            out[key] = value
        return out
    return json.loads(p.read_bytes(), object_pairs_hook=pairs,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError('nonfinite JSON')))


r = load(PARENT / 'record.json')
expected = load(PARENT / 'decoder-expectations.json')
require(r['status'] == 'PASS_ACTUAL_C_REQUEST_DECODER_INFRASTRUCTURE_ONLY' and r['passed_cases'] == 84, 'parent status')
for field in ('application_acceptance', 'transport_acceptance', 'production_gate_credit', 'guest_execution', 'execution_backend_enabled'):
    require(r[field] is False, 'credit or execution unexpectedly enabled')
require(r['application_execution'] == 'NOT_RUN', 'application execution differs')
for p in (PARENT / 'record.json', PARENT / 'helper.py'):
    keep(p)
source_review = load(PARENT / 'source-review.json')
require(source_review['status'] == 'PASS_BOUNDED_SOURCE_REVIEW_ONLY', 'source review status')
for row in r['inputs'] + r['compiler_dependencies']:
    p = check(row['retained'])
    require(all(row['original'][k] == row['retained'][k] for k in ('size', 'sha256')), 'compiler/source retention differs')
    if row in r['inputs']:
        keep(p)
for row in r['compiled_outputs']:
    check(row)
for row in source_review['frozen_inputs']:
    captured = identity(PARENT / Path(row['path']).name)
    require(all(captured[k] == row[k] for k in ('size', 'sha256')), 'compiled source not reviewed source')

command_results = []
for command in r['commands']:
    c = command['collection']
    require(c['status'] == 'COMPLETED' and type(c['raw_wait_status']) is int and c['raw_wait_status'] == 0 and c['cleanup_complete'] is True, 'actual command wait/cleanup')
    require(c['descendant_records_omitted'] == 0 and not c['descendants'], 'unexpected descendants/loss')
    require(c['payload_monotonic_started'] <= c['payload_completion_observed_monotonic'] <= c['payload_monotonic_deadline'], 'late completion observation')
    for stream in c['streams'].values():
        require(stream['eof'] is True and stream['truncated'] is False and stream['discarded_observed_bytes'] == 0, 'incomplete command stream')
        p = check(stream['artifact']); keep(p)
        require(stream['bytes_observed'] == stream['bytes_retained'] == stream['artifact']['size'], 'command byte count differs')
    command_results.append({'label': command['label'], 'argv': command['argv'], 'status': c['status'], 'raw_wait_status': c['raw_wait_status'], 'cleanup_complete': c['cleanup_complete'], 'elapsed_seconds': c['elapsed_seconds'], 'observed_completion_monotonic': c['payload_completion_observed_monotonic'], 'deadline_monotonic': c['payload_monotonic_deadline']})
decoder = next(x['collection'] for x in r['commands'] if x['label'] == 'decoder84')
require(decoder['timeout_seconds'] == 10 and decoder['cleanup_timeout_seconds'] == 15 and decoder['stdout_limit_bytes'] == decoder['stderr_limit_bytes'] == 65536, 'decoder execution bounds differ')
require(decoder['executable']['sha256'] == identity(PARENT / 'decoder-harness.elf')['sha256'], 'executed ELF differs')
require((PARENT / 'decoder84-collection/stdout.bin').read_bytes() == expected['expected_process']['stdout_utf8'].encode(), 'exact independent stdout differs')
require((PARENT / 'decoder84-collection/stderr.bin').read_bytes() == b'', 'stderr not empty')
case_names = [row['name'] for row in expected['cases']]
require(len(case_names) == len(set(case_names)) == len(r['cases']) == 84 and [row['name'] for row in r['cases']] == case_names, 'case inventory differs')
require({p.name for p in (PARENT / 'cases').iterdir()} == set(case_names), 'actual case tree differs')
case_results = []
for row, oracle in zip(r['cases'], expected['cases']):
    request = check(row['request']); result = check(row['result'])
    keep(request); keep(result)
    observed = load(result)
    require(observed == row['observed'] and row['expected'] == oracle, 'case report/root differs')
    for key, value in expected['common_result'].items():
        require(type(observed[key]) is type(value) and observed[key] == value, 'independent common result differs')
    require(observed['actual_error'] == observed['expected_error'] == oracle['expected_error'] and observed['case'] == oracle['name'], 'independent case error differs')
    require(observed['output_cleared'] is oracle['output_cleared'] and observed['wire_size'] == request.stat().st_size, 'case zeroing/size differs')
    require(type(observed['checks']) is int and observed['checks'] > 0 and observed['failures'] == 0, 'missing actual assertions')
    case_results.append({'name': oracle['name'], 'actual_error': observed['actual_error'], 'checks': observed['checks'], 'wire_size': observed['wire_size'], 'request': identity(request), 'result': identity(result), 'application_execution': 'NOT_RUN', 'application_acceptance': False})
literal = load(PARENT / 'literal-vector.json')
require((PARENT / 'cases/literal-argv-empty/request.bin').read_bytes() == bytes.fromhex(literal['wire_hex']), 'literal input differs')
maximum = (PARENT / 'cases/maximum-wire/request.bin').read_bytes()
over = (PARENT / 'cases/wire-one-byte-over/request.bin').read_bytes()
require(len(maximum) == 65536 and len(over) == 65537 and maximum[:16] == over[:16] and maximum[20:] == over[20:65536] and over[-1:] == b'\xa5', 'independent exact wire boundary differs')

# Complete parent-tree mapping, including retained compiler headers and outputs.
# Parent owns its full archive; this review copies selected source/raw results.
inventory = []
total = 0
for p in [PARENT] + sorted(PARENT.rglob('*')):
    require(len(inventory) < 2048, 'parent member cap')
    info = p.lstat()
    row = {'path': str(p.relative_to(PARENT)), 'mode': stat.S_IMODE(info.st_mode)}
    if stat.S_ISDIR(info.st_mode): row.update(kind='directory')
    else:
        require(stat.S_ISREG(info.st_mode), 'unexpected parent special object')
        got = identity(p)
        row.update(kind='file', size=got['size'], sha256=got['sha256'])
        total += got['size']; require(total < 32 * 1024 * 1024, 'parent content cap')
    inventory.append(row)
with (OUT / 'parent-tree.members.json').open('x') as stream:
    json.dump({'schema_version': 1, 'root': str(PARENT), 'members': inventory}, stream, indent=2); stream.write('\n')
review = {'schema_version': 1, 'kind': 'retained-request-decoder-validation-review',
          'status': 'PASS_RETAINED_DECODER_INFRASTRUCTURE_EVIDENCE_ONLY',
          'scope': 'Read retained actual pinned C infrastructure outputs; no rerun or subject import.',
          'parent_record': identity(PARENT / 'record.json'), 'source_review': identity(PARENT / 'source-review.json'),
          'passed_cases': 84, 'actual_harness_raw_wait_status': 0, 'actual_harness_elapsed_seconds': decoder['elapsed_seconds'],
          'actual_harness_executable': identity(PARENT / 'decoder-harness.elf'),
          'exact_stdout': identity(PARENT / 'decoder84-collection/stdout.bin'),
          'empty_stderr': identity(PARENT / 'decoder84-collection/stderr.bin'),
          'all_cases_NOT_RUN_application_acceptance_false': True,
          'identity_checks': checks, 'command_results': command_results, 'case_results': case_results,
          'parent_tree_inventory': identity(OUT / 'parent-tree.members.json'),
          'parent_tree_members': len(inventory), 'parent_tree_content_bytes': total,
          'parent_full_archive_owned_by_root': True, 'retained_subset': copies,
          'compiler_dependencies_rehashed_from_retained_bytes': len(r['compiler_dependencies']),
          'loader_dependencies_not_rehashed_without_container': r['loader_dependencies'],
          'reviewer_test_execution': False, 'reviewer_compiler_execution': False, 'guest_execution': False,
          'application_execution': 'NOT_RUN', 'execution_backend_enabled': False,
          'application_acceptance': False, 'transport_acceptance': False, 'production_gate_credit': False,
          'catalog_credit': 0}
with (OUT / 'review.json').open('x') as stream:
    json.dump(review, stream, indent=2, sort_keys=True); stream.write('\n')
print(json.dumps({'review': identity(OUT / 'review.json'), 'checks': len(checks), 'actual_cases': 84,
                  'actual_harness_seconds': decoder['elapsed_seconds'], 'parent_members': len(inventory)}, indent=2))
