from pathlib import Path
from datetime import datetime, timezone
import hashlib, importlib.util, json, os, shlex, shutil

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, work = Path('/workspace'), Path('/work')
out = work / 'stability-application-request-decoder-tests-20260913-1'
out.mkdir(); (out / 'tmp').mkdir()
record = dict(status='RUNNING', started_utc=datetime.now(timezone.utc).isoformat(),
    scope='Pinned actual C memory request decoder infrastructure; no application or guest execution',
    inputs=[], commands=[], compiler_dependencies=[], compiled_outputs=[], cases=[],
    application_acceptance=False, transport_acceptance=False, production_gate_credit=False,
    guest_execution=False, application_execution='NOT_RUN', execution_backend_enabled=False)
def identity(path):
    raw = path.read_bytes()
    return dict(path=str(path), size=len(raw), sha256=hashlib.sha256(raw).hexdigest())
def save():
    (out / 'record.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
try:
    assert shutil.disk_usage(work).free > 3 * 1024**3
    shutil.copyfile(__file__, out / 'helper.py')
    review_path = repo / 'docs/verification/stability-application-request-decoder-review-20260913.json'
    review = json.loads(review_path.read_text()); assert review['status'] == 'PASS_BOUNDED_SOURCE_REVIEW_ONLY'
    shutil.copyfile(review_path, out / 'source-review.json')
    record['inputs'].append(dict(original=identity(review_path), retained=identity(out / 'source-review.json')))
    for row in review['frozen_inputs']:
        src = repo / row['path']; actual = identity(src)
        assert (actual['size'], actual['sha256']) == (row['size'], row['sha256'])
        target = out / src.name; shutil.copyfile(src, target)
        record['inputs'].append(dict(original=actual, retained=identity(target)))
    assert identity(out / 'request.c')['sha256'] == 'c072005948e479e6f50d3f647bf649301741365d7c034c72d3047df3f85cc3ab'
    assert identity(out / 'decoder_harness.c')['sha256'] == 'bb1831f3a2a9fd99bb336cb9807c651310a8f27011a8c042c51f56d7e404cf62'
    assert identity(out / 'decoder-expectations.json')['sha256'] == '31f565b03064cb26a27be6effb83640ebde68660ef916ffb312e4fdda77d4cee'
    source = repo / 'scripts/application-tests/supervisor.py'
    assert identity(source)['sha256'] == '8b8700175e6673c3a6b652d4a93bd18b56def83dfa3ac4ec821d4ae6c554e873'
    shutil.copyfile(source, out / 'supervisor.py')
    record['inputs'].append(dict(original=identity(source), retained=identity(out / 'supervisor.py')))
    spec = importlib.util.spec_from_file_location('decoder_supervisor', out / 'supervisor.py')
    supervisor = importlib.util.module_from_spec(spec); spec.loader.exec_module(supervisor)
    env = dict(PATH='/usr/local/bin:/usr/bin:/bin', LANG='C', LC_ALL='C', TZ='UTC', TMPDIR=str(out / 'tmp'))
    def run(label, argv, timeout=120, cap=8*1024**2):
        if not Path(argv[0]).is_absolute(): argv[0] = shutil.which(argv[0], path=env['PATH'])
        record['phase'] = label; save(); print('RUN', label, flush=True)
        result = supervisor.run_supervised(argv, cwd=str(out), env=env, attempt_dir=str(out / (label + '-collection')),
            timeout_seconds=timeout, cleanup_timeout_seconds=15, stdout_limit_bytes=cap, stderr_limit_bytes=cap)
        record['commands'].append(dict(label=label, argv=argv, environment=env, collection=result)); save()
        assert result['status'] == 'COMPLETED' and result['raw_wait_status'] == 0 and result['cleanup_complete'], (label, result)
        return result
    run('compiler-version', ['gcc', '--version'])
    objects = []
    for stem in ('request', 'decoder_harness'):
        obj, deps = out / (stem + '.o'), out / (stem + '.d')
        run(stem + '-compile', ['gcc', '-std=c11', '-O2', '-g', '-Wall', '-Wextra', '-Werror', '-D_GNU_SOURCE',
            '-MD', '-MF', str(deps), '-c', str(out / (stem + '.c')), '-o', str(obj)])
        objects.append(obj)
        for item in shlex.split(deps.read_text().replace('\\\n', ' ').split(':', 1)[1]):
            path = Path(item)
            if not path.is_absolute(): path = out / path
            original = identity(path)
            if any(row['original'] == original for row in record['compiler_dependencies']): continue
            retained = out / 'compiler-inputs' / str(path).lstrip('/')
            retained.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(path, retained)
            record['compiler_dependencies'].append(dict(original=original, retained=identity(retained)))
        record['compiled_outputs'] += [identity(obj), identity(deps)]
    elf, linkmap = out / 'decoder-harness.elf', out / 'decoder-harness.map'
    run('link', ['gcc', *map(str, objects), '-Wl,-Map=' + str(linkmap), '-o', str(elf)])
    record['compiled_outputs'] += [identity(elf), identity(linkmap)]
    run('elf', ['readelf', '-h', '-l', '-d', str(elf)])
    run('loader-trace', ['ldd', str(elf)])
    record['loader_dependencies'] = []
    for line in (out / 'loader-trace-collection/stdout.bin').read_text().splitlines():
        for part in line.split():
            if part.startswith('/') and Path(part).is_file(): record['loader_dependencies'].append(identity(Path(part)))
    expected = json.loads((out / 'decoder-expectations.json').read_text())
    assert expected['case_count'] == len(expected['cases']) == 84
    run('decoder84', [str(elf), '--all', str(out / 'cases')], timeout=10, cap=65536)
    assert (out / 'decoder84-collection/stdout.bin').read_bytes() == expected['expected_process']['stdout_utf8'].encode()
    assert (out / 'decoder84-collection/stderr.bin').read_bytes() == bytes.fromhex(expected['expected_process']['stderr_hex'])
    assert {p.name for p in (out / 'cases').iterdir()} == {case['name'] for case in expected['cases']}
    for case in expected['cases']:
        directory = out / 'cases' / case['name']
        observed = json.loads((directory / 'result.json').read_text())
        for key, value in expected['common_result'].items():
            assert type(observed[key]) is type(value) and observed[key] == value, (case['name'], key)
        assert observed['case'] == case['name']
        assert observed['actual_error'] == observed['expected_error'] == case['expected_error']
        assert observed['output_cleared'] is case['output_cleared']
        request = identity(directory / 'request.bin')
        assert request['size'] == observed['wire_size']
        record['cases'].append(dict(name=case['name'], expected=case, observed=observed,
                                   request=request, result=identity(directory / 'result.json')))
    for row in record['inputs'] + record['compiler_dependencies']:
        assert identity(Path(row['original']['path'])) == row['original']
        assert identity(Path(row['retained']['path'])) == row['retained']
    for row in record['compiled_outputs'] + record['loader_dependencies']:
        assert identity(Path(row['path'])) == row
    record.update(status='PASS_ACTUAL_C_REQUEST_DECODER_INFRASTRUCTURE_ONLY', passed_cases=84)
except BaseException as error:
    record.update(status='FAIL', error_type=type(error).__name__, error=str(error)); raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat(); save(); print(record['status'], out, flush=True)
