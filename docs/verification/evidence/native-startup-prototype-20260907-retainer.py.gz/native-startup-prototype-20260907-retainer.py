from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,tarfile
repo=Path('/home/holden/mckernel');work=Path('/home/holden/mckernel-work/scratch')
passed=work/'native-startup-tables-prototype-20260907-2';guest=work/'native-startup-tables-guest-20260907-2'
build=json.loads((passed/'record.json').read_text());run=json.loads((guest/'local-run.json').read_text())
assert build['status']=='PASS' and run['status']=='technical-capture-passed'
assert not run['missing_markers'] and not run['error_markers']
assert len(run['physical_startup_table_readbacks'])==56 and len(run['physical_image_readbacks'])==56
assert run['startup_allocation_failures']==64 and not run['mckernel_boot_proven']
for row in build['outputs']+run['inputs']:
 if row['path'].startswith('/work/'): path=work/row['path'][6:]
 elif row['path'].startswith('/workspace/'): path=repo/row['path'][11:]
 else: continue
 data=path.read_bytes();assert len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256'],str(path)
artifacts=[]
def retain(name,data):
 output=repo/'docs/verification/evidence'/('native-startup-prototype-20260907-'+name+'.gz')
 encoded=gzip.compress(data,mtime=0)
 with output.open('xb') as stream: stream.write(encoded)
 artifacts.append(dict(path=str(output.relative_to(repo)),size=len(encoded),sha256=hashlib.sha256(encoded).hexdigest(),uncompressed_size=len(data),uncompressed_sha256=hashlib.sha256(data).hexdigest()))
def archive(folder,exclude):
 out=io.BytesIO()
 with tarfile.open(fileobj=out,mode='w',format=tarfile.USTAR_FORMAT) as stream:
  for path in sorted(folder.rglob('*')):
   if not path.is_file() or path.relative_to(folder).parts[0] in exclude: continue
   data=path.read_bytes();info=tarfile.TarInfo(str(path.relative_to(folder)));info.size=len(data);info.mode=0o644;info.mtime=0
   stream.addfile(info,io.BytesIO(data))
 return out.getvalue()
for attempt in (1,2):
 compiled=work/('native-startup-tables-prototype-20260907-'+str(attempt));capture=work/('native-startup-tables-guest-20260907-'+str(attempt))
 retain('build-'+str(attempt)+'.tar',archive(compiled,{'prior-stage','prior-module-build'}))
 retain('guest-'+str(attempt)+'.tar',archive(capture,{'root'}))
 for label,folder,names in [('build',compiled,('record.json','module-build.log','module-artifact-checks.json')),('guest',capture,('local-run.json','serial.log','run-helper.py'))]:
  for name in names: retain(label+'-'+str(attempt)+'-'+name,(folder/name).read_bytes())
for name in ('build-native-startup-tables-prototype.py','build-native-startup-tables-prototype-2.py','check-native-startup-tables-modules.py','check-native-startup-tables-modules-2.py','run-native-startup-tables-guest.py','run-native-startup-tables-validation.py','run-native-startup-tables-validation-2.py','run-native-startup-policy-tests.py','refresh-startup-ffi-ledger.py','native-startup-updated-ffi-ledger-20260907.changes.json','integrate-native-startup-stage.py','bind-native-startup-consumers.py','refresh-startup-license-bindings.py'):
 retain(name,(work/name).read_bytes())
retain('retainer.py',Path(__file__).read_bytes())
for attempt in (2,3):
 for suffix in ('log','json'):
  name='native-startup-policy-tests-20260907-'+str(attempt)+'.'+suffix
  retain(name,(work/name).read_bytes())
record=dict(schema_version=1,kind='owned-startup-tables-source-bound-prototype',recorded_utc=datetime.now(timezone.utc).isoformat(),
 source_parent=build['source_parent'],compiled_source_overlays=build['overlay'],build_outputs=build['outputs'],
 compiler=dict(status='PASS',module_architecture_and_no_simd=True),
 guest=dict(status='PASS',cpus=4,numa_nodes=2,module_cycles=2,abis=['x86_64','i386'],started_utc=run['started_utc'],finished_utc=run['finished_utc'],physical_image_readbacks=56,physical_startup_table_readbacks=56,startup_allocation_failures=64,owner_cleanup_repetitions=32,independent_table_models=run['startup_table_models'],missing_markers=[],error_markers=[],immutable_inputs_verified_at_completion=True),
 prior_failure=dict(status='FAIL',guest_attempt=1,reason='NUMA_NO_NODE passed to low-level __alloc_pages_noprof; corrected by using exported alloc_pages_noprof for policy-selected startup allocation',evidence_retained=True),
 staging=dict(status='source-and-focused-checks-integrated',declared_build_and_guest='pending',full_suite='pending'),
 ffi=dict(sources=19,sites=156,preserved_previous_ids=True,changed_ids=['RS011-SMP-0044'],new_ids=['RS011-SMP-0073','RS011-SMP-0074'],independent_review='pending'),
 production_gate_credit=False,native_mckernel_boot_proven=False,complete_rust_unification_claimed=False,
 remaining=['Declared-stage build and guest/full validation','Owned AP trampoline and boot parameters','CPU wakeup, readiness and IKC','Native mcctrl workloads','McKernel Rust/assembly-only completion','Independent production acceptance'],artifacts=artifacts)
with (repo/'docs/verification/native-startup-tables-checkpoint-20260907.json').open('x') as stream: stream.write(json.dumps(record,indent=2,sort_keys=True)+'\n')
print('Retained startup prototype, passing guest, original failure and integration evidence:',len(artifacts),'artifacts')
