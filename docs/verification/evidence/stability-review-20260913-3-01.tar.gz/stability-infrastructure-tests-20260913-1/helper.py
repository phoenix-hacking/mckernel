from pathlib import Path
from datetime import datetime,timezone
import hashlib,importlib.util,json,os,shutil,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');out=Path('/work/stability-infrastructure-tests-20260913-1');out.mkdir();(out/'tmp').mkdir()
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),commands=[],inputs=[],application_acceptance=False,production_gate_credit=False,scope='Pinned infrastructure self-tests only; no application payload or guest execution')
def identity(p):
 data=p.read_bytes();return dict(path=str(p),size=len(data),sha256=hashlib.sha256(data).hexdigest())
def save():(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
try:
 shutil.copyfile(__file__,out/'helper.py')
 sources=['scripts/application-tests/'+n for n in ['supervisor.py','runtime_contracts.py','runtime-contract.md','audit_drafts.py','verification_state.py']]+['scripts/tests/'+n for n in ['test_application_supervisor.py','test_application_runtime_contracts.py','test_application_draft_audit.py','test_verification_state.py']]
 for name in sources:
  source=repo/name;target=out/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
  record['inputs'].append(dict(original=identity(source),captured=identity(target)))
 spec=importlib.util.spec_from_file_location('supervisor',out/'source/scripts/application-tests/supervisor.py');supervisor=importlib.util.module_from_spec(spec);spec.loader.exec_module(supervisor)
 env=dict(PATH='/usr/local/bin:/usr/bin:/bin',LANG='C',LC_ALL='C',TZ='UTC',TMPDIR=str(out/'tmp'))
 commands=[('diff-check',['/usr/bin/git','-C',str(repo),'diff','--check'])]+[(name,[sys.executable,'-B',str(repo/'scripts/tests'/name),'-v']) for name in ['test_application_draft_audit.py','test_verification_state.py','test_application_supervisor.py','test_application_runtime_contracts.py']]
 for label,argv in commands:
  print('RUN',label,flush=True);record['phase']=label;save()
  result=supervisor.run_supervised(argv,cwd=str(repo),env=env,attempt_dir=str(out/label),timeout_seconds=120,cleanup_timeout_seconds=10,stdout_limit_bytes=8*1024**2,stderr_limit_bytes=8*1024**2)
  record['commands'].append(dict(label=label,argv=argv,collection=result));save()
  assert result['status']=='COMPLETED' and result['wait_status']==dict(kind='exited',code=0) and result['cleanup_complete'],(label,result['status'],result['wait_status'])
 for row in record['inputs']:
  assert identity(Path(row['original']['path']))==row['original']
  assert identity(Path(row['captured']['path']))==row['captured']
 record['status']='PASS'
except BaseException as error:record.update(status='FAIL',error_type=type(error).__name__,error=str(error));raise
finally:record['finished_utc']=datetime.now(timezone.utc).isoformat();save();print(record['status'],out,flush=True)
