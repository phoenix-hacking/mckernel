"""Retain native START, selected guest retirement contract and original runtime evidence."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, os, re, shutil, stat, subprocess, sys, tarfile
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-application-memory-retained-20260909-'+sys.argv[1]);out.mkdir()
manifest=out/'native-application-memory-checkpoint-20260909.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    artifacts=[],captures=[],references=[],native_compiler_bindings=[],guest_compiler_bindings=[],
    scope='Real native START, retained scheduled retirement, exact RET adapter routing, repeated applications and original control regressions; remaining readiness smokes are explicitly pending.',
    native_procfs_service_integrated=False,live_procfs_retirement_observed=False,
    start_integrated=False,scheduled_cleanup_integrated=False,mckernel_application_executed=False,
    production_gate_credit=False,independent_acceptance=False,original_module_failures=1)
def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())

def check_tree(source, path, excluded):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen and relative not in excluded
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), relative
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert current.is_symlink() and os.readlink(current) == member.linkname
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), relative
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), relative
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected - excluded.keys(), (source, sorted((expected - excluded.keys()) - seen)[:5])

def artifact(source, name, tree=False, excluded=None):
    excluded = excluded or {}
    path = out / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                def select(member):
                    relative = str(PurePosixPath(*PurePosixPath(member.name).parts[1:]))
                    return None if relative in excluded else member
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name, filter=select)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    with gzip.open(path, 'rb') as stream:
        while stream.read(1 << 20):
            pass
    if tree:
        check_tree(source, path, excluded)
    else:
        assert gzip.decompress(path.read_bytes()) == source.read_bytes()
    row = identity(path)
    assert row['size'] < 95 * 1024**2, row
    row.update(path='docs/verification/evidence/' + name, source=str(source))
    if excluded:
        row['scope'] = 'Complete capture except mapped, verified copies of committed evidence; restore those blobs using archive_exclusions.'
    record['artifacts'].append(row)
    print('RETAINED', name, row['size'], flush=True)

def binding(current, compiled):
    left, right = identity(current), identity(compiled)
    assert (left['size'], left['sha256']) == (right['size'], right['sha256']), str(current)
    return dict(path=str(current.relative_to(repo)), size=left['size'], sha256=left['sha256'],
                compiler_capture=str(compiled), binding='identical compiler source')

def verify(row, old_prefix=None, retained_prefix=None):
    path=Path(row['path'])
    if old_prefix is not None and path.is_relative_to(old_prefix):
        path=retained_prefix/path.relative_to(old_prefix)
    actual=identity(path)
    assert (actual['size'],actual['sha256']) == (row['size'],row['sha256']), (row,actual)


plan=json.loads((work/sys.argv[2]).read_text())
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),scope='Retained syscall-11 host invalidation, exact WAIT/RET adapters, native guest protection synchronization; full original captures including fixture import failure. No new image or actual guest acceptance.',artifacts=[],captures=[],native_compiler_bindings=[],source_bindings=[],application_readiness_complete=False,actual_guest_pass=False,guest_image_built=False,zeroing_service_integrated=False,full_capture_retention_pending=False)
try:
    shutil.copyfile(__file__,out/'helper.py');shutil.copyfile(work/sys.argv[2],out/'retention-plan.json')
    for name,expected in plan['captures']:
        directory=work/name;state=json.loads((directory/'record.json').read_text());assert state['status']==expected,(name,state['status'])
        for row in state.get('inputs',[])+state.get('outputs',[])+state.get('compiler_inputs',[]):verify(row)
        for row in state.get('overlay',[]):verify(row,work/'native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel',directory/'staged-source')
        record['captures'].append(dict(name=name,original_status=expected,record=identity(directory/'record.json')))
        artifact(directory,name+'.tar.gz',True)
    compiled=work/plan['module'];state=json.loads((compiled/'record.json').read_text())
    for item in state['compiler_inputs']:
        saved=Path(item['path']);relative=saved.relative_to(compiled/'staged-source');current=repo/'host-kernel/native-rust'/relative
        if current.read_bytes()==saved.read_bytes():record['native_compiler_bindings'].append(binding(current,saved))
        else:
            assert str(relative) in ('ihk_ioctl.rs','os_registry.rs','smp_resource.rs'),str(relative)
            replay=out/'format-replay'/relative;replay.parent.mkdir(parents=True,exist_ok=True)
            original=replay.with_suffix('.original.rs');shutil.copyfile(current,original);shutil.copyfile(current,replay)
            command=['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(replay)]
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);replay.with_suffix('.log').write_bytes(result.stdout)
            assert result.returncode==0,(command,result.stdout);assert replay.read_bytes()==saved.read_bytes(),str(current)
            row=identity(current);row['path']=str(current.relative_to(repo));row.update(binding='exact pinned rustfmt replay',compiler_capture=str(saved),formatted_sha256=identity(saved)['sha256'],replay_command=command)
            record['native_compiler_bindings'].append(row)
    assert len(record['native_compiler_bindings'])==55
    artifact(out/'format-replay','native-application-memory-20260909-format-replay.tar.gz',True)
    for current,compiled in [
        ('scripts/tests/fixtures/native-application-syscall.rs','native-application-memory-protocol-20260909-1/source/scripts/tests/fixtures/native-application-syscall.rs'),
        ('scripts/tests/fixtures/native-application-return-adapter.rs','native-application-memory-adapter-20260909-1/native-application-return-adapter.rs'),
        ('scripts/tests/fixtures/native-application-protection.rs','native-application-protection-protocol-20260909-2/native-application-protection.rs'),
        ('kernel/rust/syscall_policy.rs','native-application-protection-protocol-20260909-2/original-inputs/kernel/rust/syscall_policy.rs'),
        ('kernel/rust/abi.rs','native-application-protection-protocol-20260909-2/abi.rs'),
        ('kernel/syscall.c','native-application-protection-protocol-20260909-2/original-inputs/kernel/syscall.c'),
        ('kernel/include/process.h','native-application-protection-protocol-20260909-2/original-inputs/kernel/include/process.h')]:record['source_bindings'].append(binding(repo/current,work/compiled))
    record['review_sources']=[]
    for name in ['kernel/rust/page_alloc.rs','kernel/rust/x86_memory_helpers.rs','executer/kernel/mcctrl/rust/mcctrl_helpers.rs','kernel/CMakeLists.txt']:
        row=identity(repo/name);row['path']=name;record['review_sources'].append(row)
    reference=work/'native-source/linux-6.12.0-211.44.1.el10_2/include/linux/llist.h'
    artifact(reference,'native-application-memory-20260909-linux-llist-reference.gz')
    artifact(out/'helper.py','native-application-memory-20260909-retention-helper.gz')
    artifact(out/'retention-plan.json','native-application-memory-20260909-retention-plan.gz')
    record.update(status='PASS',finished_utc=datetime.now(timezone.utc).isoformat(),original_failures=1)
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat();manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],manifest,flush=True)
