/work/native-application-launcher-20260908-2/fallback/tmp.resolve_MODULES_END/driver.ko
/work/native-application-launcher-20260908-2/fallback/tmp.resolve_MODULES_END/driver.o

