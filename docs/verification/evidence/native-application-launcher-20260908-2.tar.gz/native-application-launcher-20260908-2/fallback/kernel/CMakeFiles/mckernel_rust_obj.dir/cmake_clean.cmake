file(REMOVE_RECURSE
  "CMakeFiles/mckernel_rust_obj"
  "rust/mckernel_rust.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/mckernel_rust_obj.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
