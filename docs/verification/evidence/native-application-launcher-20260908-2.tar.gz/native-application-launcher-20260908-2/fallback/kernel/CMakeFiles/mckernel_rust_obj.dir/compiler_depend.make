# Empty custom commands generated dependencies file for mckernel_rust_obj.
# This may be replaced when dependencies are built.
