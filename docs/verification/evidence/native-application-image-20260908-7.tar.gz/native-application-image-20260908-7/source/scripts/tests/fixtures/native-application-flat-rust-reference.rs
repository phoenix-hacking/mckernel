extern "C" { fn malloc(size: usize) -> *mut u8; pub fn free(pointer: *mut u8); }
unsafe fn cstr_len(ptr: *const u8) -> usize {
    let mut len = 0usize;
    while unsafe { *ptr.add(len) } != 0 {
        len += 1;
    }
    len
}
unsafe fn zero_bytes(dst: *mut u8, len: usize) {
    let mut idx = 0usize;
    while idx < len {
        unsafe {
            *dst.add(idx) = 0;
        }
        idx += 1;
    }
}
unsafe fn copy_ptr_bytes(dst: *mut u8, src: *const u8, len: usize) {
    let mut idx = 0usize;
    while idx < len {
        unsafe {
            *dst.add(idx) = *src.add(idx);
        }
        idx += 1;
    }
}
unsafe fn count_cstr_array(strings: *mut *mut u8) -> usize {
    if strings.is_null() {
        return 0;
    }

    let mut count = 0usize;
    while unsafe { !(*strings.add(count)).is_null() } {
        count += 1;
    }
    count
}
pub unsafe extern "C" fn mcexec_flatten_strings_result(
    pre_strings: *mut u8,
    strings: *mut *mut u8,
    flat: *mut *mut u8,
) -> i32 {
    if strings.is_null() || flat.is_null() {
        return 0;
    }

    let nr_strings = unsafe { count_cstr_array(strings) };
    let mut pre_strings_count = 0usize;
    let mut pre_strings_len = 0usize;
    let pre_strings_flat = pre_strings as *const isize;

    let mut full_len = core::mem::size_of::<isize>() + core::mem::size_of::<*mut u8>();
    if !pre_strings.is_null() {
        pre_strings_count = unsafe { *pre_strings_flat } as usize;
        let pre_end = unsafe { *pre_strings_flat.add(pre_strings_count + 1) } as usize;
        let pre_header_len = core::mem::size_of::<isize>() * (pre_strings_count + 2);
        if pre_end < pre_header_len {
            return 0;
        }
        pre_strings_len = pre_end - pre_header_len;
        let Some(next_len) = full_len
            .checked_add(pre_strings_count * core::mem::size_of::<isize>())
            .and_then(|v| v.checked_add(pre_strings_len))
        else {
            return 0;
        };
        full_len = next_len;
    }

    let mut idx = 0usize;
    while idx < nr_strings {
        let string = unsafe { *strings.add(idx) };
        let len = unsafe { cstr_len(string as *const u8) } + 1;
        let Some(next_len) = full_len
            .checked_add(core::mem::size_of::<*mut u8>())
            .and_then(|v| v.checked_add(len))
        else {
            return 0;
        };
        full_len = next_len;
        idx += 1;
    }

    let align = core::mem::size_of::<isize>() - 1;
    full_len = (full_len + align) & !align;
    let base = unsafe { malloc(full_len) };
    if base.is_null() {
        return 0;
    }
    unsafe {
        zero_bytes(base, full_len);
    }

    let flat_words = base as *mut isize;
    unsafe {
        *flat_words = (nr_strings + pre_strings_count) as isize;
    }

    let mut out =
        unsafe { base.add((nr_strings + pre_strings_count + 2) * core::mem::size_of::<isize>()) };
    if !pre_strings.is_null() {
        idx = 0;
        while idx < pre_strings_count {
            let old_offset = unsafe { *pre_strings_flat.add(idx + 1) };
            unsafe {
                *flat_words.add(idx + 1) =
                    old_offset + (nr_strings * core::mem::size_of::<isize>()) as isize;
            }
            idx += 1;
        }

        let start = unsafe { *pre_strings_flat.add(1) } as usize;
        unsafe {
            copy_ptr_bytes(out, pre_strings.add(start), pre_strings_len);
            out = out.add(pre_strings_len);
        }
    }

    idx = 0;
    while idx < nr_strings {
        let string = unsafe { *strings.add(idx) };
        let len = unsafe { cstr_len(string as *const u8) } + 1;
        unsafe {
            *flat_words.add(idx + pre_strings_count + 1) = out.offset_from(base) as isize;
            copy_ptr_bytes(out, string as *const u8, len);
            out = out.add(len);
        }
        idx += 1;
    }

    let len = unsafe { out.offset_from(base) } as usize;
    unsafe {
        *flat_words.add(nr_strings + pre_strings_count + 1) = len as isize;
        *flat = base;
    }

    if len > i32::MAX as usize {
        unsafe {
            free(base);
            *flat = core::ptr::null_mut();
        }
        return 0;
    }
    len as i32
}
