use crate::abi::*;
use core::{ffi::c_void,mem::size_of,ptr::{read_volatile,write_volatile}};
const EINVAL: CInt = 22;
const SCD_MSG_PROCFS_TID_CREATE: CInt = 0x44;
pub type ProcfsThreadPhysFn = Option<unsafe extern "C" fn(addr: *mut c_void) -> CULong>;
pub type ProcfsThreadSendFn =
    Option<unsafe extern "C" fn(channel: *mut c_void, packet: *mut IkcScdPacket) -> CInt>;
pub type ProcfsThreadPauseFn = Option<unsafe extern "C" fn()>;
unsafe fn zero_ikc_scd_packet(packet: *mut IkcScdPacket) {
    let words = size_of::<IkcScdPacket>() / size_of::<CULong>();
    let bytes = size_of::<IkcScdPacket>() % size_of::<CULong>();
    let wordp = packet.cast::<CULong>();
    let mut index = 0;

    while index < words {
        write_volatile(wordp.add(index), 0);
        index += 1;
    }

    let bytep = wordp.add(words).cast::<u8>();
    let mut byte = 0;
    while byte < bytes {
        write_volatile(bytep.add(byte), 0);
        byte += 1;
    }
}
pub unsafe extern "C" fn procfs_thread_ctl_result(
    channel: *mut c_void,
    packet: *mut IkcScdPacket,
    donep: *mut CInt,
    msg: CInt,
    osnum: CInt,
    cpu_id: CInt,
    pid: CInt,
    tid: CInt,
    phys_fn: ProcfsThreadPhysFn,
    send_fn: ProcfsThreadSendFn,
    pause_fn: ProcfsThreadPauseFn,
) -> CInt {
    let phys = match phys_fn {
        Some(phys) => phys,
        None => return -EINVAL,
    };
    let send = match send_fn {
        Some(send) => send,
        None => return -EINVAL,
    };
    if packet.is_null() || donep.is_null() {
        return -EINVAL;
    }

    zero_ikc_scd_packet(packet);
    let traditional = (&raw mut (*packet).body).cast::<IkcScdPacketTraditional>();
    (*traditional).arg = tid as CULong;
    (*packet).msg = msg;
    (*traditional).osnum = osnum;
    (*traditional).ref_ = cpu_id;
    (*traditional).pid = pid;
    (*traditional).resp_pa = phys(donep.cast::<c_void>());
    (*packet).err = 0;

    let error = send(channel, packet);
    if msg == SCD_MSG_PROCFS_TID_CREATE {
        while read_volatile(donep) == 0 {
            match pause_fn {
                Some(pause) => pause(),
                None => return if error != 0 { error } else { -EINVAL },
            }
        }
    }
    error
}
