/work/mckernel-native-clone3-images-20260909-1/invalid-sysfs-c/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-clone3-images-20260909-1/invalid-sysfs-c/tmp.resolve_MODULES_END/driver.o

