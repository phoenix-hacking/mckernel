import hashlib
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, "/home/holden/mckernel")

from scripts.tests.test_collector_storage_fault_packet import (
    StorageFaultV2SourceTests,
    oracle,
)


case = StorageFaultV2SourceTests(
    methodName="test_oracle_seven_positive_fixtures")
mutations = (
    ("schema_version", True),
    ("collector_pid", 50.0),
    ("first_failure_errno", False),
    ("collector_interruption_signal", False),
)
for field, value in mutations:
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary) / "case"
        case.write_fixture(root, 0)
        report_path = root / "collection/report.json"
        report = json.loads(report_path.read_text())
        report[field] = value
        raw = json.dumps(
            report, sort_keys=True, separators=(",", ":")).encode()
        report_path.write_bytes(raw)
        case.rebind_artifact(root, "report")
        case.refresh_supervisor(root)
        accepted = oracle.validate(root, 0, 0)
        print(field, repr(value), "ACCEPT", accepted,
              "report_sha256=" + hashlib.sha256(raw).hexdigest())
