from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, re, tarfile

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
work = Path('/work')
out = work / 'native-irq-transport-staging-retained-20260907-1'
out.mkdir()
record = dict(created_utc=datetime.now(timezone.utc).isoformat(),
              production_gate_credit=False, mckernel_boot_proven=False,
              artifacts=[], runs=[],
              passed=['443 runtime/workflow/FP-0006/license checks before the first RS-006 failure',
                      'All 27 RS-006 checks after refreshing the current workflow-test byte binding',
                      'Repository diff and native IRQ fixture formatting'],
              limitations=['Declared-stage rebuild and native-image guest replay remain next',
                           'Full repository suite still describes the earlier IRQ image checkpoint',
                           'Earlier intermittent Linux idle/RCU stall remains unresolved',
                           'No actual McKernel CPU startup, cross-kernel IKC or production acceptance'])

def sha(data):
    return hashlib.sha256(data).hexdigest()

def add(path, name):
    data = path.read_bytes()
    target = out / name
    with target.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as stream:
            stream.write(data)
    assert gzip.decompress(target.read_bytes()) == data
    record['artifacts'].append(dict(path='docs/verification/evidence/' + name,
        source=str(path), size=target.stat().st_size, sha256=sha(target.read_bytes()),
        unpacked_size=len(data), unpacked_sha256=sha(data)))

for attempt, expected in [('1', 1), ('2', 0)]:
    stem = 'native-irq-transport-policy-tests-20260907-' + attempt
    metadata = json.loads((work / (stem + '.json')).read_text())
    assert metadata['exit_code'] == expected
    log = (work / (stem + '.log')).read_text()
    count, elapsed = re.findall(r'Ran (\d+) tests in ([0-9.]+)s', log)[-1]
    record['runs'].append(dict(attempt=attempt, source_parent=metadata['source_parent'],
        tests=int(count), seconds=float(elapsed), exit_code=expected,
        started_utc=metadata['started_utc'], finished_utc=metadata['finished_utc'],
        changed_inputs=metadata['changed_inputs']))
    for suffix in ('.json', '.log'):
        add(work / (stem + suffix), stem + suffix + '.gz')
    if metadata['changed_inputs']:
        target = out / (stem + '-source-overlays.tar.gz')
        private = work / ('native-irq-transport-policy-source-20260907-' + attempt)
        with tarfile.open(target, 'w:gz') as archive:
            for row in metadata['changed_inputs']:
                source = private / row['path']
                data = source.read_bytes()
                assert len(data) == row['size'] and sha(data) == row['sha256']
                archive.add(source, arcname=row['path'])
        with tarfile.open(target, 'r:gz') as archive:
            for row in metadata['changed_inputs']:
                data = archive.extractfile(row['path']).read()
                assert len(data) == row['size'] and sha(data) == row['sha256']
        record['artifacts'].append(dict(path='docs/verification/evidence/' + target.name,
            size=target.stat().st_size, sha256=sha(target.read_bytes()),
            source=str(private), archived_files=metadata['changed_inputs']))
for name in ('run-native-irq-transport-policy-tests.py', 'refresh-irq-transport-bindings.py',
             'retain-native-irq-transport-staging.py'):
    add(work / name, 'native-irq-transport-staging-20260907-' + name + '.gz')
(out / 'native-irq-transport-staging-integration-20260907.json').write_text(
    json.dumps(record, indent=2, sort_keys=True) + '\n')
print('Retained focused IRQ transport integration:', len(record['artifacts']), 'verified artifacts')
