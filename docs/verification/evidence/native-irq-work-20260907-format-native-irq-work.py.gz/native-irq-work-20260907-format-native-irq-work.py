from pathlib import Path
import os, subprocess, sys
assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
out = Path('/work/native-irq-work-format-20260907-' + (sys.argv[1] if len(sys.argv) > 1 else '1'))
out.mkdir()
for relative in ('kernel/rust/smp_ikc.rs', 'scripts/tests/fixtures/mckernel_irq_work_compile.rs', 'scripts/tests/fixtures/mckernel_irq_work_verify.rs'):
    destination = out / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((repo / relative).read_bytes())
    subprocess.run(['rustfmt', '--edition', '2021', '--config', 'skip_children=true,reorder_modules=false', str(destination)], check=True)
print('Formatted native IRQ producer and fixture in', out)
