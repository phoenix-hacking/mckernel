from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,subprocess,sys
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');out=Path('/work/native-application-core-build-20260908-'+sys.argv[1]);out.mkdir()
record=dict(status='RUNNING',started_utc=datetime.now(timezone.utc).isoformat(),source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),commands=[],inputs=[],runtime_libraries=[],scope='Ordinary dynamically linked libc application smokes: memory, file I/O, pthread barrier/mutex/TLS/join, blocked and alternate-stack signals. Linux reference only at this build step.',mckernel_application_executed=False,production_gate_credit=False)
def identity(p):
 b=p.read_bytes();return dict(path=str(p),size=len(b),sha256=hashlib.sha256(b).hexdigest())
def run(label,command,expected=0,timeout=60):
 print('RUN',label,flush=True);(out/'phase').write_text(label+'\n')
 with (out/(label+'.log')).open('wb') as stream:r=subprocess.run(command,cwd=str(out),stdout=stream,stderr=subprocess.STDOUT,timeout=timeout)
 record['commands'].append(dict(label=label,command=command,expected=expected,exit_code=r.returncode));assert r.returncode==expected,(label,(out/(label+'.log')).read_text()[-8000:])
 return (out/(label+'.log')).read_text()
try:
 shutil.copyfile(__file__,out/'helper.py')
 source=out/'native-application-core.c';shutil.copyfile(repo/'scripts/tests/fixtures/native-application-core.c',source);record['inputs']=[identity(source)]
 run('diff-check',['git','-C',str(repo),'diff','--check'])
 record['compiler']=run('compiler',['cc','--version'])
 binary=out/'native-application-core'
 run('build',['cc','-O2','-g','-Wall','-Wextra','-Werror','-fno-pie','-no-pie','-Wl,-z,noexecstack','-pthread','-MD','-MF',str(out/'compiler.d'),str(source),'-o',str(binary)])
 header=run('elf',['readelf','-h','-l',str(binary)]);assert 'ELF64' in header and 'EXEC' in header and 'INTERP' in header
 record['linkage']='normal dynamic libc/pthread APIs, x86_64 ET_EXEC with interpreter'
 run('disassembly',['objdump','-d',str(binary)])
 libs=run('libraries',['ldd',str(binary)]);assert 'not found' not in libs
 for name in sorted(set(re.findall(r'(/[^\s()]+)\s+\(0x[0-9a-f]+\)',libs))):
  original=Path(name);target=out/'runtime'/name.lstrip('/');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,target)
  record['runtime_libraries'].append(dict(original=identity(original),captured=identity(target)))
 record['linux_reference']=[]
 for case in ['memory','files','threads','signals']:
  stdout=run('linux-reference-'+case,[str(binary),case],37,20);assert stdout=='NATIVE_CORE PASS '+case+'\n',repr(stdout)
  record['linux_reference'].append(dict(case=case,exit_code=37,stdout=stdout,mckernel=False))
 record['compiler_dependencies']=[]
 for name in (out/'compiler.d').read_text().replace('\\\n',' ').split()[1:]:
  path=Path(name)
  if path.is_absolute() and path.is_file():record['compiler_dependencies'].append(identity(path))
 assert record['compiler_dependencies']
 record.update(status='PASS',binary=identity(binary))
except BaseException as error:record.update(status='FAIL',error=str(error));raise
finally:
 record['finished_utc']=datetime.now(timezone.utc).isoformat();record['outputs']=[identity(p) for p in out.iterdir() if p.is_file() and p.name not in ('record.json','phase')];(out/'record.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');print(record['status'],out,flush=True)
