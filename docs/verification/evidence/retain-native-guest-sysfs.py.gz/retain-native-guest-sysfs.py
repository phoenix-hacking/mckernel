"""Retain actual guest sysfs evidence without duplicating committed archives."""
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import gzip, hashlib, json, os, shutil, stat, subprocess, sys, tarfile

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo = Path('/workspace')
work = Path('/work')
out = work / ('native-guest-sysfs-retained-20260908-' + sys.argv[1])
out.mkdir()
manifest = out / 'native-guest-sysfs-checkpoint-20260908.json'
record = dict(status='running', started_utc=datetime.now(timezone.utc).isoformat(),
              source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
              artifacts=[], captures=[], references=[], native_compiler_bindings=[],
              guest_compiler_bindings=[], linux_compiler_bindings=[], archive_exclusions=[],
              actual_starts=[], applications_tested=False, production_gate_credit=False,
              sysfs_service_completed=False)


def identity(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return dict(path=str(path), size=path.stat().st_size, sha256=digest.hexdigest())


def verify(row):
    assert identity(Path(row['path'])) == row, row


def bound_evidence_copies(capture, state):
    """Omit only copies that exactly match a blob at the capture's Git commit."""
    evidence = capture / 'source/docs/verification/evidence'
    if not evidence.is_dir():
        return {}
    tree = subprocess.check_output(['git', '-C', str(repo), 'ls-tree', '-r', '-z',
                                    state['source_parent'], '--', 'docs/verification/evidence'])
    blobs = {}
    for raw in tree.split(b'\0'):
        if raw:
            info, name = raw.split(b'\t', 1)
            blobs[name.decode()] = info.split()[2].decode()
    excluded = {}
    for path in sorted(evidence.rglob('*')):
        if path.is_dir():
            continue
        assert path.is_file() and not path.is_symlink(), str(path)
        current = identity(path)
        relative = str(path.relative_to(capture / 'source'))
        blob = hashlib.sha1(('blob %d\0' % current['size']).encode())
        with path.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1 << 20), b''):
                blob.update(chunk)
        assert blob.hexdigest() == blobs[relative], relative
        retained = identity(repo / relative)
        assert (retained['size'], retained['sha256']) == (current['size'], current['sha256'])
        relative_capture = str(path.relative_to(capture))
        excluded[relative_capture] = dict(relative_capture=relative_capture,
            git_path=relative, git_blob=blobs[relative], size=current['size'],
            sha256=current['sha256'], mode=stat.S_IMODE(path.stat().st_mode),
            mtime_ns=path.stat().st_mtime_ns)
    record['archive_exclusions'].append(dict(capture=str(capture), commit=state['source_parent'],
        criterion='Only byte-identical copies of already committed evidence; all other capture entries are archived, including source and Git metadata.',
        files=list(excluded.values()), bytes=sum(row['size'] for row in excluded.values())))
    return excluded


def check_tree(source, path, excluded):
    seen = set()
    with tarfile.open(path, 'r:gz') as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name).parts
            assert parts and parts[0] == source.name and '..' not in parts
            relative = str(PurePosixPath(*parts[1:]))
            assert relative not in seen and relative not in excluded
            seen.add(relative)
            current = source / relative
            info = current.lstat()
            assert stat.S_IMODE(info.st_mode) == stat.S_IMODE(member.mode), relative
            if member.isdir():
                assert stat.S_ISDIR(info.st_mode)
            elif member.issym():
                assert current.is_symlink() and os.readlink(current) == member.linkname
            else:
                assert stat.S_ISREG(info.st_mode) and (member.isfile() or member.islnk()), relative
                digest = hashlib.sha256()
                size = 0
                with archive.extractfile(member) as stream:
                    for chunk in iter(lambda: stream.read(1 << 20), b''):
                        size += len(chunk)
                        digest.update(chunk)
                actual = identity(current)
                assert (size, digest.hexdigest()) == (actual['size'], actual['sha256']), relative
    expected = {'.'}
    for parent, dirs, files in os.walk(source, followlinks=False):
        expected.update(str((Path(parent) / name).relative_to(source)) for name in dirs + files)
    assert seen == expected - excluded.keys(), (source, sorted((expected - excluded.keys()) - seen)[:5])


def artifact(source, name, tree=False, excluded=None):
    excluded = excluded or {}
    path = out / name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            if tree:
                def select(member):
                    relative = str(PurePosixPath(*PurePosixPath(member.name).parts[1:]))
                    return None if relative in excluded else member
                with tarfile.open(fileobj=compressed, mode='w') as archive:
                    archive.add(source, arcname=source.name, filter=select)
            else:
                with source.open('rb') as stream:
                    shutil.copyfileobj(stream, compressed)
    with gzip.open(path, 'rb') as stream:
        while stream.read(1 << 20):
            pass
    if tree:
        check_tree(source, path, excluded)
    else:
        assert gzip.decompress(path.read_bytes()) == source.read_bytes()
    row = identity(path)
    assert row['size'] < 95 * 1024**2, row
    row.update(path='docs/verification/evidence/' + name, source=str(source))
    if excluded:
        row['scope'] = 'Complete capture except mapped, verified copies of committed evidence; restore those blobs using archive_exclusions.'
    record['artifacts'].append(row)
    print('RETAINED', name, row['size'], flush=True)


def binding(current, compiled):
    left, right = identity(current), identity(compiled)
    assert (left['size'], left['sha256']) == (right['size'], right['sha256']), str(current)
    return dict(path=str(current.relative_to(repo)), size=left['size'], sha256=left['sha256'],
                compiler_capture=str(compiled), binding='identical compiler source')


try:
    shutil.copyfile(__file__, out / 'helper.py')
    for name in ['native-sysfs-snoop-boundary-checkpoint-20260908.json',
                 'native-sysfs-service-checkpoint-20260908.json',
                 'native-vdso-service-checkpoint-20260907.json']:
        path = repo / 'docs/verification' / name
        value = json.loads(path.read_text())
        assert value['status'] == 'PASS'
        reference = identity(path)
        reference['path'] = str(path.relative_to(repo))
        record['references'].append(reference)
        for row in value['artifacts']:
            retained = repo / row['path']
            actual = identity(retained)
            assert (actual['size'], actual['sha256']) == (row['size'], row['sha256'])
            with gzip.open(retained, 'rb') as stream:
                while stream.read(1 << 20):
                    pass
    captures = [
        ('native-guest-sysfs-format-20260908-1', 'FAIL'),
        ('native-guest-sysfs-format-20260908-2', 'PASS'),
        ('mckernel-native-sysfs-images-20260908-1', 'FAIL'),
        ('mckernel-native-sysfs-images-20260908-2', 'PASS'),
        ('native-guest-sysfs-20260908-verify-x86_64-1', 'FAIL'),
        ('native-guest-sysfs-20260908-verify-x86_64-2', 'PASS'),
        ('native-guest-sysfs-20260908-verify-i386-1', 'PASS'),
        ('native-guest-sysfs-20260908-normal-x86_64-1', 'PASS'),
        ('native-guest-sysfs-20260908-normal-i386-1', 'PASS'),
    ]
    for name, expected in captures:
        capture = work / name
        state = json.loads((capture / 'record.json').read_text())
        assert state['status'] == expected, (name, state['status'])
        for row in state.get('inputs', []) + state.get('outputs', []) + state.get('production_inputs', []):
            verify(row)
        if 'input' in state:
            original = identity(capture / 'original.rs')
            assert (original['size'], original['sha256']) == (state['input']['size'], state['input']['sha256'])
        for row in state.get('images', []):
            for item in row['outputs']:
                verify(item)
        for row in state.get('captures', []):
            for item in row['artifacts']:
                verify(item)
        excluded = bound_evidence_copies(capture, state)
        artifact(capture, name + '.tar.gz', True, excluded)
        artifact(capture / 'record.json', name + '-record.json.gz')
        record['captures'].append(dict(path=str(capture), status=expected))
    # Bind the unchanged native production module through its prior exact input
    # and pinned-format records. No new native module build is claimed here.
    prior = json.loads((repo / 'docs/verification/native-sysfs-snoop-boundary-checkpoint-20260908.json').read_text())
    for row in prior['compiler_inputs']:
        if not row['path'].startswith('host-kernel/native-rust/'):
            continue
        current, compiled = identity(repo / row['path']), identity(Path(row['compiler_capture']))
        assert (current['size'], current['sha256']) == (row['source_size'], row['source_sha256'])
        assert (compiled['size'], compiled['sha256']) == (row['size'], row['sha256'])
        record['native_compiler_bindings'].append(row)
    image_capture = work / 'mckernel-native-sysfs-images-20260908-2'
    image_state = json.loads((image_capture / 'record.json').read_text())
    assert [row['kind'] for row in image_state['images']] == ['fallback', 'legacy-rust', 'native-rust', 'native-sysfs-verify']
    assert [row['native_sysfs_verify'] for row in image_state['images']] == [False, False, False, True]
    negative = [row for row in image_state['results'] if row['label'].startswith('reject-')]
    assert len(negative) == 4 and all(row['exit_code'] != 0 for row in negative)
    assert all(row['exit_code'] == 0 for row in image_state['results'] if not row['label'].startswith('reject-'))
    image_source = image_capture / 'source'
    guest_paths = sorted((image_source / 'kernel/rust').rglob('*.rs'))
    guest_paths += [image_source / p for p in ['kernel/CMakeLists.txt',
        'scripts/tests/fixtures/mckernel_guest_sysfs.rs', 'host-kernel/native-rust/abi/vdso.rs']]
    for path in guest_paths:
        record['guest_compiler_bindings'].append(binding(repo / path.relative_to(image_source), path))
    for name, expected in captures[-4:]:
        assert expected == 'PASS'
        capture = work / name
        state = json.loads((capture / 'record.json').read_text())
        assert state['boot_ioctl'] == 0 and state['registry_status'] == 4 and state['physical_status'] == 3
        assert state['observed_callback_exchanges'] == 130 and state['guest_store_payload_checks'] == 64
        for path in sorted((capture / 'probe-source').iterdir()):
            record['linux_compiler_bindings'].append(binding(repo / 'scripts/tests/fixtures' / path.name, path))
        record['actual_starts'].append({key: state[key] for key in ['architecture', 'profile',
            'boot_ioctl', 'registry_status', 'physical_status', 'observed_callback_exchanges',
            'guest_store_payload_checks']})
        if state['profile'] == 'verify':
            fixture = state['actual_guest_fixture']
            assert fixture['metadata_requests'] == 52 and fixture['expected_metadata_errors'] == 9
            assert fixture['value_reads'] == 260 and fixture['value_stores'] == 256 and fixture['remote_releases'] == 8
            record['actual_starts'][-1]['fixture'] = fixture
    baseline = work / 'mckernel-native-irq-images-20260907-13/native-rust/kernel/mckernel.img'
    record['original_passing_image'] = identity(baseline)
    assert record['original_passing_image']['sha256'] == 'c37e6e7d30e09079003bcb9ed80baf27acc18f9d60d472e79826629b01a62e80'
    for name in ['build-mckernel-native-sysfs-images.py', 'format-native-guest-sysfs.py', 'run-native-guest-sysfs.py']:
        artifact(work / name, name + '.gz')
    artifact(out / 'helper.py', 'retain-native-guest-sysfs.py.gz')
    # Final accounting and limitations are filled below before status is PASS.
    record.update(status='PASS', full_ready_observed=True, image_profiles_built=4,
        negative_configuration_checks=4, actual_starts_passed=4, physical_ready_captures=8,
        actual_metadata_requests=118, expected_metadata_errors=18, special_reads=18,
        value_reads=520, value_stores=512, checked_data_release_callbacks=16,
        forbidden_duplicate_release_callbacks=0, remote_error_checks=12, local_snoop_store_errors=2,
        full_capacity_file_reads=4, full_page_store_checks=2, fixture_namespaces_retired=2,
        post_ready_callback_exchanges=520, guest_online_store_payload_checks=256,
        pre_ready_callback_exchanges=sum(row.get('fixture', {}).get('pre_ready_callback_exchanges', 0) for row in record['actual_starts']),
        scope='Actual McKernel guest metadata, mapped special formats, independent concurrent values, transfer bounds and callback release through both startup ABIs, with normal-image regressions',
        limitations=[
            'One actual McKernel CPU runs inside each four-vCPU/two-NUMA Linux TCG guest. The 32-bit startup ioctl probe uses the same 64-bit Linux sysfs controller.',
            'The opt-in fixture pauses the normal boot thread until its Linux controller completes. It uses real guest requests and callbacks and no substituted IHK identities; normal image profiles exclude the fixture.',
            'Value readers are joined before their subtree is removed. This proves actual metadata/release progress and exactly-once data callbacks; forced in-flight value-read removal races remain covered only by the prior Linux fixture.',
            'The first formatting helper, image negative-diagnostic comparison and guest missing-store expectation failed and remain FAIL. Retained corrected attempts do not overwrite them.',
            'The image build archived a then-current Linux controller source it did not compile. Only the separate Linux guest captures bind the corrected controller used in passing runs.',
            'Image archives omit only redundant evidence copies verified against committed Git blobs. The full exclusion manifest supplies content hashes, modes and restoration identities; all compiler inputs, other capture files and Git metadata are retained.',
            'Native host modules are unchanged from snooping module attempt 3 and are bound to its prior verified sources; no new host module build or full repository suite is claimed.',
            'The ordinary guest CPU online store still only logs and acknowledges bytes. It does not change CPU state.',
            'Continuing worker/queue allocation faults, multiple active McKernel CPUs/OSes, native application services, application execution, shutdown, full Rust/assembly migration, current declared integration and independent production acceptance remain open. No production gate is promoted.'
        ])
except BaseException as error:
    record.update(status='FAIL', error=str(error))
    raise
finally:
    record['finished_utc'] = datetime.now(timezone.utc).isoformat()
    manifest.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(record['status'], out, flush=True)
