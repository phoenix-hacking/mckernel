"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Selected SDK source/default tool compiler operation using accepted h990 ownership.
No device/CLI execution, Rust library rebuild, root action, or native credit.
"""
from pathlib import Path
import ast,hashlib,json,os,re,resource,signal,stat,sys,time
entered=time.monotonic()
CONFIG = Path('/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/actual-source-SDK11-installed-consumer-preparation-1/sdk-install-top-level-mount-correction-1/TARGET-INSTALL.INPUTS.json')
CONFIG_SHA = '6ccc4485a58d68ace817ec5fc59b1db98f1fa8b13652dd1534cfa426d87c6ca1'
TOOL_RULES={'/nightly/bin/rustc': ('readonly-mounted-nightly', '70ebcbbaa352a2d0ef5401eea226b0e61320840430b5c15ad016fb3dc8b54e09'), '/usr/bin/cc': ('readonly-image', '2092e32fa9abee9ccbf777a5f893b9cc608582b660c93e742a17c3eb7da109c2'), '/usr/include/bfd.h': ('readonly-image', 'de900a9fe4ac94543ee1382cebc3063c3d7e20d16bc934fc816133dd55fe2432'), '/usr/lib64/libbfd.so': ('readonly-image', '6cfd31804974c248c9512879e7b77a94862f92150c2171d901140464ea936ab3'), '/usr/bin/cmake': ('readonly-image', 'a2ec9c59d15b48b6abba45cfaa873df186e01a2e3ca99302ada1e51637f4cfd1'), '/usr/bin/nm': ('readonly-image', 'df99ae7b36cf9aa2da1e447026082ae5faddb7d7f12ebce911503c3022ed4bf1'), '/usr/bin/readelf': ('readonly-image', 'c5e0de5f419ed907fdc0b7b0a6087ff5c54a8c68db4da01097bdf84a296349b7')}
D = Path('/work/output/selected-install-captures')
def need(ok, why):
    if not ok: raise RuntimeError(why)

def digest(p):
    p=Path(p);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        first=os.fstat(fd);need(stat.S_ISREG(first.st_mode) and first.st_nlink==1,'regular singlelink source')
        value=hashlib.sha256();size=0
        for block in iter(lambda:os.read(fd,65536),b''):
            size+=len(block);need(size<=32<<20,'bounded input hash');value.update(block)
        last=os.fstat(fd);path=p.lstat()
        fields=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
        need(size==last.st_size and all(getattr(first,k)==getattr(last,k)==getattr(path,k) for k in fields),'stable input FD')
        return value.hexdigest()
    finally:os.close(fd)

def tool_digest(alias):
    target=None; first_metadata=None; final_metadata=None; path_metadata=None; fd=None
    try:
        need(alias in TOOL_RULES, 'fixed tool alias required')
        tool_class,expected=TOOL_RULES[alias]
        target=Path(alias).resolve(strict=True)
        fd=os.open(target,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
        fields=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
        first=os.fstat(fd)
        first_metadata={k:getattr(first,k) for k in fields}
        need(stat.S_ISREG(first.st_mode) and
             (first.st_nlink==1 if tool_class=='readonly-mounted-nightly' else first.st_nlink>=1),
             'fixed tool regular/link policy')
        value=hashlib.sha256();size=0
        for block in iter(lambda:os.read(fd,65536),b''):
            size+=len(block);need(size<=32<<20,'bounded tool hash');value.update(block)
        last=os.fstat(fd);path=target.lstat()
        final_metadata={k:getattr(last,k) for k in fields}
        path_metadata={k:getattr(path,k) for k in fields}
        need(size==last.st_size and first_metadata==final_metadata==path_metadata,
             'stable fixed tool FD/path metadata')
        need(Path(alias).resolve(strict=True)==target,'fixed tool alias retargeted')
        digest_value=value.hexdigest();need(digest_value==expected,'exact pinned tool hash')
        return dict(alias=alias,tool_class=tool_class,resolved_path=str(target),sha256=digest_value,
                    first_metadata=first_metadata,final_metadata=final_metadata,path_metadata=path_metadata)
    except Exception as exc:
        raise RuntimeError('fixed tool alias='+str(alias)+' target='+str(target)+
                           ' first='+repr(first_metadata)+' final='+repr(final_metadata)+
                           ' path='+repr(path_metadata)+': '+str(exc)) from exc
    finally:
        if fd is not None:os.close(fd)

def retained_archive_snapshot(path):
    path=Path(path);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        first=os.fstat(fd);last=os.fstat(fd);named=path.lstat()
        fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
        need(stat.S_ISREG(first.st_mode) and first.st_nlink==1 and
             all(getattr(first,k)==getattr(last,k)==getattr(named,k) for k in fields),'stable retained archive FD metadata')
        return dict(device=first.st_dev,inode=first.st_ino,mode=oct(stat.S_IMODE(first.st_mode)),
                    nlink=first.st_nlink,uid=first.st_uid,gid=first.st_gid,size=first.st_size,
                    mtime_ns=first.st_mtime_ns,ctime_ns=first.st_ctime_ns)
    finally:os.close(fd)

def positive(r):
 return r['returncode']==0 and r['direct_child_joined'] and r['group_absent'] and r['closed_streams'] and r['error'] is None and r['retirement_error'] is None and not r['timed_out']
def validate_libdwarf_vendor(spec, root, host_identity=False):
    import hashlib, json, os, stat
    from pathlib import Path
    def require(ok, message):
        if not ok:
            raise ValueError(message)
    def read_stable(path, expected_sha, expected_mode=None):
        path=Path(path)
        require(path.is_absolute() and path.resolve()==path, 'literal resolved vendor input')
        fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
        try:
            a=os.fstat(fd)
            require(stat.S_ISREG(a.st_mode) and a.st_size<=32<<20, 'bounded regular vendor source')
            if expected_mode is not None:
                require(stat.S_IMODE(a.st_mode)==expected_mode, 'exact vendor source mode')
            h=hashlib.sha256(); count=0
            while True:
                block=os.read(fd,65536)
                if not block: break
                count+=len(block);h.update(block)
            z=os.fstat(fd);n=path.lstat()
            fields=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
            require(all(getattr(a,k)==getattr(z,k)==getattr(n,k) for k in fields), 'stable9 vendor source')
            require(count==z.st_size and h.hexdigest()==expected_sha, 'accepted vendor source bytes')
        finally:
            os.close(fd)
    root=Path(root)
    require(root.is_absolute() and root.resolve()==root and root.is_dir(), 'exact vendor root')
    if host_identity:
        s=root.stat(); actual=dict(device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=stat.S_IMODE(s.st_mode))
        require(actual==spec['HOST_identity'], 'retained vendor root identity')
    authority=spec['authority'];read_stable(authority['path'],authority['sha256'])
    selected=json.loads(Path(authority['path']).read_bytes())['consumed_gitlinks'][spec['gitlink']]
    require(selected['commit']==spec['commit'] and selected['files']==spec['files'] and len(selected['files'])==412, 'full accepted gitlink authority')
    require(set(spec['configure_and_target_required_paths'])<=selected['files'].keys(), 'finite CMake vendor closure')
    for relative,row in sorted(selected['files'].items()):
        rel=Path(relative)
        require(not rel.is_absolute() and '..' not in rel.parts and row['mode'] in ('100644','100755'), 'fixed vendor path/mode')
        read_stable(root/rel,row['sha256'],int(row['mode'],8)&0o777)
    return dict(verified_vendor_files=412,configure_and_target_paths=len(spec['configure_and_target_required_paths']),commit=spec['commit'])

def validate_canonical_source_snapshot(packet):
 for relative,row in packet['canonical_source_inputs'].items():
  path=Path('/src')/relative
  need(path.is_file() and path.stat().st_size==row['bytes'] and digest(path)==row['sha256'],'canonical actual source snapshot '+relative)

def validate_new_source_producer():
 base=Path('/work/output/whole70-tool-default/ihk/linux/user/rust/whole70')
 row=json.loads((base/'producer-receipt.json').read_bytes())
 need(row['status']=='PASS_REAL_HEADERS_AND_ONE_RUST_STATICLIB_BUILD_ONLY' and row['C_runtime_TU'] is False and row['native'] is False,'real canonical producer build scope')
 need(len(row['commands'])==10 and all(x['returncode']==0 for x in row['commands']),'four real-header compiles/five metadata runs/one Rust compile')
 last=row['commands'][-1]['argv']
 need(last[0]=='/nightly/bin/rustc' and last[-1]=='/src/ihk/linux/user/rust/whole70/libihklib_whole70.rs' and not any('/retained/' in a for a in last),'canonical source Rust invocation, no external archive shortcut')
 for flag in ('staticlib','ihklib_host_std_runtime','ihklib_stat_abi_stat','panic=abort','codegen-units=1','relocation-model=pic','opt-level=2','native-static-libs'):
  need(flag in last,'same real producer flag '+flag)
 need(row['stat_cfg']=='ihklib_stat_abi_stat' and (base/'actual-stat-cfg.txt').read_bytes()==b'ihklib_stat_abi_stat\n','actual generated platform cfg')
 native=['-lgcc_s','-lutil','-lrt','-lpthread','-lm','-ldl','-lc']
 need(row['native_static_libs']==native and (base/'native-static-libs.rsp').read_text().splitlines()==native,'samecompile native flag order')
 for name in ('perf_pages_abi.rs','dump_abi.rs','diagnostic_origins.rs','create_diagnostic_origins.rs'):
  need((base/name).is_file() and b'pub const ' in (base/name).read_bytes(),'actual header metadata '+name)
 need(row['archive']==str(base/'libihklib_whole70.a'),'new produced archive path')
 link=(Path('/work/output/whole70-tool-default/ihk/linux/user/CMakeFiles/ihklib.dir/link.txt')).read_text()
 need('libihklib_whole70.a' in link and 'native-static-libs.rsp' in link and '/retained/' not in link,'actual default library source-produced link inputs')
 return dict(canonical_source_produced=True,producer_commands=10,metadata_outputs=5,native_static_libs=native,archive=str(base/'libihklib_whole70.a'))

def main():
 need(digest(CONFIG)==CONFIG_SHA,'exact install packet');p=json.loads(CONFIG.read_bytes());phase=p['install_phase']
 need(os.getuid()==os.getgid()==1000 and os.sched_getaffinity(0)=={2,3,4,5},'reviewed SDK UID/CPUs')
 for row in p['source_inputs']+p['accepted_input_records']:
  need(Path(row['path']).stat().st_size==row['bytes'] and digest(row['path'])==row['sha256'],'source/authority pin')
 validate_canonical_source_snapshot(p)
 verdict=json.loads(Path(phase['independent_source_sdk_acceptance']['path']).read_bytes())
 need(verdict['decision']=='PASS_ACTUAL_SELECTED_SDK_CANONICAL_SOURCE_PRODUCER_ABI_LINK','genuine source-SDK11 authority')
 prior=json.loads(Path(phase['accepted_receipt']['path']).read_bytes())
 need(prior['status']=='PASS_SELECTED_SDK_TARGET_TOOLS_CMAKE_ABI_LINK_ONLY' and prior['source_identity']==p['source_identity'] and prior['C_library_TU'] is False,'accepted selected Rust build')
 def source_stat(name):
  item=phase['source_artifacts'][name]['producer_descriptor'];host=Path('/selected-sdk11-output')/Path(item['path']).relative_to('/work/output/whole70-tool-default');s=host.stat()
  observed=dict(device=s.st_dev,inode=s.st_ino,uid=s.st_uid,gid=s.st_gid,mode=oct(stat.S_IMODE(s.st_mode)),nlink=s.st_nlink,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
  need(all(observed[k]==item[k] for k in observed),'accepted artifact stable identity '+name);return observed
 before_sources={name:source_stat(name) for name in phase['source_artifacts']}
 before_tools={k:tool_digest(k) for k in TOOL_RULES}
 plan=json.loads(Path(p['operation']['path']).read_bytes());need(len(plan['commands'])==4 and [x['index'] for x in plan['commands']]==list(range(4)),'finite4 install/loader phases')
 h=p['capture_helper'];need(digest(h['path'])==h['sha256']=='990807ab7ecaee4bd4386908270e2d68f2172d09b505a5602949247dd3e7fdc8','h990')
 names={'need','write','hashed','stop','members','process_start','terminal_unreaped','wait_terminal','owned_capture'};assignments={'FIELDS','stopping','CENSUS_SOURCE','CENSUS_SHA','_CENSUS','STOP_SIGNALS'}
 nodes=[n for n in ast.parse(Path(h['path']).read_bytes()).body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name in names or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in assignments for t in n.targets)]
 ns={'__file__':h['path']};exec(compile(ast.Module(body=nodes,type_ignores=[]),h['path'],'exec'),ns)
 def budget():
  a=resource.getrusage(resource.RUSAGE_SELF);b=resource.getrusage(resource.RUSAGE_CHILDREN)
  need(a.ru_utime+a.ru_stime+b.ru_utime+b.ru_stime<=60,'whole CPU acceptance60')
  need(time.monotonic()-entered<90,'whole active wall90')
  need(sum(q.stat().st_size for q in Path('/work').rglob('*') if q.is_file())<=512<<20,'aggregate512MiB')
 def limits():
  for k,v in ((resource.RLIMIT_AS,2<<30),(resource.RLIMIT_CPU,60),(resource.RLIMIT_FSIZE,32<<20),(resource.RLIMIT_NOFILE,256),(resource.RLIMIT_CORE,0),(resource.RLIMIT_STACK,2<<20)):resource.setrlimit(k,(v,v))
  os.sched_setaffinity(0,{2,3,4,5})
 need(not D.exists() and not Path('/work/evidence').exists() and not Path(phase['installed_prefix']).exists(),'fresh install/captures/evidence')
 Path('/work/output').mkdir(mode=0o700);D.mkdir(mode=0o700);Path('/work/evidence').mkdir(mode=0o700);os.chdir(D)
 for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGALRM):signal.signal(sig,ns['stop'])
 rows=[];artifacts={};receipt=dict(schema='mckernel.sdk-installed-tools-receipt.v1',status='FAIL',commands=rows,artifacts=artifacts,native=False,default_acceptance=False,CLI_executed=False,C_library_TU=False,source_identity=p['source_identity'],configuration_sha256=CONFIG_SHA,accepted_source_receipt=phase['accepted_receipt'])
 budget();signal.setitimer(signal.ITIMER_REAL,90-(time.monotonic()-entered))
 try:
  for item in plan['commands']:
   budget();q=D/('%02d'%item['index']);q.mkdir(mode=0o700);cmd=dict(argv=item['argv'],purpose=item['purpose']);ns['write'](q/'command.json',cmd)
   remaining=90-(time.monotonic()-entered);need(remaining>0,'shared90 deadline before phase launch');result=ns['owned_capture'](cmd,q,remaining,limits)
   rows.append(dict(command=item,result=result));ns['write'](q/'RESULT.json',rows[-1]);budget();need(positive(result),'first install/loader failure STOP')
   need((q/'stderr').stat().st_size==0,'no unexpected install/loader stderr')
   if item['index']==0:
    paths={'libihk.so':'lib64/libihk.so','ihkconfig':'sbin/ihkconfig','ihkosctl':'sbin/ihkosctl','mcps':'bin/mcps'}
    prefix=Path(phase['installed_prefix']);seen={str(x.relative_to(prefix)) for x in prefix.rglob('*') if x.is_file()};need(seen==set(paths.values()),'exact four selected installed files')
    for name,relative in paths.items():
     path=prefix/relative;need(not path.is_symlink() and path.stat().st_nlink==1 and stat.S_IMODE(path.stat().st_mode)==0o755,'owned installed file '+name);artifacts[str(path)]=ns['hashed'](path,32<<20)
    ns['write'](q/'DURABLE-INSTALLED-ARTIFACTS.json',artifacts)
   else:
    text=(q/'stdout').read_text();need(text and 'not found' not in text and '/retained/' not in text and '/src/' not in text,'closed target loader dependency resolution')
    if item['index'] in (1,2):
     lines=[line.strip() for line in text.splitlines() if line.strip().startswith('libihk.so => ')]
     need(len(lines)==1 and lines[0].startswith('libihk.so => '+phase['installed_prefix']+'/lib64/libihk.so ('),'actual installed DSO selected')
    else:need('libihk.so =>' not in text,'mcps no project DSO dependency')
  need({name:source_stat(name) for name in phase['source_artifacts']}==before_sources,'all4 retained artifacts postflight stable')
  need({k:tool_digest(k) for k in TOOL_RULES}==before_tools,'same target tools postflight');validate_canonical_source_snapshot(p)
  budget();receipt.update(status='PASS_SELECTED_SDK_FOUR_INSTALL_THREE_LOADER_ONLY',installed_files=4,loader_checks=3,source_artifact_stats_stable=True,tool_preflight=before_tools,tool_postflight=before_tools)
 except BaseException as exc:
  receipt['error']=str(exc);raise
 finally:
  ns['write'](Path('/work/evidence/receipt.json'),receipt);signal.setitimer(signal.ITIMER_REAL,0)
if __name__=='__main__':main()
