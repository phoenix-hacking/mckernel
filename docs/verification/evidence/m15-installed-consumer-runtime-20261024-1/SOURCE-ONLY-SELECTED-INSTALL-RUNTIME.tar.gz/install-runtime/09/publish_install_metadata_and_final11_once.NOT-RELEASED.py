"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
One ordinary UID1000 metadata publication: exclusive empty HOST candidate and
exact completed request/11-source map. No owner import/API/query/release execution.
"""
from pathlib import Path
import hashlib,json,os,stat,sys,uuid
D=Path(__file__).resolve().parent
REQUEST = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/actual-source-SDK11-installed-consumer-preparation-1/sdk-install-top-level-mount-correction-1/REQUEST.INSTALL.NAMESPACE-PENDING.json', 'sha256': '1aa3b740f5455f222be2b16d88e4e1d776ff975c2972b5412b22a0d36fa6916e', 'bytes': 2379}
RELEASE = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/actual-source-SDK11-installed-consumer-preparation-1/sdk-install-top-level-mount-correction-1/RELEASE.INSTALL.NO-CLOCK-NO-APPROVAL.json', 'sha256': '56c94752031620cb11e7c88e8a55887f6ddf255a4dc3178ea3cf1401388525d1', 'bytes': 4440}
OWNER = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/actual-source-SDK11-installed-consumer-preparation-1/sdk-install-top-level-mount-correction-1/target_tools_sdk_owner.py', 'sha256': '2ec8e85696e47f9abcfa2a5eeada22880471ecdd022dc89424480d950184a03f', 'bytes': 190704}
DRIVER = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/actual-source-SDK11-installed-consumer-preparation-1/sdk-install-top-level-mount-correction-1/target_tools_sdk_driver.py', 'sha256': 'b15e0a5bc85c8d517c7804aba5e0d0e36ca76231a7dd672221b2839a29f2c328', 'bytes': 16333}
MATERIAL = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/bounded-top-level-cache-dependency-correction-1/source-materialization-1/MATERIALIZATION-RESULT.json', 'sha256': 'b10506718afea887425328be21c2217986608ad7ed0680aff55d517b8891f271', 'bytes': 11217}
PROOF = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/actual-source-SDK11-installed-consumer-preparation-1/sdk-install-top-level-mount-correction-1/STATIC-INSTALL-OPERATION-SOURCE-JOIN.json', 'sha256': '96687b95bc49220356ab074d5c3f8feb1c9c4481ee42bad2fdaf0506acd5e921', 'bytes': 6008}

PREPARATION = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/actual-source-SDK11-installed-consumer-preparation-1/sdk-install-top-level-mount-correction-1/preparation.json', 'sha256': '8e7675d63115699d84defd9a5f23a13c0c374f93e529dad8f4e8c6926d1d9d13', 'bytes': 146170}
CONFIGURATION = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/actual-source-SDK11-installed-consumer-preparation-1/sdk-install-top-level-mount-correction-1/TARGET-INSTALL.INPUTS.json', 'sha256': '6ccc4485a58d68ace817ec5fc59b1db98f1fa8b13652dd1534cfa426d87c6ca1', 'bytes': 150247}

def need(ok,message):
 if not ok:raise ValueError(message)
def read(ref):
 p=Path(ref['path']);fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  a=os.fstat(fd);need(stat.S_ISREG(a.st_mode) and a.st_nlink==1 and a.st_size<=32<<20,'bounded regular input');blocks=[]
  while True:
   b=os.read(fd,65536)
   if not b:break
   blocks.append(b)
  raw=b''.join(blocks);z=os.fstat(fd);n=p.lstat();keys=('st_dev','st_ino','st_uid','st_gid','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
  need(all(getattr(a,k)==getattr(z,k)==getattr(n,k) for k in keys) and len(raw)==z.st_size and len(raw)==ref['bytes'] and hashlib.sha256(raw).hexdigest()==ref['sha256'],'stable9 pinned input');return raw
 finally:os.close(fd)
def node(path):
 p=Path(path);need(p.is_dir() and not p.is_symlink(),'owned directory');s=p.stat();need(s.st_uid==s.st_gid==1000 and stat.S_IMODE(s.st_mode)==0o700,'private directory identity');return dict(path=str(p),device=s.st_dev,inode=s.st_ino,mode=stat.S_IMODE(s.st_mode),uid=s.st_uid,gid=s.st_gid)
def publish(path,value):
 raw=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode();fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 parent=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(parent)
 finally:os.close(parent)
 return dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
MOUNTPOINT = '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/bounded-top-level-cache-dependency-correction-1/source-materialization-1/materialized-source/executer/user/lib/libdwarf/libdwarf'
MOUNTPOINT_PARENT = {'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/bounded-top-level-cache-dependency-correction-1/source-materialization-1/materialized-source/executer/user/lib/libdwarf', 'device': 66306, 'inode': 58496722, 'uid': 1000, 'gid': 1000, 'mode': 448}

def create_vendor_mountpoint():
 need(node(MOUNTPOINT)=={'device': 66306, 'gid': 1000, 'inode': 59269718, 'mode': 448, 'path': '/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m15-libihk-next/canonical-source-producer-SDK-target-operation-1/bounded-top-level-cache-dependency-correction-1/source-materialization-1/materialized-source/executer/user/lib/libdwarf/libdwarf', 'uid': 1000}, 'reuse actual accepted empty vendor mountpoint identity')
 p=Path(MOUNTPOINT);need(not list(p.iterdir()), 'accepted vendor mountpoint remains empty')
 return node(p)

def main():
 need(sys.argv[1:]==['--publish-metadata-once'] and os.getuid()==os.geteuid()==os.getgid()==1000,'exact ordinary UID1000 metadata invocation')
 request=json.loads(read(REQUEST));release=json.loads(read(RELEASE));read(OWNER);read(DRIVER);read(PREPARATION);read(CONFIGURATION);material=json.loads(read(MATERIAL));proof=json.loads(read(PROOF));need(proof['missing']==[],'complete static read-path join')
 need(material['status']=='PASS_FINITE_TARGET_SOURCE_MATERIALIZATION_ONLY' and node(material['source_root'])==material['source_identity'],'actual materialized source identity')
 need(not (D/'workspace').exists() and not (D/'REQUEST.ROOT.FINAL.json').exists(),'fresh finite namespace/publication')
 mountpoint_identity=create_vendor_mountpoint()
 nonce=uuid.uuid4().hex;parent=D/'workspace';parent.mkdir(mode=0o700);candidate=parent/('native-running-modules-candidate-'+nonce);candidate.mkdir(mode=0o700);evidence=parent/('native-running-modules-owner-'+nonce)
 request.update(libdwarf_mountpoint_identity=mountpoint_identity,nonce=nonce,candidate_root=str(candidate),candidate_identity=node(candidate),owner_evidence_root=str(evidence),input_root=str(D),input_identity=node(D),output_parent_identity=node(parent))
 need(request['request_path']==str(D/'REQUEST.ROOT.FINAL.json') and not evidence.exists() and list(candidate.iterdir())==[],'exact nonce-bound request/freshness')
 rq=publish(D/'REQUEST.ROOT.FINAL.json',request);release.update(nonce=nonce,request=dict(path=rq['path'],sha256=rq['sha256']),status='PENDING_FRESH_ADMISSION_PUBLICATION_AND_INDEPENDENT_EXECUTION_REVIEW')
 rl=publish(D/'RELEASE.ROOT.PENDING-NO-CLOCK-NO-APPROVAL.json',release)
 finalmap=publish(D/'ACTUAL-FINAL-ELEVEN-SOURCE-MAP.json',dict(source_sha256=release['source_sha256'],owner=OWNER,driver=DRIVER,preparation=PREPARATION,configuration=CONFIGURATION,request=rq,nonce=nonce,source_materialization=MATERIAL,execution_release=False))
 result=dict(libdwarf_mountpoint_identity=mountpoint_identity,mountpoint_parent_identity=MOUNTPOINT_PARENT,original_copy_result_preserved=MATERIAL,status='PASS_EXCLUSIVE_TARGET_METADATA_NAMESPACE_AND_REQUEST_ONLY',request=rq,release_pending=rl,final_eleven_source_map=finalmap,nonce=nonce,owner=OWNER,driver=DRIVER,source_sha256=release['source_sha256'],candidate_identity=node(candidate),output_parent_identity=node(parent),input_identity=node(D),actual_source_materialization=MATERIAL,read_path_proof=PROOF,execution_release=False)
 rr=publish(D/'ACTUAL-METADATA-PUBLICATION-RECEIPT.json',result);print(json.dumps(dict(receipt=rr,**result),sort_keys=True))
if __name__=='__main__':main()
