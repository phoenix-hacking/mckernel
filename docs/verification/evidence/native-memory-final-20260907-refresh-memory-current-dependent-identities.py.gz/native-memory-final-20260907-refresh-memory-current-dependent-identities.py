"""Edit reviewed current data bindings; never execute repository code on the host."""
import ast,hashlib,json,pprint,re,subprocess
from pathlib import Path
root=Path('/home/holden/mckernel')
def sha(data):return hashlib.sha256(data).hexdigest()
def identity(path):
 data=(root/path).read_bytes();return dict(path=path,sha256=sha(data),size=len(data))
def nodes(s):return {n.targets[0].id:n.value for n in ast.parse(s).body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
def edit_values(path,replacements):
 p=root/path;s=p.read_text();lines=s.splitlines(keepends=True); found=nodes(s);edits=[]
 for name,value in replacements.items():
  n=found[name];edits.append((sum(map(len,lines[:n.lineno-1]))+n.col_offset,sum(map(len,lines[:n.end_lineno-1]))+n.end_col_offset,pprint.pformat(value,width=100,sort_dicts=False)))
 for a,b,v in sorted(edits,reverse=True):s=s[:a]+v+s[b:]
 p.write_text(s)
def normalize(path,marker):
 p=root/path;raw=p.read_bytes();pattern=marker.encode()+br':[0-9a-f]{64}'
 normalized,count=re.subn(pattern,marker.encode()+b':'+b'0'*64,raw);assert count==1
 raw,count=re.subn(pattern,marker.encode()+b':'+sha(normalized).encode(),raw);assert count==1;p.write_bytes(raw)
def update_json(path,allowed):
 p=root/path;v=json.loads(p.read_text());changed=[]
 def walk(d):
  if isinstance(d,dict):
   if d.get('path') in allowed and 'sha256' in d:
    current=identity(d['path']); d['sha256']=current['sha256']
    if 'size' in d:d['size']=current['size']
    changed.append(d['path'])
   for x in d.values():walk(x)
  elif isinstance(d,list):
   for x in d:walk(x)
 walk(v);p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n');return changed
runtime='scripts/native_rust_runtime_evidence.py'
workflow='.github/workflows/native-rust-host-modules-exact-build.yml'
s=(root/runtime).read_text();ns=nodes(s)
v=ast.literal_eval(ns['EXPECTED_REPOSITORY_WORKFLOW_IDENTITIES']);data=(root/workflow).read_bytes()
v['build_workflow']=dict(sha256=sha(data),size=len(data),git_blob_sha1=hashlib.sha1(('blob '+str(len(data))+'\0').encode()+data).hexdigest())
edit_values(runtime,{'EXPECTED_REPOSITORY_WORKFLOW_IDENTITIES':v});normalize(runtime,'ISOLATED_SELF_DIGEST')
capture='host-kernel/contracts/fp0006-runtime-capture-integration-v1.json'
update_json(capture,{runtime,workflow});cap=identity(capture)
edit_values('scripts/fp0006_runtime_capture_integration.py',dict(EXPECTED_CONTRACT_SHA256=cap['sha256'],EXPECTED_CONTRACT_SIZE=cap['size'],EXPECTED_NATIVE_WORKFLOW_SHA256=identity(workflow)['sha256']))
executable='host-kernel/contracts/fp0006-executable-acceptance-closure-v1.json'
old=identity(executable)['sha256'];update_json(executable,{capture});new=identity(executable)
edit_values('scripts/fp0006_executable_acceptance_closure.py',dict(EXPECTED_CONTRACT_SHA256=new['sha256'],EXPECTED_CONTRACT_SIZE=new['size']));normalize('scripts/fp0006_executable_acceptance_closure.py','SELF_DIGEST')
p=root/'scripts/tests/test_fp0006_executable_acceptance_closure.py';s=p.read_text();assert s.count(old)==1;p.write_text(s.replace(old,new['sha256']))
rs006='host-kernel/contracts/rs006-miscdevice-module-owner-followup-v1.json'
p=root/rs006;value=json.loads(p.read_text())
for row in value['integrated_consumer_inventory']:
 if row['path']==runtime:row.update(identity(runtime))
p.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
edit_values('scripts/rs006_miscdevice_module_owner_followup.py',{'EXPECTED_CONTRACT_SHA256':identity(rs006)['sha256']})
print('Updated executed workflow identity and current dependent contracts')
