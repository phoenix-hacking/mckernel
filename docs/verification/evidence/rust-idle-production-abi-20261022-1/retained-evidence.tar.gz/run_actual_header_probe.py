from pathlib import Path
import subprocess,json,hashlib,shlex,resource,os,re
ROOT=Path('/home/holden/mckernel')
OUT=Path(__file__).resolve().parent
REFERENCE=Path('/home/holden/mckernel-work/host-preparation/phase4-guest-compiler-preparation-20261020-1/new205-real-C-template.json')
reference=json.loads(REFERENCE.read_text())
BUILD=Path(reference['build'])
row=next(row for row in reference['selected'] if row['source']=='kernel/process.c')
profile={'affinity':[0],'address_space_bytes':1073741824,'cpu_seconds':20,'wall_seconds':30}
commands=[]
def write(name,data):
 with (OUT/name).open('x') as f:f.write(data)
def limits():
 os.sched_setaffinity(0,{0})
 resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
 resource.setrlimit(resource.RLIMIT_CPU,(20,20))
def run(label,argv):
 commands.append({'label':label,'argv':argv,'profile':profile})
 (OUT/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 r=subprocess.run(['timeout','30s']+argv,capture_output=True,text=True,preexec_fn=limits)
 write(label+'.stdout',r.stdout);write(label+'.stderr',r.stderr);write(label+'.status',str(r.returncode)+'\n')
 print(label, r.returncode, r.stdout, r.stderr)
 if r.returncode:raise SystemExit(r.returncode)
 return r.stdout
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
process=(ROOT/'kernel/process.c').read_text()
start=process.index('#ifdef MCKERNEL_RUST_PROCESS_HELPERS',process.index('s = ihk_mc_spinlock_lock(&v->runq_lock);',process.index('void idle(')))
end=process.index('\n#else',start)
selected=process[start:end]+'\n#endif\n'
write('actual-selected-body.c.fragment',selected)
write('input-manifest.json',json.dumps({'head':head,'reference':{'path':str(REFERENCE),'sha256':hashlib.sha256(REFERENCE.read_bytes()).hexdigest()},'retained_production_command':row['row'],'generated_config':{'path':str(BUILD/'config.h'),'sha256':hashlib.sha256((BUILD/'config.h').read_bytes()).hexdigest()},'sources':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['kernel/process.c','kernel/include/process.h','kernel/include/sched_helpers.h','kernel/include/cls.h','lib/include/list.h','kernel/rust/abi.rs']}},indent=2)+'\n')
assert hashlib.sha256((BUILD/'config.h').read_bytes()).hexdigest()==reference['generated_config']['sha256']
source='#include <process.h>\n#include <sched_helpers.h>\n#include <cls.h>\n_Static_assert(sizeof(((struct thread *)0)->status)==4, "actual thread status width");\n_Static_assert(__builtin_types_compatible_p(__typeof__(((struct thread *)0)->status),int), "actual thread status type");\n_Static_assert(offsetof(struct thread,status)==4184, "actual thread status offset");\n_Static_assert(offsetof(struct thread,sched_list)==4328, "actual thread sched_list offset");\n_Static_assert(offsetof(struct thread,spin_sleep)==4356, "actual thread spin_sleep offset");\n_Static_assert(sizeof(struct thread)==5568, "actual thread size");\n_Static_assert(offsetof(struct list_head,next)==0, "actual list next offset");\n_Static_assert(sizeof(struct list_head)==16, "actual list width");\n_Static_assert(sizeof(unsigned long)==8 && sizeof(void *)==8, "actual LP64 C pointer ABI");\n_Static_assert(PS_RUNNING==1, "actual exact running status");\n_Static_assert(CPU_STATUS_RUNNING==2, "actual CPU running status");\nconst unsigned long idle_scan_production_abi[] = {\n sizeof(struct thread), offsetof(struct thread,status), sizeof(((struct thread *)0)->status),\n offsetof(struct thread,sched_list), offsetof(struct thread,spin_sleep),\n offsetof(struct list_head,next),sizeof(struct list_head),PS_RUNNING,CPU_STATUS_RUNNING\n};\nvoid actual_selected_idle_scan(struct cpu_local_var *v) {\n'+selected+'}\n'
write('actual_production_header_probe.c',source)
compiler=Path('/usr/bin/gcc')
version=run('compiler-version',[str(compiler),'--version'])
inc=run('compiler-system-include',[str(compiler),'-print-file-name=include']).strip()
argv=[str(compiler)]
original=row['argv'][1:]
i=0
while i<len(original):
 arg=original[i]
 if arg=='-o':i+=2;continue
 if arg=='-c':i+=2;continue
 if arg=='-isystem':argv += ['-isystem',inc];i+=2;continue
 if arg.startswith('-I/work/output/build'):arg='-I'+str(BUILD)+arg[len('-I/work/output/build'):]
 elif arg.startswith('-I/src'):arg='-I'+str(ROOT)+arg[len('-I/src'):]
 argv.append(arg);i+=1
argv += ['-std=gnu11','-Werror','-MD','-MF',str(OUT/'actual_production_header_probe.d'),'-c',str(OUT/'actual_production_header_probe.c'),'-o',str(OUT/'actual_production_header_probe.o')]
write('host-recipe-adaptation.json',json.dumps({'original':row['argv'],'adapted':argv,'changes':['map /src includes to live source root','map /work/output/build includes to retained accepted new205 generated root','use host /usr/bin/gcc 9.4.0 and its matching GCC system headers instead of container-only cc14.3.1','compile extracted exact selected idle bridge against real production process.h/cls.h/sched_helpers.h; no full process.c compile','add gnu11/Werror/dependency capture; write all outputs in fresh owned directory'],'compiler':{'path':str(compiler),'resolved_path':str(compiler.resolve()),'sha256':hashlib.sha256(compiler.resolve().read_bytes()).hexdigest(),'version':version}},indent=2)+'\n')
run('actual-header-compile-1',argv)
run('actual-header-symbols',['/usr/bin/nm',str(OUT/'actual_production_header_probe.o')])
dis=run('actual-header-disassembly',['/usr/bin/objdump','-dr',str(OUT/'actual_production_header_probe.o')])
assert not re.search(r'\b(?:[xyz]mm[0-9]+|st\([0-7]\)|xsave\w*|xrstor\w*)\b',dis)
run('actual-header-rodata',['/usr/bin/objdump','-s','-j','.rodata',str(OUT/'actual_production_header_probe.o')])
deps=(OUT/'actual_production_header_probe.d').read_text().replace('\\\n',' ').split(':',1)[1].split()
headers={str(Path(p)):hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in deps}
write('consumed-input-sha256.json',json.dumps(headers,indent=2)+'\n')
write('result.json',json.dumps({'status':'PASS','actual_production_headers_compiled':True,'full_process_translation_unit_compiled':False,'compiler_equivalent_to_pinned_image':False,'linked_or_native_acceptance':False,'actual_selected_bridge':True,'static_assertions':{'status_type':'C int','status_width':4,'status_offset':4184,'sched_list_offset':4328,'spin_sleep_offset':4356,'thread_size':5568,'list_next_offset':0,'list_size':16,'PS_RUNNING':1,'CPU_STATUS_RUNNING':2},'profile':profile,'limitations':['retained accepted new205 generated config; current live production headers','host GCC9.4 instead of production image GCC14.3.1','no current whole-TU/image/link/native proof'],'failure_history':'candidate1 passed; no correction needed'},indent=2)+'\n')
