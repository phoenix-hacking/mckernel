#include <process.h>
#include <sched_helpers.h>
#include <cls.h>
_Static_assert(sizeof(((struct thread *)0)->status)==4, "actual thread status width");
_Static_assert(__builtin_types_compatible_p(__typeof__(((struct thread *)0)->status),int), "actual thread status type");
_Static_assert(offsetof(struct thread,status)==4184, "actual thread status offset");
_Static_assert(offsetof(struct thread,sched_list)==4328, "actual thread sched_list offset");
_Static_assert(offsetof(struct thread,spin_sleep)==4356, "actual thread spin_sleep offset");
_Static_assert(sizeof(struct thread)==5568, "actual thread size");
_Static_assert(offsetof(struct list_head,next)==0, "actual list next offset");
_Static_assert(sizeof(struct list_head)==16, "actual list width");
_Static_assert(sizeof(unsigned long)==8 && sizeof(void *)==8, "actual LP64 C pointer ABI");
_Static_assert(PS_RUNNING==1, "actual exact running status");
_Static_assert(CPU_STATUS_RUNNING==2, "actual CPU running status");
const unsigned long idle_scan_production_abi[] = {
 sizeof(struct thread), offsetof(struct thread,status), sizeof(((struct thread *)0)->status),
 offsetof(struct thread,sched_list), offsetof(struct thread,spin_sleep),
 offsetof(struct list_head,next),sizeof(struct list_head),PS_RUNNING,CPU_STATUS_RUNNING
};
void actual_selected_idle_scan(struct cpu_local_var *v) {
#ifdef MCKERNEL_RUST_PROCESS_HELPERS
			_Static_assert(__builtin_types_compatible_p(
				__typeof__(((struct thread *)0)->status), int),
				"idle runqueue status must be a C int");
			_Static_assert(sizeof(((struct thread *)0)->status) == 4,
				"idle runqueue status must match Rust i32");
			_Static_assert(offsetof(struct list_head, next) == 0,
				"idle runqueue next must be the first list field");
			if (sched_idle_runqueue_has_running_result(
				(unsigned long)&v->runq,
				offsetof(struct thread, sched_list),
				offsetof(struct thread, status), PS_RUNNING))
				v->status = CPU_STATUS_RUNNING;
#endif
}
