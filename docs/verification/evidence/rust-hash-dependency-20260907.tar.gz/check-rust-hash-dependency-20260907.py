"""Prove the missing dependency and corrected incremental rebuild in isolation."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

repo = Path('/workspace')
source = Path('/work/compat-source-pageattrs-20260907')
build = Path('/work/compat-build-pageattrs-20260907')
out = Path('/work/rust-hash-dependency-20260907')
if os.getuid() != 1000 or os.sched_getaffinity(0) != {2, 3, 4, 5}:
    raise SystemExit('Use the fixed unprivileged four-CPU runner')
out.mkdir()
makefile = build / 'kernel/CMakeFiles/mckernel_rust_obj.dir/build.make'
rust_hash = source / 'kernel/rust/hash.rs'
rust_object = build / 'kernel/rust/mckernel_rust.o'
image = build / 'kernel/mckernel.img'

def identity(path):
    return dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                size=path.stat().st_size)

def run(args, name):
    with (out / name).open('wb') as log:
        result = subprocess.run(args, cwd=str(build), stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        raise SystemExit('Stopped at failed command: ' + name)
    return (out / name).read_text()

before = dict(rust_source=identity(rust_hash), object=identity(rust_object), image=identity(image))
shutil.copyfile(makefile, out / 'before-build.make')
shutil.copyfile(source / 'kernel/CMakeLists.txt', out / 'before-CMakeLists.txt')
probe = ['gmake', '-f', str(makefile), '-n', '-W', str(rust_hash), 'kernel/rust/mckernel_rust.o']
negative = run(probe, 'before-dry-run.log')
if '--crate-name mckernel_rust' in negative:
    raise SystemExit('Baseline already rebuilds for hash.rs; investigate before editing the build copy')
shutil.copyfile(repo / 'kernel/CMakeLists.txt', source / 'kernel/CMakeLists.txt')
run(['cmake', '-S', str(source), '-B', str(build)], 'configure.log')
shutil.copyfile(makefile, out / 'after-build.make')
positive = run(probe, 'after-dry-run.log')
if '--crate-name mckernel_rust' not in positive:
    raise SystemExit('Corrected dependency did not schedule the Rust compiler')
old_mtime = rust_object.stat().st_mtime_ns
rust_hash.touch()
run(['cmake', '--build', str(build), '--target', 'mckernel.img', '--parallel', '4'], 'rebuild.log')
after = dict(rust_source=identity(rust_hash), object=identity(rust_object), image=identity(image))
if rust_object.stat().st_mtime_ns <= old_mtime:
    raise SystemExit('Rust object was not rebuilt after hash.rs changed timestamp')
if before != after:
    raise SystemExit('Dependency-only repair changed source or binary bytes; inspect retained outputs')
record = dict(schema='mckernel-rust-hash-dependency-check-v1',
              finished_utc=datetime.now(timezone.utc).isoformat(),
              source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD']).decode().strip(),
              change=dict(path='kernel/CMakeLists.txt', **identity(repo / 'kernel/CMakeLists.txt')),
              before=before, after=after, negative_missed_rebuild=True,
              corrected_scheduled_rebuild=True, rebuilt_object=True,
              image_and_object_bytes_unchanged=True, cpus=4, guest_boot_claimed=False,
              artifacts=[dict(path=p.name, **identity(p)) for p in sorted(out.iterdir())])
(out / 'result.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print('HASH_DEPENDENCY_NEGATIVE_AND_REBUILD_PASS')
