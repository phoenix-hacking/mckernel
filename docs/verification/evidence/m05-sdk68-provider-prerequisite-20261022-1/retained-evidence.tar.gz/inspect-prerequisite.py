"""Targeted pinned-tool prerequisite check; no compilation or container access."""
import json
from pathlib import Path
import re
import shlex
import shutil
import subprocess
OUT=Path(__file__).resolve().parent
BASE=Path('/home/holden/mckernel-work/scratch/mckernel-exact-candidate-scratch-22-authority3-output')
SOURCE=Path('/home/holden/mckernel-work/host-preparation/m05-sdk68-current-source-bundle-20261022-1/source-modules')
RETAINED=Path('/home/holden/mckernel-work/scratch/nsd-c-df75d8453eab42ff918731acbd2573c4/modules/.mcctrl_vm_write_compat.o.cmd')
CONFIG=Path('/home/holden/mckernel-work/scratch/nsd-i-df75d8453eab42ff918731acbd2573c4/baseline.config')
config=CONFIG.read_text()
expected=re.search(r'^CONFIG_CC_VERSION_TEXT=(.*)$',config,re.M).group(1)
clang=shutil.which('clang')
version=subprocess.run([clang,'--version'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,check=False,timeout=5)
(OUT/'host-clang-version.stdout').write_text(version.stdout)
(OUT/'host-clang-version.stderr').write_text(version.stderr)
original=RETAINED.read_text().splitlines()[0].split(':=',1)[1].strip()
argv=shlex.split(original)
assert argv[0]=='clang' and argv[-1]=='/candidate/modules/mcctrl_vm_write_compat.c'
# Exact saved compiler flags; translate only namespace input/output roots.
translated=[]
for token in argv:
    token=token.replace('/out/',str(BASE)+'/')
    token=token.replace('/candidate/modules/.mcctrl_vm_write_compat.o.d',str(OUT/'mcctrl_vm_write_compat.o.d'))
    token=token.replace('/candidate/modules/mcctrl_vm_write_compat.o',str(OUT/'mcctrl_vm_write_compat.o'))
    token=token.replace('/candidate/modules/mcctrl_vm_write_compat.c',str(SOURCE/'mcctrl_vm_write_compat.c'))
    translated.append(token)
translated[0]='/usr/bin/clang'
required=[BASE/'build/include/generated/autoconf.h',BASE/'build/include/generated/utsrelease.h',
          BASE/'source/linux-6.12.0-211.44.1.el10_2/include/linux/mm.h',
          BASE/'source/linux-6.12.0-211.44.1.el10_2/include/linux/mmap_lock.h',
          SOURCE/'mcctrl_vm_write_compat.c',SOURCE/'mcctrl_vm_write_compat.h']
value=dict(scope='Functional McKernel OS/apps and Rust/assembly migration only; no security testing.',
 status='BLOCKED_PINNED_CLANG21_NOT_DIRECTLY_AVAILABLE_HOST_PROFILE',
 exact_missing_prerequisite='Directly runnable pinned Rocky clang21.1.8(RESF21.1.8-1.el10) toolchain under reviewed ordinary host profile; existing pinned image alone is not a directly available host executable.',
 selected_sdk_compiler=expected,host_clang=dict(path=clang,returncode=version.returncode,version_stdout=version.stdout),
 checked_tool_locations=['/usr/bin/clang* (versions6.0,11,15)','/usr/lib/llvm-{6.0,10,11,15}','/home/holden/mckernel-work/toolchains (cargo,rustup only)'],
 selected_config_path=str(CONFIG),retained_actual_compiler_command_path=str(RETAINED),
 required_targeted_inputs=[dict(path=str(p),present=p.is_file()) for p in required],
 next_compile=dict(argv=translated,cwd=str(BASE/'build'),conditional='Only after exact pinned compiler is available and released under ordinary profile; current /usr/bin/clang15 must not run this command as pinned evidence.'),
 next_symbol_observation=dict(argv=['/usr/bin/nm','--format=posix',str(OUT/'mcctrl_vm_write_compat.o')],
 expected_global_definitions=['mckernel_inherited_mmap_write_lock','mckernel_inherited_mmap_write_unlock','mckernel_inherited_vma_start_write'],expected_each_definition_count=1,expected_each_undefined_count=0),
 compilation_calls=0,compiler_version_queries=1,symbol_observations=0,
 provider_only_limit='Even a wrapper object PASS would not establish current Rust FFI caller linkage; current Rust object/composite/module checks remain later prerequisites.',
 runtime_acceptance=False,module_acceptance=False,native_acceptance=False,rust_retirement=False,
 no_container_or_root_or_sdk_activation=True)
(OUT/'prerequisite.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(dict(status=value['status'],selected_sdk_compiler=expected,host_version=version.stdout.splitlines()[0],
 targeted_inputs_present=all(r['present'] for r in value['required_targeted_inputs']),compilation_calls=0),indent=2))
