#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <limits.h>
#include "list.h"
#define PS_RUNNING 1
#define CPU_STATUS_RUNNING 2
struct thread { unsigned char prefix[4184]; int status; unsigned char gap[140]; struct list_head sched_list; unsigned char gap2[12]; int spin_sleep; unsigned char tail[1208]; } __attribute__((aligned(64)));
struct cpu { int status; struct list_head runq; };
_Static_assert(sizeof(int) == 4, "status width");
_Static_assert(sizeof(unsigned long) == sizeof(void *) && sizeof(void *) == 8, "supported LP64 pointer ABI");
_Static_assert(sizeof(struct thread) == 5568, "fixture thread size");
_Static_assert(offsetof(struct thread, status) == 4184, "C status offset");
_Static_assert(offsetof(struct thread, sched_list) == 4328, "C list offset");
_Static_assert(offsetof(struct thread, spin_sleep) == 4356, "fixture spin offset");
int sched_idle_runqueue_has_running_result(unsigned long runq_head,
	unsigned long thread_sched_list_offset,
	unsigned long thread_status_offset, int running_status);
int original_scan(struct cpu *v) { struct thread *t;
			for (t = ((typeof(*t) *)((char *)((&v->runq)->next) - offsetof(typeof(*t), sched_list))); &t->sched_list != (&v->runq); t = ((typeof(*t) *)((char *)(t->sched_list.next) - offsetof(typeof(*t), sched_list)))) {
				if (t->status == PS_RUNNING) {
					v->status = CPU_STATUS_RUNNING;
					break;
				}
			}
return v->status; }
int selected_scan(struct cpu *v) {
#ifndef MCKERNEL_RUST_PROCESS_HELPERS
struct thread *t;
#endif
#ifdef MCKERNEL_RUST_PROCESS_HELPERS
			_Static_assert(__builtin_types_compatible_p(
				__typeof__(((struct thread *)0)->status), int),
				"idle runqueue status must be a C int");
			_Static_assert(sizeof(((struct thread *)0)->status) == 4,
				"idle runqueue status must match Rust i32");
			_Static_assert(offsetof(struct list_head, next) == 0,
				"idle runqueue next must be the first list field");
			if (sched_idle_runqueue_has_running_result(
				(unsigned long)&v->runq,
				offsetof(struct thread, sched_list),
				offsetof(struct thread, status), PS_RUNNING))
				v->status = CPU_STATUS_RUNNING;
#else
			for (t = ((typeof(*t) *)((char *)((&v->runq)->next) - offsetof(typeof(*t), sched_list))); &t->sched_list != (&v->runq); t = ((typeof(*t) *)((char *)(t->sched_list.next) - offsetof(typeof(*t), sched_list)))) {
				if (t->status == PS_RUNNING) {
					v->status = CPU_STATUS_RUNNING;
					break;
				}
			}
#endif
return v->status; }

struct other_thread { int status; int spin_sleep; unsigned long gap[5]; struct list_head sched_list; };
int main(void) {
  static struct thread threads[3], saved[3];
  int cases[][3] = {{0,0,0},{2,32,16},{1,2,32},{2,1,32},{2,32,1},{3,5,17},{-1,INT_MIN,INT_MAX},{0x10001,0x101,0x201},{2,32,16},{1,1,1}};
  int checked=0;
  for (int n=0;n<=3;n++) for(unsigned c=0;c<sizeof(cases)/sizeof(*cases);c++) for(int initial=1;initial<=3;initial+=2) {
    memset(threads, 0xa5, sizeof(threads));
    struct cpu v={.status=initial};
    struct list_head *tail=&v.runq;
    v.runq.next=&v.runq; v.runq.prev=&v.runq;
    int expected=initial;
    for(int i=0;i<n;i++) {
      threads[i].status=cases[c][i]; threads[i].spin_sleep=c==8 ? 1 : 0;
      struct list_head *node=&threads[i].sched_list;
      node->prev=tail; node->next=&v.runq; tail->next=node; v.runq.prev=node; tail=node;
      if(threads[i].status==PS_RUNNING) expected=CPU_STATUS_RUNNING;
    }
    memcpy(saved,threads,sizeof(threads));
    struct list_head saved_head=v.runq;
    assert(original_scan(&v)==expected);
    assert(memcmp(saved,threads,sizeof(threads))==0);
    assert(memcmp(&saved_head,&v.runq,sizeof(saved_head))==0);
    v.status=initial;
    assert(selected_scan(&v)==expected);
    assert(memcmp(saved,threads,sizeof(threads))==0);
    assert(memcmp(&saved_head,&v.runq,sizeof(saved_head))==0);
    checked++;
  }
#ifdef MCKERNEL_RUST_PROCESS_HELPERS
  struct list_head head; struct other_thread other[2];
  memset(other,0x7b,sizeof(other));
  other[0].status=3; other[1].status=1;
  head.next=&other[0].sched_list; head.prev=&other[1].sched_list;
  other[0].sched_list.prev=&head; other[0].sched_list.next=&other[1].sched_list;
  other[1].sched_list.prev=&other[0].sched_list; other[1].sched_list.next=&head;
  unsigned char snapshot[sizeof(other)]; memcpy(snapshot,other,sizeof(other));
  assert(sched_idle_runqueue_has_running_result((unsigned long)&head,offsetof(struct other_thread,sched_list),offsetof(struct other_thread,status),1)==1);
  assert(memcmp(snapshot,other,sizeof(other))==0);
  other[1].status=3;
  memcpy(snapshot,other,sizeof(other));
  assert(sched_idle_runqueue_has_running_result((unsigned long)&head,offsetof(struct other_thread,sched_list),offsetof(struct other_thread,status),1)==0);
  assert(memcmp(snapshot,other,sizeof(other))==0);
#endif
  printf("PASS %d exact C/Rust idle cases; C offsets, int width, byte preservation\n",checked);
  return 0;
}
