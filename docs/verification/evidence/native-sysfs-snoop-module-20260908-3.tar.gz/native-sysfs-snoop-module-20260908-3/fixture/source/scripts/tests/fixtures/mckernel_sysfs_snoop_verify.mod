/work/native-sysfs-snoop-module-20260908-3/fixture/source/scripts/tests/fixtures/mckernel_sysfs_snoop_verify.o
