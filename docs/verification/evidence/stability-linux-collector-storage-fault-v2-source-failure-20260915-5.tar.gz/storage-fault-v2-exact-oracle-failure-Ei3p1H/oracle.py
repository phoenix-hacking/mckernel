#!/usr/bin/env python3
"""Independent offline oracle for storage-fault-v2 retained evidence."""
import hashlib
import itertools
import json
import os
import stat
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE_SHA = "09a63a343fa8cc9f511a26693371f5ba4f55ac5ca56fcb47abdc44759830cf1f"
PREFIX = bytes.fromhex("41435251303030")
PREFIX_SHA = "793665677edfa8c879c38d37c8c5300c54ff78e980eae26a96913d7aab9d8d91"
EXPECTED = {
    0: (0, "post-fork", "complete", "COMPLETED", "none", 0, 21),
    1: (256, "pre-fork", "complete", "PREPARATION_ERROR", "artifact-create", 28, 10),
    2: (256, "pre-fork", "complete", "COLLECTOR_ERROR", "artifact-write", 28, 17),
    3: (256, "post-fork", "complete", "COLLECTOR_ERROR", "artifact-fsync", 5, 21),
    4: (32000, "post-fork", "absent", None, None, 28, 16),
    5: (32000, "post-fork", "complete-undurable", "COMPLETED", "none", 0, 21),
    6: (32000, "pre-fork", "complete-undurable", "COLLECTOR_ERROR", "artifact-write", 28, 17),
}
COUNTS = [21, 10, 17, 21, 16, 21, 17]
COMMON = {"schema_version", "nonce", "selector", "sequence", "kind", "phase",
          "monotonic_ns", "site", "object", "occurrence", "collector_pid",
          "collector_startticks", "source_sha256", "generated_sha256",
          "header_sha256", "elf_sha256"}
CREATE = {"dirfd", "dir_stat", "fd", "target_stat", "acquisition_id",
          "return", "errno_authoritative", "errno"}
WRITE_BEFORE = {"fd", "target_stat", "acquisition_id", "requested_bytes",
                "return", "errno_authoritative", "errno"}
WRITE_AFTER = WRITE_BEFORE | {"actual_bytes"}
IO = {"fd", "target_stat", "acquisition_id", "return",
      "errno_authoritative", "errno"}
BIND = {"acquisition_id", "old_fd", "old_stat", "new_fd", "new_stat"}
OBS = {"REAP": {"pid", "startticks", "raw_wait_status"},
       "EOF": {"closed_fd"},
       "CLEANUP_READY": {"waitid_return", "waitid_errno", "leader_reaped",
           "stdout_eof", "stderr_eof", "setup_eof"},
       "CLEANUP_FINAL": {"cleanup_start_ns", "cleanup_deadline_ns",
           "cleanup_finished_ns", "cleanup_complete", "group_pinned",
           "owned_count", "owned_records_omitted", "first_failure",
           "first_failure_errno"}}

def pair(site, object_name, occurrence=1):
    return [("BEFORE", site, object_name, occurrence),
            ("AFTER", site, object_name, occurrence)]

def schedule_variants(selector):
    e, w1, w2 = pair("events-create", "events.jsonl"), \
        pair("request-write", "request.bin"), pair("request-write", "request.bin", 2)
    eb = [("BIND", "events-create", "events.jsonl", 1)]
    a, r = pair("request-sync", "request.bin"), pair("report-create", "report.json")
    rb = [("BIND", "report-create", "report.json", 1)]
    f, s = pair("report-flush", "report.json"), pair("report-sync", "report.json")
    base = {0:e+eb+w1+["O"]+a+r+rb+f+s, 1:e+r+rb+f+s,
            2:e+eb+w1+w2+a+r+rb+f+s, 3:e+eb+w1+["O"]+a+r+rb+f+s,
            4:e+eb+w1+["O"]+a+r, 5:e+eb+w1+["O"]+a+r+rb+f+s,
            6:e+eb+w1+w2+a+r+rb+f+s}[selector]
    ready = [("READY", "startup", "collector", 0)]
    if "O" not in base:
        return [ready + base]
    index = base.index("O")
    observations = [("REAP", "reap", "leader", 1),
        ("EOF", "pump", "stdout", 1), ("EOF", "pump", "stderr", 2),
        ("EOF", "pump", "setup", 3)]
    final = [("CLEANUP_READY", "cleanup", "owned-tree", 1),
             ("CLEANUP_FINAL", "cleanup", "owned-tree", 1)]
    return [ready + base[:index] + list(order) + final + base[index+1:]
            for order in itertools.permutations(observations)]

def phase_for(selector, site, kind):
    if kind == "READY" or site in ("events-create", "request-write"):
        return "pre-fork"
    if kind in OBS:
        return "post-fork"
    return "pre-fork" if selector in (1, 2, 6) else "post-fork"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def strict(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate key")
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(
                          ValueError("nonfinite")))

def read(path, limit=1 << 20):
    path = Path(path)
    if not path.is_absolute() or path.resolve() != path:
        raise ValueError("canonical evidence path")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size > limit:
            raise ValueError("bounded regular evidence")
        chunks, remaining = [], before.st_size
        while remaining:
            chunk = os.read(fd, min(remaining, 65536))
            if not chunk:
                raise OSError("short evidence read")
            chunks.append(chunk)
            remaining -= len(chunk)
        after = os.fstat(fd)
        if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != \
           (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
            raise OSError("evidence changed during read")
        return b"".join(chunks)
    finally:
        os.close(fd)

def journal(path):
    raw = read(path, 1 << 20)
    if not raw.endswith(b"\n"):
        raise ValueError("journal terminal newline")
    rows = [strict(line) for line in raw.splitlines()]
    if not rows or any(set(row) != {"packet", "receipt_monotonic_ns"}
                       for row in rows):
        raise ValueError("journal envelope")
    if any(type(row["receipt_monotonic_ns"]) is not int or
           row["receipt_monotonic_ns"] <= 0 for row in rows):
        raise ValueError("journal receipt")
    return rows

def validate_stat(value):
    if type(value) is not dict or set(value) != {"dev", "ino", "mode", "size"} or \
       any(type(value[key]) is not int for key in value):
        raise ValueError("witness stat")

def validate_packet_schema(packet):
    kind, site = packet["kind"], packet["site"]
    if kind == "READY": extras = set()
    elif kind in ("BEFORE", "AFTER") and site in ("events-create", "report-create"):
        extras = CREATE
    elif kind == "BEFORE" and site == "request-write": extras = WRITE_BEFORE
    elif kind == "AFTER" and site == "request-write": extras = WRITE_AFTER
    elif kind in ("BEFORE", "AFTER") and site in (
            "request-sync", "report-flush", "report-sync"): extras = IO
    elif kind == "BIND": extras = BIND
    elif kind in OBS: extras = OBS[kind]
    else: raise ValueError("witness kind")
    if set(packet) != COMMON | extras:
        raise ValueError("witness exact fields")
    for name in ("target_stat", "dir_stat", "old_stat", "new_stat"):
        if name in packet and packet[name] is not None: validate_stat(packet[name])
    if kind == "BEFORE" and (packet["return"] is not None or
            packet["errno_authoritative"] is not False or packet["errno"] is not None):
        raise ValueError("before result")
    if kind == "AFTER":
        result = packet["return"]
        if type(result) is not int or packet["errno_authoritative"] is not (result < 0) or \
           (result < 0 and (type(packet["errno"]) is not int or packet["errno"] <= 0)) or \
           (result >= 0 and packet["errno"] is not None):
            raise ValueError("after result")

def validate_packet_order(packets, selector, nonce, hashes, expected_count):
    if len(packets) != expected_count or expected_count != COUNTS[selector]:
        raise ValueError("witness packet count")
    signatures = []
    for sequence, packet in enumerate(packets):
        validate_packet_schema(packet)
        if packet["schema_version"] != 2 or packet["nonce"] != nonce or \
           packet["selector"] != selector or packet["sequence"] != sequence:
            raise ValueError("witness identity")
        if type(packet["monotonic_ns"]) is not int or packet["monotonic_ns"] <= 0 or \
           type(packet["collector_pid"]) is not int or packet["collector_pid"] <= 0 or \
           type(packet["collector_startticks"]) is not int or packet["collector_startticks"] <= 0:
            raise ValueError("witness monotonic")
        if packet["source_sha256"] != SOURCE_SHA:
            raise ValueError("source hash")
        for key in ("generated_sha256", "header_sha256", "elf_sha256"):
            if packet[key] != hashes[key]:
                raise ValueError("generated hash")
        if packet["phase"] != phase_for(selector, packet["site"], packet["kind"]):
            raise ValueError("witness phase")
        signatures.append((packet["kind"], packet["site"], packet["object"],
                           packet["occurrence"]))
    if signatures not in schedule_variants(selector):
        raise ValueError("witness schedule")

    request_identity, request_size = None, 0
    creates, positive_ids = {}, set()
    for packet in packets[1:]:
        kind, site = packet["kind"], packet["site"]
        if kind == "BEFORE" and site in ("events-create", "report-create"):
            if packet["fd"] is not None or packet["target_stat"] is not None or \
               packet["acquisition_id"] is not None or type(packet["dirfd"]) is not int:
                raise ValueError("create before")
            validate_stat(packet["dir_stat"])
        elif kind == "AFTER" and site in ("events-create", "report-create"):
            failed = (site == "events-create" and selector == 1) or \
                     (site == "report-create" and selector == 4)
            if failed:
                if (packet["return"], packet["errno"], packet["fd"],
                    packet["target_stat"], packet["acquisition_id"]) != \
                   (-1, 28, None, None, None): raise ValueError("create failure")
            else:
                if packet["return"] < 0 or packet["fd"] != packet["return"] or \
                   type(packet["acquisition_id"]) is not int or packet["acquisition_id"] <= 0:
                    raise ValueError("create success")
                validate_stat(packet["target_stat"])
                if packet["target_stat"]["size"] != 0 or packet["acquisition_id"] in positive_ids:
                    raise ValueError("create acquisition")
                positive_ids.add(packet["acquisition_id"])
                creates[site] = packet
        elif kind == "BIND":
            create = creates.get(site)
            if not create or packet["acquisition_id"] != create["acquisition_id"] or \
               packet["old_fd"] != create["fd"]:
                raise ValueError("bind acquisition")
            for key in ("dev", "ino", "mode"):
                if packet["old_stat"][key] != packet["new_stat"][key] or \
                   packet["old_stat"][key] != create["target_stat"][key]:
                    raise ValueError("bind identity")
        elif site == "request-write":
            stat_value = packet["target_stat"]
            identity = (packet["fd"], stat_value["dev"], stat_value["ino"], stat_value["mode"])
            if packet["acquisition_id"] != 0 or (request_identity and identity != request_identity):
                raise ValueError("request acquisition")
            request_identity = identity
            occurrence = packet["occurrence"]
            injected = selector in (2, 6)
            requested = 406 if occurrence == 1 else 399
            before_size = 0 if occurrence == 1 else 7
            if packet["requested_bytes"] != requested:
                raise ValueError("request bytes")
            if kind == "BEFORE" and stat_value["size"] != before_size:
                raise ValueError("request before size")
            if kind == "AFTER":
                result = 7 if injected and occurrence == 1 else -1 if occurrence == 2 else 406
                error = 28 if result < 0 else None
                if packet["return"] != result or packet["errno"] != error or \
                   packet["actual_bytes"] != max(result, 0) or \
                   stat_value["size"] != (7 if injected else 406):
                    raise ValueError("request write result")
                request_size = stat_value["size"]
        elif site == "request-sync":
            expected_result = -1 if selector in (3, 6) else 0
            if packet["acquisition_id"] != 0 or packet["target_stat"]["size"] != request_size or \
               (kind == "AFTER" and (packet["return"] != expected_result or
                packet["errno"] != (5 if expected_result < 0 else None))):
                raise ValueError("request sync result")
        elif kind == "AFTER" and site == "report-flush" and packet["return"] != 0:
            raise ValueError("report flush result")
        elif kind == "AFTER" and site == "report-sync":
            expected_result = -1 if selector in (5, 6) else 0
            if packet["return"] != expected_result or \
               packet["errno"] != (5 if expected_result < 0 else None):
                raise ValueError("report sync result")
    cleanup = [packet for packet in packets if packet["kind"] == "CLEANUP_FINAL"]
    if cleanup and (cleanup[0]["cleanup_complete"] is not True or
            not cleanup[0]["cleanup_start_ns"] < cleanup[0]["cleanup_finished_ns"] <
                cleanup[0]["cleanup_deadline_ns"]):
        raise ValueError("collector cleanup result")

def validate(root, selector):
    if selector not in EXPECTED:
        raise ValueError("selector")
    root = Path(root).resolve()
    expected_wait, phase, report_kind, status, failure, error, count = EXPECTED[selector]
    owner = strict(read(root / "owner-result.json"))
    if owner.get("schema_version") != 2 or owner.get("selector") != selector or \
       owner.get("raw_wait_status") != expected_wait or owner.get("owner_failure") is not None:
        raise ValueError("owner result")
    if owner.get("cleanup_complete") is not True or owner.get("application_acceptance") is not False:
        raise ValueError("owner cleanup")
    nonce = owner.get("nonce")
    if type(nonce) is not str or len(nonce) != 32 or any(
            char not in "0123456789abcdef" for char in nonce):
        raise ValueError("nonce")
    rows = journal(root / "witness.jsonl")
    if rows[-1]["packet"].get("kind") != "OWNER_RESULT":
        raise ValueError("owner publication")
    packets = [row["packet"] for row in rows[:-1]]
    hashes = owner.get("hashes")
    if not isinstance(hashes, dict) or set(hashes) != {
            "generated_sha256", "header_sha256", "elf_sha256"}:
        raise ValueError("owner hashes")
    validate_packet_order(packets, selector, nonce, hashes, count)
    if any(rows[index]["receipt_monotonic_ns"] >= rows[index + 1]["receipt_monotonic_ns"]
           for index in range(len(rows) - 1)):
        raise ValueError("receipt order")
    if any(packet["phase"] != phase for packet in packets[1:]
           if packet["kind"] in ("BEFORE", "AFTER")):
        raise ValueError("selector phase")
    collection = root / "collection"
    report_path = collection / "report.json"
    if report_kind == "absent":
        if report_path.exists():
            raise ValueError("fabricated report")
    else:
        report = strict(read(report_path))
        if report.get("status") != status or report.get("first_failure") != failure or \
           report.get("first_failure_errno") != error:
            raise ValueError("report result")
    request = read(collection / "request.bin")
    if selector in (2, 6):
        if request != PREFIX or sha(request) != PREFIX_SHA:
            raise ValueError("request prefix")
    elif sha(request) != owner.get("request_artifact_sha256"):
        raise ValueError("request artifact")
    if selector in (5, 6):
        sync = [packet for packet in packets if packet.get("site") == "report-sync"]
        if len(sync) != 2 or sync[-1].get("return") != -1 or \
           sync[-1].get("errno") != 5:
            raise ValueError("report sync failure")
    return True
