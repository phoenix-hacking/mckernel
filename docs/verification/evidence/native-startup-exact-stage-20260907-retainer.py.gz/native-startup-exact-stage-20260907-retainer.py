from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,tarfile
repo=Path('/home/holden/mckernel');work=Path('/home/holden/mckernel-work/scratch')
compiled=work/'native-startup-exact-stage-20260907-1';guest=work/'native-startup-exact-stage-guest-20260907-1'
build=json.loads((compiled/'record.json').read_text());run=json.loads((guest/'local-run.json').read_text())
assert build['status']=='PASS' and run['status']=='technical-capture-passed'
assert not run['missing_markers'] and not run['error_markers'] and run['declared_stage_inputs_required']
assert len(run['physical_image_readbacks'])==56 and len(run['physical_startup_table_readbacks'])==56 and run['startup_allocation_failures']==64
for row in build['outputs']+run['inputs']:
 if row['path'].startswith('/work/'): path=work/row['path'][6:]
 elif row['path'].startswith('/workspace/'): path=repo/row['path'][11:]
 else: continue
 raw=path.read_bytes();assert len(raw)==row['size'] and hashlib.sha256(raw).hexdigest()==row['sha256'],str(path)
artifacts=[]
def retain(name,raw):
 data=gzip.compress(raw,mtime=0);path=repo/'docs/verification/evidence'/('native-startup-exact-stage-20260907-'+name+'.gz')
 with path.open('xb') as stream: stream.write(data)
 artifacts.append(dict(path=str(path.relative_to(repo)),size=len(data),sha256=hashlib.sha256(data).hexdigest(),uncompressed_size=len(raw),uncompressed_sha256=hashlib.sha256(raw).hexdigest()))
def archive(folder,exclude):
 buffer=io.BytesIO()
 with tarfile.open(fileobj=buffer,mode='w',format=tarfile.USTAR_FORMAT) as tar:
  for path in sorted(folder.rglob('*')):
   if not path.is_file() or path.relative_to(folder).parts[0] in exclude: continue
   raw=path.read_bytes();info=tarfile.TarInfo(str(path.relative_to(folder)));info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
 return buffer.getvalue()
retain('build-capture.tar',archive(compiled,{'prototype-stage','prototype-module-build'}))
retain('guest-capture.tar',archive(guest,{'root'}))
for label,folder,names in [('build',compiled,('record.json','stage-lock.json','kbuild-link-closure.json','module-artifact-checks.json','kernel-build.log','module-build.log')),('guest',guest,('local-run.json','serial.log','image-model.json'))]:
 for name in names: retain(label+'-'+name,(folder/name).read_bytes())
for name in ('build-native-startup-exact-stage.py','check-native-startup-exact-stage-modules.py','run-native-startup-declared-stage-guest.py','run-native-startup-exact-stage-validation.py','inventory-rust-consumers-startup-20260907.py','run-native-startup-full-tests.py'):
 retain(name,(work/name).read_bytes())
retain('retainer.py',Path(__file__).read_bytes())
inventory_path=work/'rust-consumers-startup-20260907.json';inventory=json.loads(inventory_path.read_text())
assert len(inventory['files'])==137 and not inventory['removed_baseline_files'] and not inventory['cmake_missing_dependencies'] and not inventory['cmake_extra_dependencies']
with (repo/'docs/verification'/inventory_path.name).open('xb') as stream: stream.write(inventory_path.read_bytes())
references=[]
for name in ('native-startup-tables-checkpoint-20260907.json','native-startup-staging-integration-20260907.json','rust-consumers-startup-20260907.json'):
 path=repo/'docs/verification'/name;raw=path.read_bytes();references.append(dict(path=str(path.relative_to(repo)),size=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
record=dict(schema_version=1,kind='native-owned-startup-tables-declared-stage-local-validation',recorded_utc=datetime.now(timezone.utc).isoformat(),source_parent=build['source_parent'],
 build=dict(status='PASS',declared_stage_verified=True,link_closure_verified=True,module_architecture_and_no_simd_verified=True,started_utc=build['started_utc'],finished_utc=build['finished_utc'],outputs=build['outputs']),
 guest=dict(status='PASS',cpus=4,numa_nodes=2,module_cycles=2,abis=['x86_64','i386'],started_utc=run['started_utc'],finished_utc=run['finished_utc'],physical_image_readbacks=56,physical_startup_table_readbacks=56,startup_allocation_failures=64,owner_cleanup_repetitions=32,independent_table_models=run['startup_table_models'],missing_markers=[],error_markers=[],immutable_inputs_verified_at_completion=True),
 rust_preservation=dict(total_files=137,counts=inventory['preservation_counts'],kernel_crate_files=64,native_staged_files=19,removed_files=[]),
 full_repository_suite='pending',production_gate_credit=False,native_mckernel_boot_proven=False,complete_rust_unification_claimed=False,
 remaining=['Full repository suite','Owned trampoline and exact boot parameters','Native CPU wakeup, readiness and IKC','Native mcctrl/application checks','McKernel Rust/assembly-only completion','Independent production acceptance'],references=references,artifacts=artifacts)
with (repo/'docs/verification/native-startup-exact-stage-checkpoint-20260907.json').open('x') as stream: stream.write(json.dumps(record,indent=2,sort_keys=True)+'\n')
print('Retained declared startup build/guest and Rust inventory:',len(artifacts),'artifacts')
