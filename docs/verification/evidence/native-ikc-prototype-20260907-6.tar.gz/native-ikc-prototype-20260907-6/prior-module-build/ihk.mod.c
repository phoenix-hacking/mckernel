#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

MODULE_INFO(intree, "Y");

KSYMTAB_FUNC(ihk_os_create_unbooted_v1, "_gpl", "MCKERNEL_IHK_V1");
KSYMTAB_FUNC(ihk_os_create_unbooted_v2, "_gpl", "MCKERNEL_IHK_V1");
KSYMTAB_FUNC(ihk_os_create_unbooted_v3, "_gpl", "MCKERNEL_IHK_V1");
KSYMTAB_FUNC(ihk_os_destroy_unbooted_v1, "_gpl", "MCKERNEL_IHK_V1");
KSYMTAB_DATA(ihk_provider_lifecycle_v1, "_gpl", "MCKERNEL_IHK_V1");
KSYMTAB_FUNC(ihk_smp_provider_attach_v1, "_gpl", "MCKERNEL_IHK_V1");
KSYMTAB_FUNC(ihk_smp_provider_attach_v2, "_gpl", "MCKERNEL_IHK_V1");
KSYMTAB_FUNC(ihk_smp_provider_close_v1, "_gpl", "MCKERNEL_IHK_V1");
KSYMTAB_FUNC(ihk_smp_provider_detach_v1, "_gpl", "MCKERNEL_IHK_V1");
KSYMTAB_FUNC(ihk_smp_provider_detach_v2, "_gpl", "MCKERNEL_IHK_V1");
KSYMTAB_FUNC(ihk_smp_provider_open_v1, "_gpl", "MCKERNEL_IHK_V1");

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "791C951E6339350CCEBD32F");
MODULE_INFO(rhelversion, "10.2");
