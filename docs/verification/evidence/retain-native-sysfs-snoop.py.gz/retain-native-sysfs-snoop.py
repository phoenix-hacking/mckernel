"""Retain snooping fixes, independent fixture evidence and actual-start regressions."""
from datetime import datetime, timezone
from pathlib import Path
import gzip, hashlib, json, os, shutil, subprocess, sys, tarfile
assert os.getuid()==1000 and os.sched_getaffinity(0)=={2,3,4,5}
repo=Path('/workspace');work=Path('/work')
out=work/('native-sysfs-snoop-retained-20260908-'+sys.argv[1]);out.mkdir()
manifest=out/'native-sysfs-snoop-checkpoint-20260908.json'
record=dict(status='running',started_utc=datetime.now(timezone.utc).isoformat(),artifacts=[],compiler_inputs=[],references=[],commands=[],source_references=[],
    source_parent=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
    production_gate_credit=False,sysfs_service_completed=False,applications_tested=False)
def identity(path):
    raw=path.read_bytes();return dict(path=str(path),size=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def verify(row):
    assert identity(Path(row['path']))==row,row
def artifact(source,name,tree=False):
    path=out/name
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as compressed:
            if tree:
                with tarfile.open(fileobj=compressed,mode='w') as archive:archive.add(source,arcname=source.name)
            else:
                with source.open('rb') as stream:shutil.copyfileobj(stream,compressed)
    with gzip.open(path,'rb') as stream:
        while stream.read(1<<20):pass
    row=identity(path);row['path']='docs/verification/evidence/'+path.name;row['source']=str(source)
    record['artifacts'].append(row)
try:
    shutil.copyfile(__file__,out/'helper.py')
    for name in ['native-sysfs-service-checkpoint-20260908.json','native-sysfs-setup-checkpoint-20260907.json','native-topology-checkpoint-20260907.json']:
        path=repo/'docs/verification'/name;ref=identity(path);ref['path']=str(path.relative_to(repo));record['references'].append(ref)
        saved=json.loads(path.read_text());assert saved['status']=='PASS'
        for row in saved['artifacts']:
            path=repo/row['path'];actual=identity(path)
            assert actual['sha256']==row['sha256'] and actual['size']==row['size'],row
            with gzip.open(path,'rb') as stream:
                while stream.read(1<<20):pass
    captures=[
        'native-sysfs-snoop-module-20260908-1',
        'native-sysfs-snoop-module-20260908-2',
        'native-sysfs-snoop-guest-20260908-1',
        'native-sysfs-snoop-guest-20260908-2',
        'native-sysfs-snoop-start-20260908-x86_64-1',
        'native-sysfs-snoop-start-20260908-i386-1',
    ]
    record['captures']=[]
    for name in captures:
        capture=work/name;state=json.loads((capture/'record.json').read_text())
        expected='FAIL' if name==captures[2] else 'PASS';assert state['status']==expected,(name,state['status'])
        for row in state.get('inputs',[])+state.get('compiler_inputs',[])+state.get('outputs',[]):verify(row)
        for row in state.get('captures',[]):
            for item in row.get('artifacts',[]):verify(item)
        for row in state.get('overlay',[]):
            relative=Path(row['path']).relative_to(work/'native-source/linux-6.12.0-211.44.1.el10_2/drivers/misc/mckernel')
            saved=identity(capture/'staged-source'/relative)
            assert saved['size']==row['size'] and saved['sha256']==row['sha256'],(name,relative)
        for row in state.get('extracted_bodies',[]):
            raw=Path(row['source']).read_bytes()[row['start_byte']:row['end_byte']]
            assert hashlib.sha256(raw).hexdigest()==row['sha256'],row
        artifact(capture,name+'.tar.gz',True);artifact(capture/'record.json',name+'-record.json.gz')
        record['captures'].append(dict(path=str(capture),status=expected))
    compiled=work/'native-sysfs-snoop-module-20260908-2'
    originals=compiled/'original-inputs';staged=compiled/'staged-source'
    replay=out/'format-replay';replay.mkdir()
    fixture_names=['mckernel_sysfs_snoop_verify.rs','mckernel_native_snoop_checks.rs','mckernel_sysfs_snoop_oracle.c','native-sysfs-snoop.c']
    for original in sorted(originals.rglob('*')):
        if not original.is_file():continue
        relative=original.relative_to(originals)
        if relative.name in fixture_names:
            compiler=compiled/'fixture/source/scripts/tests/fixtures'/relative
            current=repo/'scripts/tests/fixtures'/relative
        else:
            compiler=staged/relative;current=repo/'host-kernel/native-rust'/relative
        source_bytes=current.read_bytes();compiler_bytes=compiler.read_bytes()
        row=dict(path=str(current.relative_to(repo)),source_size=len(source_bytes),source_sha256=hashlib.sha256(source_bytes).hexdigest(),
            compiler_capture=str(compiler),original_capture=str(original),size=len(compiler_bytes),sha256=hashlib.sha256(compiler_bytes).hexdigest())
        if source_bytes==compiler_bytes:row['binding']='identical'
        else:
            assert source_bytes==original.read_bytes() and current.suffix=='.rs',str(current)
            candidate=replay/relative;candidate.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(current,candidate)
            command=['rustfmt','--edition','2021','--config','skip_children=true,reorder_modules=false',str(candidate)]
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            record['commands'].append(dict(command=command,exit_code=result.returncode,output=result.stdout.decode()))
            assert result.returncode==0 and candidate.read_bytes()==compiler_bytes,str(current)
            row['binding']='exact pinned rustfmt replay';row['replay']=str(candidate)
        record['compiler_inputs'].append(row)
    artifact(replay,'native-sysfs-snoop-format-replay-20260908.tar.gz',True)
    for path in [repo/'executer/kernel/mcctrl/sysfs.c',repo/'executer/kernel/mcctrl/rust/mcctrl_helpers.rs']:
        row=identity(path);row['path']=str(path.relative_to(repo));record['source_references'].append(row)
    assert (repo/'executer/kernel/mcctrl/sysfs.c').read_bytes()==(compiled/'legacy-reference/sysfs.c').read_bytes()
    artifact(repo/'executer/kernel/mcctrl/rust/mcctrl_helpers.rs','native-sysfs-snoop-legacy-rust-dispatch-20260908.rs.gz')
    for name in ['build-native-sysfs-snoop.py','run-native-sysfs-snoop-guest.py','native-sysfs-snoop-guest-init.sh','run-native-sysfs-snoop-start.py']:
        artifact(work/name,name+'.gz')
    artifact(out/'helper.py','retain-native-sysfs-snoop.py.gz')
    record['actual_starts']=[]
    for name in captures[-2:]:
        guest=json.loads((work/name/'record.json').read_text())
        assert guest['full_ready_observed'] and guest['boot_ioctl']==0 and guest['registry_status']==4 and guest['physical_status']==3
        assert guest['observed_callback_exchanges']==130 and guest['guest_store_payload_checks']==64
        for path in sorted((work/name/'probe-source').iterdir()):
            current=repo/'scripts/tests/fixtures'/path.name
            assert current.read_bytes()==path.read_bytes(),str(current)
            record['compiler_inputs'].append(dict(path=str(current.relative_to(repo)),source_size=current.stat().st_size,source_sha256=identity(current)['sha256'],
                compiler_capture=str(path),original_capture=str(path),size=path.stat().st_size,sha256=identity(path)['sha256'],binding='identical actual-start compiler source'))
        record['actual_starts'].append({key:guest[key] for key in ['architecture','boot_ioctl','registry_status','physical_status','observed_callback_exchanges','read_checks','store_checks','rounds','guest_store_payload_checks']})
    fixture=json.loads((work/captures[3]/'record.json').read_text())
    assert fixture['format_comparisons']==272 and fixture['concurrent_scalar_reads']==2560 and fixture['claim_collision_races']==128
    record.update(status='PASS',native_modules_built=3,verification_modules_built=2,no_simd=True,
        fixture_module_lifetimes=2,unchanged_c_format_comparisons=272,initial_fixture_file_reads=16,concurrent_scalar_reads=2560,
        fixture_scalar_producer_updates=fixture['scalar_producer_updates'],claim_collision_races=128,request_slots=66,
        actual_linux_callback_drains=2,mapping_reclaims=2,joined_fixture_workers=6,fixture_namespaces_removed=True,
        full_ready_observed=True,actual_start_abis=['x86_64','i386'],actual_callback_exchanges=260,actual_read_checks=132,actual_store_checks=128,
        actual_guest_store_payload_checks=128,physical_ready_captures=4,
        scope='Corrected native snooping formats/coherent scalar loads and actual mapping ledger verified in Linux, with both actual one-CPU McKernel starts and ordinary callback regressions',
        limitations=[
            'The mapping/snooping fixture includes unchanged production sources but substitutes diagnostic identity/extent carriers and an eight-entry carrier capacity. It owns Linux RAM and grants no IHK authority; production request capacity remains 66.',
            'The separate C oracle contains eight unchanged legacy show bodies and two bitmap wrappers; it is not a production module dependency. Oversized output is rejected explicitly instead of reproducing legacy truncation or unsafe writes.',
            'Fixture coverage includes all five request layouts, fixed/request/snoop aliases, repeated claims, 66-slot exhaustion/reuse, queue reservation rollback and successful exclusion, concurrent claim collisions and callback-bound mapping retirement. Serial exhaustion, every allocator failure and arbitrary malicious peer writes remain outside these checks.',
            'Actual starts exercise one McKernel CPU in a four-vCPU/two-NUMA Linux guest, ordinary boot metadata and 260 remote callbacks. These runs do not exercise real guest snooping, mkdir/unlink/release, packet-queue pressure, worker allocation failure, multiple McKernel CPUs/OSes or applications.',
            'The guest CPU online store remains NYI: it logs and acknowledges bytes without changing its value or Linux CPU state. No store mutation or hotplug credit is claimed.',
            'The first Linux fixture run remains FAIL for the missing ENOSPC store override. Both module builds and the corrected second guest pass; all original bytes and failure logs remain retained.',
            'Preparation coverage remains the prior checkpoint, not a new full preparation run. Native shutdown, current full-suite integration, complete Rust/assembly, declared production integration and independent acceptance remain open. No production gate accounting change.'
        ])
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    manifest.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],out,flush=True)
