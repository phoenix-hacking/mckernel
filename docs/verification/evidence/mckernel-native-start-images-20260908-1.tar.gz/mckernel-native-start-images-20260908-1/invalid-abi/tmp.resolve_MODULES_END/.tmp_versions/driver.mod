/work/mckernel-native-start-images-20260908-1/invalid-abi/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-start-images-20260908-1/invalid-abi/tmp.resolve_MODULES_END/driver.o

