/work/mckernel-native-start-images-20260908-1/fallback/tmp.resolve_MODULES_END/driver.ko
/work/mckernel-native-start-images-20260908-1/fallback/tmp.resolve_MODULES_END/driver.o

