kernel/CMakeFiles/mckernel.img.dir/__/lib/list.c.o: \
 /work/mckernel-native-start-images-20260908-1/source/lib/list.c \
 /work/mckernel-native-start-images-20260908-1/source/lib/include/list.h
