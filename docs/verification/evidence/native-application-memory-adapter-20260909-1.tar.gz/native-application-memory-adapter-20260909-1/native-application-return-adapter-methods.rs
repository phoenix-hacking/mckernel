impl Registration {
    fn wait_syscall(&self, argument: usize, compat: bool) -> Result<isize> {
        if compat {
            return Err(errno(-95));
        }
        let worker = self.worker(true)?;
        if worker.delivery.load(Ordering::Acquire) != 0 {
            return Err(EBUSY);
        }
        loop {
            let mut bytes = [0; 96];
            bytes[..8].copy_from_slice(&worker.handle.to_le_bytes());
            self.invoke(super::application_abi::WAIT_SYSCALL, &mut bytes)?;
            let serial = u64::from_le_bytes(bytes[8..16].try_into().unwrap());
            if serial == 0 {
                return Err(EIO);
            }
            if image::word(&bytes, 40).map_err(errno)? == 9 {
                // mmap numbers in this protocol are kernel file/device-pager
                // requests. Consume the retained packet in this worker's context
                // before the ordinary userspace WAIT descriptor is touched.
                let mut pager = [0; 32];
                pager[..16].copy_from_slice(&bytes[..16]);
                let result = self.invoke(super::application_abi::PAGER_SYSCALL, &mut pager);
                if result.is_err() && image::word(&pager, 16).map_err(errno)? == 0 {
                    let mut rollback = [0; 24];
                    rollback[..16].copy_from_slice(&bytes[..16]);
                    let _ = self.invoke(super::application_abi::COPIED_SYSCALL, &mut rollback);
                }
                result?;
                continue;
            }
            if image::word(&bytes, 40).map_err(errno)? == 11 {
                let mut clear = [0; 40];
                clear[..16].copy_from_slice(&bytes[..16]);
                if let Err(error) = self.invoke(super::application_abi::CLEAR_SYSCALL, &mut clear) {
                    if u64::from_le_bytes(clear[16..24].try_into().unwrap()) == 0 {
                        let mut rollback = [0; 24];
                        rollback[..16].copy_from_slice(&bytes[..16]);
                        let _ = self.invoke(super::application_abi::COPIED_SYSCALL, &mut rollback);
                    }
                    return Err(error);
                }
                let start = u64::from_le_bytes(clear[24..32].try_into().unwrap());
                let end = u64::from_le_bytes(clear[32..40].try_into().unwrap());
                // The kernel reservation defers cancellation. This worker
                // retains the exact Mirror/Registration while Linux clears its
                // current MM outside every application/transport lock. Always
                // finish the reservation, including an actual MM error.
                let value = worker
                    .mirror
                    .clear(start, end)
                    .map_or_else(|error| error.to_errno() as i64, |()| 0);
                clear[16..].fill(0);
                clear[24..32].copy_from_slice(&value.to_le_bytes());
                self.invoke(super::application_abi::CLEAR_DONE, &mut clear)?;
                continue;
            }
            let copied = UserSlice::new(argument, 80)
                .writer()
                .write_slice(&bytes[16..96]);
            let mut result = [0; 24];
            result[..16].copy_from_slice(&bytes[..16]);
            result[16..24].copy_from_slice(&(copied.is_ok() as u64).to_le_bytes());
            let commit = self.invoke(super::application_abi::COPIED_SYSCALL, &mut result);
            // The original private request stays queued if any user byte faults.
            copied?;
            commit?;
            // The launcher uses its Linux worker slot in RET.cpu. Retain the
            // packet's guest CPU before publishing this private delivered serial.
            worker.delivery_cpu.store(
                image::word(&bytes, 16).map_err(errno)? as i32,
                Ordering::Relaxed,
            );
            worker.delivery.store(serial, Ordering::Release);
            if self.trace() {
                pr_info!("application_syscall=delivered os={} generation={} pid={} worker={} delivery={} cpu={} number={}\n",
                self.slot, self.generation, self.pid, worker.handle, serial,
                image::word(&bytes, 16).map_err(errno)?, image::word(&bytes, 40).map_err(errno)?);
            }
            return Ok(0);
        }
    }
    fn return_syscall(&self, argument: usize, compat: bool) -> Result<isize> {
        if compat {
            return Err(errno(-95));
        }
        let mut descriptor = [0; 40];
        UserSlice::new(argument, descriptor.len())
            .reader()
            .read_slice(&mut descriptor)?;
        let worker = self.worker(false)?;
        let serial = worker.delivery.load(Ordering::Acquire);
        if serial == 0 {
            return Err(EINVAL);
        }
        let length = image::word(&descriptor, 32).map_err(errno)?;
        if length > 16 {
            return Err(EINVAL);
        }
        let mut bytes = [0; 72];
        bytes[..8].copy_from_slice(&worker.handle.to_le_bytes());
        bytes[8..16].copy_from_slice(&serial.to_le_bytes());
        let cpu = worker.delivery_cpu.load(Ordering::Relaxed) as i64;
        bytes[16..24].copy_from_slice(&cpu.to_le_bytes());
        bytes[24..32].copy_from_slice(&descriptor[8..16]);
        bytes[32..48].copy_from_slice(&descriptor[24..40]);
        if length != 0 {
            let source = image::word(&descriptor, 16).map_err(errno)? as usize;
            source.checked_add(length as usize).ok_or(errno(-75))?;
            UserSlice::new(source, length as usize)
                .reader()
                .read_slice(&mut bytes[56..56 + length as usize])?;
        }
        let launcher_cpu = image::word(&descriptor, 0).map_err(errno)? as i64;
        if launcher_cpu != cpu && self.trace() {
            pr_info!("application_syscall=return_route os={} generation={} pid={} worker={} delivery={} launcher_cpu={} guest_cpu={}\n",
                self.slot, self.generation, self.pid, worker.handle, serial, launcher_cpu, cpu);
        }
        let result = self.invoke(super::application_abi::RETURN_SYSCALL, &mut bytes);
        if image::word(&bytes, 48).map_err(errno)? == 1 {
            // This includes interrupted waits after acceptance. The independent
            // pump retains the original result; WAIT cannot rebind this worker
            // until its status and any required wake have actually published.
            worker.delivery.store(0, Ordering::Release);
        }
        result?;
        if self.trace() {
            pr_info!("application_syscall=returned os={} generation={} pid={} worker={} delivery={} cpu={} value={}\n",
                self.slot, self.generation, self.pid, worker.handle, serial,
                image::word(&bytes, 16).map_err(errno)?, image::word(&bytes, 24).map_err(errno)? as i64);
        }
        Ok(0)
    }
}
