"""Functional McKernel OS/apps and Rust/assembly migration only; no security testing.
Static whole-owner/request/query operational namespace join. No product import.
Retired history/provenance is retained; active namespace constants must be current.
"""
import ast,json,re,sys
from pathlib import Path
ROOT=Path('/home/holden/mckernel-work/host-preparation/velocity-intervention-20261023-15/m14-retained-validator-continuation-1/retained-validation-attempt-6')

def check(owner_source,request,query):
    tree=ast.parse(owner_source)
    common=[];operational=[];retired=[]
    for node in tree.body:
        historical=isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='RETIRED_COMMON_EXCLUSIONS' for t in node.targets)
        for value in ast.walk(node):
            if isinstance(value,ast.Constant) and isinstance(value.value,str) and 'retained-validation-attempt-' in value.value:
                (retired if historical else operational).append(value.value)
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='COMMON_EXCLUSION' for t in node.targets):common.append(ast.literal_eval(node.value))
    expected={'work_root':str(ROOT/'owner-work'),'owner_evidence_root':str(ROOT/'owner-evidence'),'output_root':str(ROOT/'owner-work/output'),'evidence_root':str(ROOT/'owner-work/evidence'),'attempt_root':str(ROOT/'owner-evidence/attempt'),'lease_path':str(ROOT/'lease.json'),'common_exclusion_path':str(ROOT/'common-exclusion.json')}
    if common!=[expected['common_exclusion_path']]:raise ValueError('owner COMMON_EXCLUSION differs from fresh namespace')
    if any(not p.startswith(str(ROOT)+'/') for p in operational):raise ValueError('stale operational owner namespace constant')
    if set(operational)!={expected['common_exclusion_path'],expected['work_root'],expected['owner_evidence_root']}:raise ValueError('complete expected owner operational constant set')
    for key,path in expected.items():
        if request.get(key)!=path:raise ValueError('request stale namespace '+key)
    roots=[request['source_root'],expected['work_root'],expected['owner_evidence_root'],request['gitlink_root']]
    if request['memory_allocation_roots']!=roots or query['memory_allocation_roots']!=roots:raise ValueError('request/query allocation root mismatch')
    if query['work_root']!=expected['work_root'] or query['owner_evidence_root']!=expected['owner_evidence_root']:raise ValueError('query stale work/evidence root')
    required_absent={expected[k] for k in ('evidence_root','attempt_root','lease_path','common_exclusion_path')}
    if not required_absent.issubset(set(query['absent_paths'])):raise ValueError('query missing fresh absence check')
    if any('retained-validation-attempt-' in p and not p.startswith(str(ROOT)+'/') for p in query['absent_paths']):raise ValueError('query stale absent namespace')
    def strings(value):
        if isinstance(value,str):yield value
        elif isinstance(value,dict):
            for item in value.values():yield from strings(item)
        elif isinstance(value,list):
            for item in value:yield from strings(item)
    if any(not p.startswith(str(ROOT)+'/') for p in strings(request) if 'retained-validation-attempt-' in p):raise ValueError('stale request namespace outside declared role fields')
    return {'status':'PASS_STATIC_COMPLETE_OWNER_REQUEST_QUERY_NAMESPACE_JOIN_ONLY','namespace':str(ROOT),'owner_operational_constants':sorted(operational),'retired_history_preserved':retired,'request_roles':expected,'allocation_roots':roots,'runtime_or_artifact_credit':False}

if __name__=='__main__':
    if len(sys.argv)!=4:raise SystemExit('owner-source request-json query-config-json required')
    print(json.dumps(check(Path(sys.argv[1]).read_text(),json.loads(Path(sys.argv[2]).read_bytes()),json.loads(Path(sys.argv[3]).read_bytes())),sort_keys=True))
