from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, shutil, subprocess, sys, tarfile

assert os.getuid() == 1000 and os.sched_getaffinity(0) == {2, 3, 4, 5}
repo, base = Path('/workspace'), Path('/work')
out = base / ('native-sysfs-setup-retained-20260907-' + sys.argv[1]); out.mkdir()
final = base / 'native-sysfs-setup-module-20260907-1'
record = dict(started_utc=datetime.now(timezone.utc).isoformat(), status='running',
    source_parent=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
    artifacts=[], captures=[], compiler_inputs=[], references=[], production_gate_credit=False,
    declared_stage=False, sysfs_service_completed=False, mckernel_boot_proven=False,
    applications_tested=False)

def digest(path):
    checksum = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''): checksum.update(chunk)
    return checksum.hexdigest()

def identity(path):
    return dict(path=str(path), size=path.stat().st_size, sha256=digest(path))

def checked(row):
    assert identity(Path(row['path'])) == row, row

def retain_gzip(source, name):
    target = out / name
    with source.open('rb') as stream, target.open('xb') as raw:
        with gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as output:
            shutil.copyfileobj(stream, output)
    row = identity(target)
    row.update(path='docs/verification/evidence/' + name, source=str(source),
        unpacked_size=source.stat().st_size, unpacked_sha256=digest(source))
    record['artifacts'].append(row)

def bind(current, compiled):
    relative = current.relative_to(repo)
    row = identity(compiled); row['path'] = str(relative)
    row.update(source_sha256=digest(current), source_size=current.stat().st_size,
               binding='identical', compiler_capture=str(compiled))
    if current.read_bytes() != compiled.read_bytes():
        assert current.suffix == '.rs', (str(current), str(compiled))
        original = final / 'original-inputs' / current.relative_to(repo / 'host-kernel/native-rust')
        assert current.read_bytes() == original.read_bytes(), ('original-source-binding', str(current))
        saved = out / 'source-bindings' / relative
        saved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(current, saved.with_suffix('.original.rs'))
        shutil.copyfile(current, saved)
        command = ['rustfmt', '--edition', '2021', '--config', 'skip_children=true,reorder_modules=false', str(saved)]
        with saved.with_suffix('.rustfmt.log').open('wb') as log:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
        assert result.returncode == 0, (command, result.returncode)
        assert saved.read_bytes() == compiled.read_bytes(), ('formatted-source-binding', str(current))
        row.update(binding='exact-rustfmt-replay', command=command, original_capture=str(original))
    if row not in record['compiler_inputs']: record['compiler_inputs'].append(row)

try:
    shutil.copyfile(__file__,out/'helper.py')
    reference=repo/'docs/verification/native-sysfs-setup-build-checkpoint-20260907.json'
    build=json.loads(reference.read_text());assert build['status']=='PASS'
    record['compiler_inputs']=build['compiler_inputs']
    for row in record['compiler_inputs']:
        current=repo/row['path']
        assert digest(current)==row['source_sha256'] and current.stat().st_size==row['source_size'],row['path']
    failure=base/'native-sysfs-setup-retained-20260907-1'
    failed=json.loads((failure/'native-sysfs-setup-checkpoint-20260907.json').read_text())
    assert failed['status']=='FAIL' and failed['error']=="'outputs'" and not failed['artifacts']
    archive=out/'native-sysfs-setup-retention-failure-20260907-1.tar.gz'
    with tarfile.open(archive,'w:gz') as tar:tar.add(failure,arcname=failure.name)
    row=identity(archive);row.update(path='docs/verification/evidence/'+archive.name,source=str(failure));record['artifacts'].append(row)
    retain_gzip(failure/'native-sysfs-setup-checkpoint-20260907.json','native-sysfs-setup-retention-failure-20260907-1.json.gz')
    record['retention_failures']=[dict(directory=str(failure),status='FAIL',error=failed['error'],
        started_utc=failed['started_utc'],finished_utc=failed['finished_utc'],scope='Metadata schema mismatch; passing guest captures were unchanged')]
    guests={}
    for mode in ['prepare','start-x86_64','start-i386']:
        name='native-sysfs-setup-os-guest-20260907-'+mode+'-1'
        source=base/name;captured=json.loads((source/'record.json').read_text())
        assert captured['status']=='PASS',name
        # The established OS guest schema records output hashes inside captures;
        # it has no top-level outputs field. Retain every top-level file as well.
        for row in captured['inputs']:checked(row)
        record.setdefault('capture_files',{})[name]=[identity(path) for path in sorted(source.iterdir()) if path.is_file()]
        for capture in captured['captures']:
            for row in capture['artifacts']:checked(row)
        serial=(source/'serial.log').read_text()
        for bad in ['Call Trace:','BUG:','Oops:','WARNING:','Kernel panic',' FAIL line=','rcu_preempt detected stalls']:
            assert bad not in serial,(name,bad)
        archive=out/(name+'.tar.gz')
        with tarfile.open(archive,'w:gz') as tar:tar.add(source,arcname=name)
        assert archive.stat().st_size < 95 << 20,name
        row=identity(archive);row.update(path='docs/verification/evidence/'+archive.name,source=str(source));record['artifacts'].append(row)
        retain_gzip(source/'record.json',name+'-record.json.gz')
        retain_gzip(source/'serial.log',name+'-serial.log.gz')
        for saved in sorted((source/'probe-source').iterdir()):bind(repo/'scripts/tests/fixtures'/saved.name,saved)
        record['captures'].append(dict(directory=name,status='PASS',source_parent=captured['source_parent'],
            started_utc=captured['started_utc'],finished_utc=captured['finished_utc'],qemu_exit_code=captured['qemu_exit_code']))
        guests[mode]=captured;print('Retained',mode,flush=True)
    prepare=guests['prepare']
    assert prepare['sysfs_namespace_checks']==404 and not prepare['sysfs_service_completed'] and len(prepare['captures'])==4
    for capture in prepare['captures']:assert capture['status']==0
    results={}
    for mode in ['start-x86_64','start-i386']:
        guest=guests[mode];assert guest['sysfs_service_completed'] and guest['sysfs_namespace_checks']==2
        assert guest['device_borrow_checks']==30 and guest['device_borrow_callbacks']==10
        assert (guest['setup_file_checks'],guest['setup_directories'],guest['setup_links'])==(52,19,4)
        assert len(guest['captures'])==1
        capture=guest['captures'][0];vdso=capture['linux_vdso']
        assert capture['status']==2 and vdso['service_completed'] and vdso['guest_validated_state']==2
        assert vdso['sysfs_setup']['completed'] and vdso['sysfs_setup']['nodes']==76
        assert vdso['next_request']['message']==0x30 and vdso['next_request']['busy']==1
        assert vdso['next_request']['path']=='/sys/devices/system/cpu/num_processors'
        results[mode]=dict(architectural_status=capture['status'],sysfs_setup=vdso['sysfs_setup'],next_request=vdso['next_request'],
            setup_files=guest['setup_file_checks'],setup_directories=guest['setup_directories'],setup_links=guest['setup_links'])
    for name in ['run-native-sysfs-setup-os-guest.py','native-sysfs-setup-os-functions.sh',
        'native-sysfs-setup-os-validation.inc','retain-native-sysfs-setup.py']:
        retain_gzip(base/name,'native-sysfs-setup-20260907-'+name+'.gz')
    for name in ['native-sysfs-setup-build-checkpoint-20260907.json','native-topology-checkpoint-20260907.json','native-vdso-service-checkpoint-20260907.json']:
        row=identity(repo/'docs/verification'/name);row['path']='docs/verification/'+name;record['references'].append(row)
    for row in record['artifacts']:
        checksum=hashlib.sha256();size=0
        with gzip.open(out/Path(row['path']).name,'rb') as stream:
            for chunk in iter(lambda:stream.read(1<<20),b''):checksum.update(chunk);size+=len(chunk)
        if 'unpacked_size' in row:assert size==row['unpacked_size'] and checksum.hexdigest()==row['unpacked_sha256'],row
    subprocess.run(['git','-C',str(repo),'diff','--check'],check=True)
    record.update(status='PASS',native_cpu_context_integrated=True,sysfs_service_completed=True,
        architectural_status=2,full_ready_status_proven=False,actual_start_interfaces=results,
        preparation_namespace_checks=404,started_namespace_checks=4,setup_file_checks=104,
        device_borrow_checks=60,device_borrow_callbacks=20,independent_preparation_captures=4,
        original_boot_allocation_failures=32,
        passed=['Both preparation ABIs pass across two native module lifetimes with 404 namespace checks, 32 original forced boot-allocation failures, four independent physical captures and full unstarted restoration.',
            'Both actual startup ABIs complete vDSO and SYSFS_REQ_SETUP through the integrated native CPU owner and topology-export kernel.',
            'Each actual OS exposes 52 exact setup file values, 19 directories and four valid links; independent expectations use Linux topology captured before reservation.',
            'QMP captures both actual port-503 rings advancing from vDSO through setup to SYSFS_REQ_CREATE for num_processors, with the request, shared data and all queues retained and checked.',
            'Both started owners retain their namespace after incomplete BOOT and refused resource/device destruction; all 60 exact-generation borrowing checks and 20 callbacks pass.',
            'All capture input/output hashes, complete gzip streams and current source/compiler bindings verify; build/body/fixture evidence is retained in the referenced build checkpoint.'],
        limitations=['Full ready status 3 is not proven. Architectural status stays 2; BOOT still returns -110/Failed with started owners retained.',
            'The next actual request is SYSFS_REQ_CREATE (0x30) for /sys/devices/system/cpu/num_processors with busy=1. Continuing create/path/remote callback service remains required.',
            'Applications, mcexec/binfmt and other native mcctrl services, native shutdown, declared integration, current full suite and independent production acceptance remain open.',
            'The complete McKernel and linked support Rust/assembly language requirement remains active; these prototype checks do not promote formal acceptance gates.',
            'Not every new topology/setup allocation failure has been injected, and the earlier intermittent Linux idle/RCU stall is not claimed fixed.'])
except BaseException as error:
    record.update(status='FAIL',error=str(error));raise
finally:
    record['finished_utc']=datetime.now(timezone.utc).isoformat()
    (out/'native-sysfs-setup-checkpoint-20260907.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(record['status'],'retained',len(record['artifacts']),'native setup artifacts',flush=True)
